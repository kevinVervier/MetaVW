/*
 *  snp/fprintf.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:27 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_matrix_uchar.h>
#include <gdl/gdl_snp_data.h>

int
gdl_snp_data_fprintf (FILE * stream, const gdl_snp_data * v, const gdl_boolean dose_format)
{
	size_t i,j,k;

	if (dose_format)
	{
		if (v->T == gdl_snp_data_haplotype)
		{
			for(j = 0; j < v->L; j++)
			{
				for(i = 0; i < v->N; i++)
				{
					unsigned char dose = 0;
					for(k = 0; k < v->P; k++)
					{
						unsigned char g = v->data[i*(v->L*v->P)+j*v->P+k];
						if (g == '9')
						{
							fprintf (stream, "?");
							break;
						}
						else
						{
							dose += g;
						}
					}
					fprintf (stream, "%d", dose);
					if (i < v->N-1) fprintf (stream, " ");
				}
				fprintf (stream, "\n");
				fflush (stream);
			}
		}
		else if (v->T == gdl_snp_data_genotype)
		{
			for(j = 0; j < v->L; j++)
			{
				for(i = 0; i < v->N; i++)
				{
					unsigned char g = v->data[i*(v->L)+j];
					if (g == '9')
					{
						fprintf (stream, "?");
					}
					else
					{
						fprintf (stream, "%d", g);
					}
					if (i < v->N-1) fprintf (stream, " ");
				}
				fprintf(stream, "\n");
				fflush (stream);
			}
		}
		else if (v->T == gdl_snp_data_imputed)
		{
			for(j = 0; j < v->L; j++)
			{
				size_t jj = v->imp_idx[j];
				if (gdl_bit_vector_get(v->is_imp,j))
				{
					for(i = 0; i < v->N; i++)
					{
						double a = v->P*((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision;
						if (v->P == 2)
						{
							a += 1.0-(((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision+((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
						}
						fprintf (stream, "%1.3f", a);
						if (i < v->N-1) fprintf (stream, " ");
					}
				}
				else
				{
					for(i = 0; i < v->N; i++)
					{
						unsigned char g = v->data[i*v->data_stride+jj];
						if (g == '9')
						{
							fprintf (stream, "?");
						}
						else
						{
							fprintf (stream, "%d", g);
						}
						if (i < v->N-1) fprintf (stream, " ");
					}
				}
				fprintf(stream, "\n");
				fflush (stream);
			}
		}
		else if (v->T == gdl_snp_data_dose)
		{
			for(j = 0; j < v->L; j++)
			{
				for(i = 0; i < v->N; i++)
				{
					if (v->imp_data[i*v->imp_stride+j])
					{
						fprintf (stream, "%.3f", ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision);
					}
					else
					{
						fprintf (stream, "?");
					}
					if (i < v->N-1) fprintf (stream, " ");
				}
				fprintf(stream, "\n");
				fflush (stream);
			}
		}
	}
	else
	{
		if (v->T == gdl_snp_data_haplotype)
		{
			for(i = 0; i < v->N; i++)
			{
				for(k = 0; k < v->P; k++)
				{
					for(j = 0; j < v->L; j++)
					{
						unsigned char g = v->data[i*(v->L*v->P)+j*v->P+k];
						if (g == '9')
						{
							fputc ('?', stream);
						}
						else
						{
							fputc (g, stream);
						}
					}
					fputc('\n', stream);
				}
			}
		}
		else if (v->T == gdl_snp_data_genotype)
		{
			for(i = 0; i < v->N; i++)
			{
				for(j = 0; j < v->L; j++)
				{
					unsigned char g = v->data[i*(v->L)+j];
					if (g == '9')
					{
						fputc ('?', stream);
					}
					else
					{
						fputc (g, stream);
					}
				}
				fputc('\n', stream);
			}
		}
		else if (v->T == gdl_snp_data_imputed)
		{
			for(j = 0; j < v->L; j++)
			{
				size_t jj = v->imp_idx[j];
				fprintf (stream, "%ld", gdl_bit_vector_get(v->is_imp, j));
				if (gdl_bit_vector_get(v->is_imp,j))
				{
					for(i = 0; i < v->N; i++)
					{
						if (v->P == 1)
						{
							fprintf (stream, " %1.3f", ((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision);
						}
						else
						{
							fprintf (stream, " %1.3f;%1.3f", ((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision, ((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
						}
					}
				}
				else
				{
					for(i = 0; i < v->N; i++)
					{
						unsigned char g = v->data[i*v->data_stride+jj];
						if (g == '9')
						{
							fputc (' ', stream);
							fputc ('?', stream);
						}
						else
						{
							fputc (' ', stream);
							fputc (g, stream);
						}
					}
				}
				fputc('\n', stream);
			}
		}
		else if (v->T == gdl_snp_data_dose)
		{
			for(j = 0; j < v->L; j++)
			{
				for(i = 0; i < v->N; i++)
				{
					if (v->imp_data[i*v->imp_stride+j])
					{
						fprintf (stream, "%.3f", ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision);
					}
					else
					{
						fprintf (stream, "?");
					}
					if (i < v->N-1) fprintf (stream, " ");
				}
				fputc('\n', stream);
			}
		}
	}
}

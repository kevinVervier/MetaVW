/*
 *  snp/table2.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:27 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_snp.h>

gdl_snp_table2 *
gdl_snp_table2_fscanf (FILE * stream)
{
	size_t i,j,n;
	gdl_string * tok, * tok2, * line=0;
	gdl_snp_table2 * table;
	gdl_hashtable * chrom_table;
	gdl_hashtable * gene_table;
	gdl_hashtable * transcript_table;
	gdl_string * snp;

	table = GDL_CALLOC (gdl_snp_table2, 1);

	table->table = gdl_hashtable_alloc (gdl_hash_default, 0);
	table->z = 1.0;

	// ignore header
	gdl_getline (&line, &n, stream);
	gdl_string_free (line);line=0;
	while(gdl_getline (&line, &n, stream)!=-1)
	{
		i=j=0;
		// chrom name
		tok=gdl_string_next_token (line, n, &i, &j);
		chrom_table = gdl_hashtable_lookup (table->table, tok);
		if (!chrom_table)
		{
			chrom_table = gdl_hashtable_alloc (gdl_hash_default, 0);
			gdl_hashtable_add (table->table, tok, chrom_table, 0);
		}
		gdl_string_free (tok);
		// gene
		tok=gdl_string_next_token (line, n, &i, &j);
		gene_table = gdl_hashtable_lookup (chrom_table, tok);
		if (!gene_table)
		{
			gene_table = gdl_hashtable_alloc (gdl_interface_double, 0);
			gdl_hashtable_add (chrom_table, tok, gene_table, 0);
		}
		gdl_string_free (tok);
		// transcript
		tok=gdl_string_next_token (line, n, &i, &j);
		transcript_table = gdl_hashtable_lookup (gene_table, tok);
		if (!transcript_table)
		{
			transcript_table = gdl_hashtable_alloc (gdl_interface_double, 0);
			gdl_hashtable_add (gene_table, tok, transcript_table, 0);
		}
		gdl_string_free (tok);
		// snp
		tok=gdl_string_next_token (line, n, &i, &j);
		// score (optional)
		tok2=gdl_string_next_token (line, n, &i, &j);
		if (tok2 != 0)
		{
			if (!table->has_score)
			{
				table->has_score = gdl_true;
			}
			double * x = GDL_MALLOC (double, 1);
			*x = (double)atof (tok2);
			gdl_hashtable_add (transcript_table, tok, x, 1);
			gdl_string_free (tok2);
		}
		else
		{
			gdl_hashtable_add (transcript_table, tok, &(table->z), 0);
		}
		gdl_string_free (tok);
		gdl_string_free (line);line=0;
	}

	return table;
}

gdl_boolean
gdl_snp_table2_is_inside (const gdl_snp_table2 * table, const gdl_string * chrom, const gdl_string * gene, const gdl_string * transcript, const gdl_string * snp)
{
	if (!table->table) return gdl_false;
	gdl_hashtable * chrom_table = gdl_hashtable_lookup (table->table, chrom);
	if (!chrom_table) return gdl_false;
	gdl_hashtable * gene_table = gdl_hashtable_lookup (chrom_table, gene);
	if (!gene_table) return gdl_false;
	gdl_hashtable * transcript_table = gdl_hashtable_lookup (gene_table, transcript);
	if (!transcript_table)
	{
		// is there a wildcard for that gene
		transcript_table = gdl_hashtable_lookup (gene_table, "*");
		if (!transcript_table)
		{
			return gdl_false;
		}
	}
	double * z = gdl_hashtable_lookup (transcript_table, snp);
	if (!z) return gdl_false;
	return gdl_true;
}

double
gdl_snp_table2_get_score (const gdl_snp_table2 * table, const gdl_string * chrom, const gdl_string * gene, const gdl_string * transcript, const gdl_string * snp)
{
	if (!table->table) return GDL_NAN;
	gdl_hashtable * chrom_table = gdl_hashtable_lookup (table->table, chrom);
	if (!chrom_table) return GDL_NAN;
	gdl_hashtable * gene_table = gdl_hashtable_lookup (chrom_table, gene);
	if (!gene_table) return GDL_NAN;
	gdl_hashtable * transcript_table = gdl_hashtable_lookup (gene_table, transcript);
	if (!transcript_table)
	{
		// is there a wildcard for that gene
		transcript_table = gdl_hashtable_lookup (gene_table, "*");
		if (!transcript_table)
		{
			return GDL_NAN;
		}
	}
	double * z = gdl_hashtable_lookup (transcript_table, snp);
	if (!z) return GDL_NAN;
	return *z;
}

//gdl_snp_table_entry2 **
//gdl_snp_table2_get_entries (const gdl_snp_table2 * table, size_t * n)
//{
//	size_t i;
//	gdl_snp_table_entry2 ** e = 0;
//
//	*n=0;
//	if (gdl_hashtable_size (table->table))
//	{
//		gdl_hashtable_itr * citr = gdl_hashtable_iterator (table->table);
//		do
//		{
//			gdl_hashtable * chrom_table = (gdl_hashtable *) gdl_hashtable_iterator_value (citr);
//			gdl_hashtable_itr * fitr    = gdl_hashtable_iterator (chrom_table);
//			do
//			{
//				gdl_hashtable * feature_table = (gdl_hashtable *) gdl_hashtable_iterator_value (fitr);
//				*n += gdl_hashtable_size (feature_table);
//			}
//			while(gdl_hashtable_iterator_next (fitr));
//			gdl_hashtable_iterator_free (fitr);
//		}
//		while(gdl_hashtable_iterator_next (citr));
//		gdl_hashtable_iterator_free (citr);
//
//		e = GDL_MALLOC (gdl_snp_table_entry *, *n);
//		i = 0;
//
//		citr = gdl_hashtable_iterator (table->table);
//		do
//		{
//			gdl_hashtable * chrom_table = (gdl_hashtable *) gdl_hashtable_iterator_value (citr);
//			gdl_hashtable_itr * fitr    = gdl_hashtable_iterator (chrom_table);
//			do
//			{
//				gdl_hashtable * feature_table = (gdl_hashtable *) gdl_hashtable_iterator_value (fitr);
//				gdl_hashtable_itr * sitr    = gdl_hashtable_iterator (feature_table);
//				do
//				{
//					e[i] = GDL_MALLOC (gdl_snp_table_entry, 1);
//					e[i]->chrom   = gdl_hashtable_iterator_key (citr);
//					e[i]->feature = gdl_hashtable_iterator_key (fitr);
//					e[i]->snp     = gdl_hashtable_iterator_key (sitr);
//					double * z    = gdl_hashtable_iterator_value (sitr);
//					e[i]->score   = *z;
//					i++;
//				}
//				while(gdl_hashtable_iterator_next (sitr));
//				gdl_hashtable_iterator_free (sitr);
//			}
//			while(gdl_hashtable_iterator_next (fitr));
//			gdl_hashtable_iterator_free (fitr);
//		}
//		while(gdl_hashtable_iterator_next (citr));
//		gdl_hashtable_iterator_free (citr);
//	}
//
//	return e;
//}

void
gdl_snp_table2_free (gdl_snp_table2 * table)
{
	if (table)
	{
		if (gdl_hashtable_size (table->table))
		{
			gdl_hashtable_itr * citr = gdl_hashtable_iterator (table->table);
			do
			{
				gdl_hashtable * chrom_table = (gdl_hashtable *) gdl_hashtable_iterator_value (citr);
				gdl_hashtable_itr * fitr    = gdl_hashtable_iterator (chrom_table);
				do
				{
					gdl_hashtable * gene_table = (gdl_hashtable *) gdl_hashtable_iterator_value (fitr);
					gdl_hashtable_itr * titr    = gdl_hashtable_iterator (gene_table);
					do
					{
						gdl_hashtable * transcript_table = (gdl_hashtable *) gdl_hashtable_iterator_value (titr);
						gdl_hashtable_free (transcript_table);
					}
					while(gdl_hashtable_iterator_next (titr));
					gdl_hashtable_iterator_free (titr);
					gdl_hashtable_free (gene_table);
				}
				while(gdl_hashtable_iterator_next (fitr));
				gdl_hashtable_iterator_free (fitr);
				gdl_hashtable_free (chrom_table);
			}
			while(gdl_hashtable_iterator_next (citr));
			gdl_hashtable_iterator_free (citr);
		}
		gdl_hashtable_free (table->table);
		GDL_FREE (table);
	}
}

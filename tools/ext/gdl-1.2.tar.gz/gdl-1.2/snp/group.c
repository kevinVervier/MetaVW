/*
 *  snp/group.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:27 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2010  Jean-Baptiste Veyrieras, University of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include "sys/stat.h"
#include "dirent.h"

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_snp_data.h>
#include <gdl/gdl_cnv_data.h>
#include <gdl/gdl_snp_map.h>
#include <gdl/gdl_snp_chromosome.h>
#include <gdl/gdl_snp_annotation.h>
#include <gdl/gdl_snp_genome.h>


static gdl_hashtable *
_gdl_snp_genome_read_group (FILE * stream)
{
	size_t i,j,n;
	gdl_string * tok, * tok2, * line=0;
	gdl_hashtable * chrom_table;
	gdl_hashtable * table;
	gdl_string * snp;

	table = gdl_hashtable_alloc (gdl_hash_default, 0);

	while(gdl_getline (&line, &n, stream)!=-1)
	{
		i=j=0;
		// chrom name
		tok=gdl_string_next_token (line, n, &i, &j);
		chrom_table = gdl_hashtable_lookup (table, tok);
		if (!chrom_table)
		{
			chrom_table = gdl_hashtable_alloc (gdl_string_interface, 0);
			gdl_hashtable_add (table, tok, chrom_table, 0);
		}
		gdl_string_free (tok);
		// snp
		snp = gdl_string_next_token (line, n, &i, &j);
		// group
		tok = gdl_string_next_token (line, n, &i, &j);
		gdl_hashtable_add (chrom_table, snp, tok, 1);
		gdl_string_free (snp);
		gdl_string_free (line);line=0;
	}

	return table;
}

static unsigned char
_gdl_snp_genome_new_group (gdl_snp_genome * g, const gdl_string * name)
{
	if (g->ngroup)
	{
		gdl_string ** stmp = GDL_MALLOC (gdl_string *, g->ngroup+1);
		memcpy(stmp, g->group_names, sizeof(gdl_string *)*(g->ngroup));
		GDL_FREE (g->group_names);
		g->group_names = stmp;
	} else {
		g->group_names = GDL_MALLOC (gdl_string *, 1);
	}
	g->group_names[g->ngroup] = gdl_string_clone (name);
	return ++(g->ngroup);
}

int
gdl_snp_genome_add_group (gdl_snp_genome * g, const gdl_string * file, const gdl_boolean verbose)
{
	size_t i, j, k;
	FILE * stream;
	gdl_string * group;
	gdl_hashtable  * chrom_table;
	gdl_hashtable  * group_table;

	// Load the group table
	stream = gdl_fileopen(file, "r");
	group_table = _gdl_snp_genome_read_group (stream);
	gdl_fileclose (file, stream);

	for(i = 0; i < g->nchrom; i++)
	{
		if ((chrom_table = gdl_hashtable_lookup (group_table, g->chroms[i]))!=0)
		{
			if (verbose)
			{
				fprintf (stdout, ">%s\n", g->chroms[i]);
				fflush (stdout);
			}

			gdl_snp_chromosome * chrom = gdl_snp_genome_get (g, i);

			for(j = 0; j < chrom->chrom->size; j++)
			{
				gdl_snp * snp = chrom->chrom->snps[j];
				if ((group=gdl_hashtable_lookup(chrom_table, snp->rs))!=0)
				{
					for(k = 0; k < g->ngroup; k++)
					{
						if (!strcmp(g->group_names[k], group))
						{
							break;
						}
					}
					if (k==g->ngroup)
					{
						// Create a new group
						_gdl_snp_genome_new_group (g, group);
						if (verbose)
						{
							fprintf (stdout, "GROUP:%s ==> %ld\n", group, k+1);
							fflush (stdout);
						}
					}
					if (k > 254)
					{
						GDL_ERROR_VAL ("Cannot manage more than 255 SNP groups", GDL_FAILURE, GDL_FAILURE);
					}
					snp->group = k+1;
				}
			}
			// Save the updates
			gdl_snp_genome_set (g, i, chrom);
			// Clean memory
			gdl_hashtable_free (chrom_table);
			gdl_snp_chromosome_free (chrom);
		}
	}

	gdl_hashtable_free (group_table);

	return GDL_SUCCESS;
}

int
gdl_snp_genome_del_group (gdl_snp_genome * g, const gdl_string * name, const gdl_boolean verbose)
{
	// Delete the group from group_names
	// Record the old -> new group indexes [oldindex] = newindex (0 for the deleted group)
	// Update all snps with the group index updaters

	return GDL_SUCCESS;
}

/*
 *  snp/fscanf.c
 *
 *  $Author: tflutre $, $Date: 2011/10/03 15:28:53 $, $Revision: 1.7 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <stdio.h>
#include <ctype.h>
#include <math.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_snp_data.h>
#include <gdl/gdl_snp_map.h>

static int
gdl_snp_data_fscanf_dim (FILE * stream, size_t * N, size_t * L)
{
  int c;
  size_t l=0;

  *N=*L=0;

  while ((c=fgetc(stream))!=EOF)
  {
    if (c=='\n' || c =='\r')
    {
      if (*N==0) *L=l;
      else if (*L!=l)
      {
	GDL_ERROR (gdl_string_sprintf ("Line %d contains %d data (expected %d)\n", *N+1, l, *L), GDL_FAILURE);
      }
      (*N)++;
      l=0;
    }
    l += !isspace(c);
  }
}

static void
gdl_snp_data_fscanf_dim2 (FILE * stream, size_t * N, size_t * I, size_t * L)
{
  int c;
  size_t i,j,k,n,ncol=0;
  gdl_string * line = 0;

  *N=*L=*I=0;

  if (gdl_getline (&line, &n, stream)!=-1)
  {
    i = j =0;
    while(j < n && j != n-1)
    {
      gdl_string * tok = gdl_string_next_token (line, n, &i, &j);
      if (!ncol && tok[0] == '1')
      {
	(*I) = 1;
      }
      gdl_string_free(tok);
      ncol++;
    }
    gdl_string_free (line);
    line=0;
  }
  else
  {
    GDL_ERROR_VOID ("Unexpected early end of file", GDL_FAILURE);
  }
  if (ncol > 2)
  {
    *N = ncol - 1;
  }
  else
  {
    GDL_ERROR_VOID ("Expected more than 2 columns", GDL_FAILURE);
  }
  // Fast loop on file to count the number
  // of lines
  *L=1;
  i=0;
  while ((c=fgetc(stream))!=EOF)
  {
    if (c == '\n' || c == '\r')
    {
      (*L)++;
      i=0;
      continue;
    }
    if (!i && c == '1')
    {
      (*I)++;
    }
    i=1;
  }
}

static int
gdl_snp_data_fscanf_bimbam_dim (FILE * stream, size_t * N, size_t * L, gdl_boolean bimbam)
{
  int c, sp;
  size_t l;

  *N=*L=l=sp=0;

  while ((c=fgetc(stream))!=EOF)
  {
    if (c=='\n' || c =='\r')
    {
      if (*L==0) *N=l;
      else if (*N!=l)
      {
	GDL_ERROR (gdl_string_sprintf ("Line %d contains %d data (expected %d)\n", *L+1, l, *N), GDL_FAILURE);
      }
      (*L)++;
      l=sp=0;
    }
    else if (isspace(c))
    {
      if (!sp) l++;
      sp=1;
    }
    else
    {
      sp=0;
    }
  }
  if (bimbam && *N > 3)
  {
    *N -= 2;
  }
  else if (bimbam)
  {
    GDL_ERROR ("Missing snp name & alleles at the beginning of each line\n", GDL_FAILURE);
  }
  else
  {
    (*N)++;
  }
}

gdl_snp_data *
gdl_snp_data_fscanf (FILE * stream, const gdl_snp_data_format * format)
{
  int c;
  size_t i, j, k, N, L, I;
  long offset;
  gdl_snp_data * v;

  if (format->dose || format->bimbam)
  {
    offset = ftell (stream);

    gdl_snp_data_fscanf_bimbam_dim (stream, &N, &L, format->bimbam);

    //printf ("N = %ld, L = %ld\n", N, L);
    printf ("Samples = %ld, Variants = %ld, Ploidy = %ld\n", N, L, format->P);
    fflush (stdout);

    v = gdl_snp_data_alloc (gdl_snp_data_dose, N, L, 0, format->P);

    fseek (stream, offset, SEEK_SET);

    size_t i,j=0,k,l,n,m,len,ni=0,nni=0;
    gdl_string * tok, * line=0;
    double x;

    while(gdl_getline(&line, &n, stream)!=-1)
    {
      k = l = 0;
      if (format->bimbam)
      {
	// skip the first 3 tokens
	for(i = 0; i < 3; i++)
	{
	  tok = gdl_string_next_token (line, n, &k, &l);
	  gdl_string_free (tok);
	}
      }
      for(i = 0; i < N; i++)
      {
	tok = gdl_string_next_token (line, n, &k, &l);
	if (!tok)
	{
	  GDL_ERROR_VAL(gdl_string_sprintf ("In line %ld, genotype %ld is missing.\n   This is generally due to extra space at the end of the line.\n   Please remove these extra spaces first.\n", j+1, i+1), GDL_FAILURE, 0);
	}
	if (tok[0] == format->na_char)
	{
	  gdl_snp_data_xmissing (v, i, j);
	}
	else
	{
	  x   = (double)atof(tok);
	  gdl_snp_data_xset (v, i, j, x);
	}
	gdl_string_free (tok);
      }
      gdl_string_free (line);
      line=0;
      j++;
    }
  }  // end of format->dose or format->bimbam
  
  else if (format->imputed)
  {
    /**
     * imputed sample1 sample2 sample3
     * 0 0 2 1 --> genotype mode
     * 1 0.5;0.25 0.2;0.8 0.1;0.8 // implicitely prob. for homozygotes 1/1;0/0
     * etc...
     */
    offset = ftell (stream);

    gdl_snp_data_fscanf_dim2 (stream, &N, &I, &L);

    //printf ("N = %ld, L = %ld, I = %ld, P = %ld\n", N, L, I, format->P);
    printf ("Samples = %ld, Variants = %ld, Imputed = %ld, Ploidy = %ld\n", N, L, I, format->P);
    fflush (stdout);

    v = gdl_snp_data_alloc (gdl_snp_data_imputed, N, L, I, format->P);

    fseek (stream, offset, SEEK_SET);

    size_t i,j=0,k,l,n,m,len,ni=0,nni=0;
    gdl_string * tok, * line=0;
    double * x = GDL_MALLOC (double, format->P);

    while(gdl_getline(&line, &n, stream)!=-1)
    {
      if (line[0] == '0')
      {
	v->imp_idx[j] = nni++;
	for(i = 0; i < N; i++)
	{
	  gdl_snp_data_set (v, i, j, line[2*(i+1)]);
	}
      }
      else
      {
	v->imp_idx[j] = ni++;

	// set that this SNP is imputed
	gdl_bit_vector_set (v->is_imp, j);

	for(i = k = l = 0; i < N; i++)
	{
	  tok = gdl_string_next_token (line+2, n, &k, &l);
	  if (format->P == 1) // haploid = read directly the Pr(SNP = 1)
	  {
	    x[0] = (double)atof(tok);
	  }
	  else
	  {
	    len = strlen(tok);
	    for(m = 0; m < len; m++)
	    {
	      if (tok[m]==';')
		break;
	    }
	    if (m == len)
	    {
	      GDL_ERROR_VAL (gdl_string_sprintf ("Missing genotype separator for marker %d and individual %d\n", j+1, i+1), GDL_FAILURE, 0);
	    }
	    tok[m] = '\0';
	    x[0] = (double)atof(tok);
	    x[1] = (double)atof(tok+m+1);
	    //printf ("%s ==> %g %g\n", tok, x[0], x[1]);
	  }
	  gdl_snp_data_iset (v, i, j, x);
	  gdl_string_free (tok);
	}
      }
      gdl_string_free (line);
      line=0;
      j++;
    }
    GDL_FREE (x);
  }  // end of format->imputed
  
  else
  {
    offset = ftell (stream);

    gdl_snp_data_fscanf_dim (stream, &N, &L);

    fseek (stream, offset, SEEK_SET);

    if (format->P==1 || !format->haplo)
    {
      v = gdl_snp_data_alloc (gdl_snp_data_genotype, N, L, 0, format->P);
      i=j=0;
      while ((c=fgetc(stream))!=EOF)
      {
	if (c=='\n')
	{
	  i++;
	  j=0;
	}
	else if (!isspace(c))
	{
	  if (c == (int)format->na_char)
	  {
	    gdl_snp_data_set (v, i, j, (unsigned char)'9');
	  }
	  else
	  {
	    gdl_snp_data_set (v, i, j, c);
	  }
	  j++;
	}
      }
    }
    else if (N%2==0)
    {
      v = gdl_snp_data_alloc (gdl_snp_data_haplotype, N/2, L, 0, format->P);
      i=j=k=0;
      while ((c=fgetc(stream))!=EOF)
      {
	if (c=='\n')
	{
	  if (k) {k=0;i++;}
	  else k++;
	  j=0;
	}
	else if (!isspace(c))
	{
	  if (c == (int)format->na_char)
	  {
	    gdl_snp_data_hset (v, i, j, k, (unsigned char)'9');
	  }
	  else
	  {
	    gdl_snp_data_hset (v, i, j, k, c);
	  }
	  j++;
	}
      }
    }
    else
    {
      GDL_ERROR_VAL (gdl_string_sprintf ("Expected an even number of rows (haplotype mode) and I got %d\n", N), GDL_FAILURE, 0);
    }
  }  // end of format being genotype or haplotype

  return v;
}

static int
gdl_snp_data_fscanf_impute2_dim (FILE * stream,
				 size_t * nsnps,
				 size_t * nsamples)
{
  int status = 0;
  rewind(stream);
  *nsnps = 0;
  *nsamples = 0;
  
  // read the first line to find the number of samples
  gdl_string * line = NULL;
  size_t n = 0;
  long int ntoks = 0;
  if (gdl_getline(&line, &n, stream) == -1)
  {
    GDL_ERROR_VAL("file with genotypes in IMPUTE2 format is empty", GDL_FAILURE, 0);
  }
  else
  {
    ntoks = gdl_string_token(" ", line);
    if (ntoks <= 5)
    {
      GDL_ERROR_VAL("file with genotypes in IMPUTE2 format have no more than 5 columns", GDL_FAILURE, 0);
    }
    else if ((ntoks - 5) % 3 != 0)
    {
      GDL_ERROR_VAL("file with genotypes in IMPUTE2 format doesn't have 3 values per sample", GDL_FAILURE, 0);
    }
    else
    {
      *nsamples = (ntoks - 5) / 3;
    }
  }
  
  // read the rest of the file to find the number of SNPs
  *nsnps = 1;
  while (gdl_getline(&line, &n, stream) != -1)
  {
    (*nsnps)++;
  }
  
  rewind(stream);
  return 1;
}

/** \brief Read the genotype file in IMPUTE2 format for a given chromosome.
 */
int
gdl_snp_data_fscanf_impute2 (FILE * stream,
			     const gdl_snp_data_format * format,
			     gdl_snp_data ** pop,
			     gdl_snp_map ** chrom)
{
  int status = 0;
  if (stream != NULL)
  {
    size_t nsnps = 0, nsamples = 0;
    (void) gdl_snp_data_fscanf_impute2_dim(stream, &nsnps, &nsamples);
    printf("Samples = %ld, Variants = %ld, Ploidy = %ld\n", nsamples, nsnps, format->P);
    fflush (stdout);
    
    size_t n = 0, snp_id = 0, geno_id = 0, k = 0, l = 0;
    if (format->P != 2)
    {
      GDL_ERROR("a ploidy different than 2 is not compatible with the IMPUTE2 format",
		GDL_FAILURE);
    }
    double * probas = GDL_MALLOC(double, format->P);
    gdl_string * line = NULL, * tok = NULL, * rs = NULL, * coord = NULL,
      * allele0 = NULL, * allele1 = NULL;
    gdl_snp * snp = NULL;
    *pop = gdl_snp_data_alloc(gdl_snp_data_imputed, nsamples, nsnps, nsnps, format->P);
    *chrom = gdl_snp_map_alloc(nsnps);
    
    while (gdl_getline(&line, &n, stream) != -1)
    {
      k = l = 0;
      tok = gdl_string_next_token(line, n, &k, &l);  // skip SNP_ID
      gdl_string_free(tok);
      tok = gdl_string_next_token(line, n, &k, &l);  // get RS_ID
      if (tok == NULL)
      {
	GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, SNP name is missing", snp_id+1),
		      GDL_FAILURE, 0);
      }
      else
      {
	rs = gdl_string_clone(tok);
      }
      gdl_string_free (tok);
      tok = gdl_string_next_token(line, n, &k, &l);  // get coordinate
      if (tok == NULL)
      {
	GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, SNP coordinate is missing", snp_id+1),
		      GDL_FAILURE, 0);
      }
      else
      {
	coord = gdl_string_clone(tok);
      }
      gdl_string_free (tok);
      tok = gdl_string_next_token(line, n, &k, &l);  // get first allele
      if (tok == NULL)
      {
	GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, the first allele is missing", snp_id+1),
		      GDL_FAILURE, 0);
      }
      else
      {
	allele0 = gdl_string_clone(tok);
      }
      gdl_string_free (tok);
      tok = gdl_string_next_token(line, n, &k, &l);  // get second allele
      if (tok == NULL)
      {
	GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, the second allele is missing", snp_id+1),
		      GDL_FAILURE, 0);
      }
      else
      {
	allele1 = gdl_string_clone(tok);
      }
      gdl_string_free (tok);
      
      snp = gdl_snp_alloc(rs, allele0, allele1, atol(coord));
      gdl_snp_map_set((*chrom), snp_id, snp);
      
      for(geno_id = 0; geno_id < nsamples; geno_id++)
      {
	tok = gdl_string_next_token(line, n, &k, &l);  // read proba of being homozygous for the first allele
	if (tok == NULL)
	{
	  GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, genotype at column %ld is missing.\nThis is usually due to extra space at the end of the line.\nPlease remove those first.\n", snp_id+1, geno_id+1),
			GDL_FAILURE, 0);
	}
	else
	{
	  probas[0] = (double) atof(tok);
	}
	gdl_string_free(tok);
	tok = gdl_string_next_token(line, n, &k, &l);  // skip proba of being heterozygous
	if (tok == NULL)
	{
	  GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, genotype at column %ld is missing.\nThis is usually due to extra space at the end of the line.\nPlease remove those first.\n", snp_id+1, geno_id+1),
			GDL_FAILURE, 0);
	}
	gdl_string_free(tok);
	tok = gdl_string_next_token(line, n, &k, &l);  // read proba of being homozygous for the second allele
	if (tok == NULL)
	{
	  GDL_ERROR_VAL(gdl_string_sprintf("in line %ld, genotype at column %ld is missing.\nThis is usually due to extra space at the end of the line.\nPlease remove those first.\n", snp_id+1, geno_id+1),
			GDL_FAILURE, 0);
	}
	else
	{
	  probas[1] = (double) atof(tok);
	}
	gdl_string_free(tok);
	(*pop)->imp_idx[snp_id] = snp_id;
	gdl_bit_vector_set((*pop)->is_imp, snp_id);
	gdl_snp_data_iset(*pop, geno_id, snp_id, probas);
      }
      
      gdl_string_free(line);
      line = NULL;
      snp_id++;
    }
    GDL_FREE(probas);
    status = 1;
  }
  return status;
}

static int
gdl_snp_map_fscanf_dim (FILE * stream, size_t * N)
{
  int c;

  *N=0;

  while ((c=fgetc(stream))!=EOF)
  {
    if (c=='\n')
    {
      (*N)++;
    }
  }
}

gdl_snp_map *
gdl_snp_map_fscanf (FILE * stream)
{
  if (stream)
  {
    int c;
    size_t i, j, n, s, N;
    long offset;
    gdl_string * line = 0;
    gdl_string * rs, * pos, * allele0, * allele1;
    gdl_snp_map * chrom;
    gdl_snp * snp;

#define NEXT_TOKEN {for (j=i;isspace(line[j]) && j<n;j++);	\
      for (i=j;!isspace(line[i]) && i<n;i++);}

    offset = ftell (stream);

    gdl_snp_map_fscanf_dim (stream, &N);

    fseek (stream, offset, SEEK_SET);

    chrom = gdl_snp_map_alloc (N);

    s=i=j=0;
    while(gdl_getline (&line, &n, stream)!=-1)
    {
      NEXT_TOKEN
	rs = gdl_string_alloc (i);
      strncpy (rs, line, i);
      NEXT_TOKEN
	pos = gdl_string_alloc (i-j);
      strncpy (pos, &line[j], i-j);
      NEXT_TOKEN
	allele0 = gdl_string_alloc (i-j);
      strncpy (allele0, &line[j], i-j);
      NEXT_TOKEN
	allele1 = gdl_string_alloc (i-j);
      strncpy (allele1, &line[j], i-j);

      snp = gdl_snp_alloc (rs, allele0, allele1, atol(pos));
      gdl_snp_map_set (chrom, s, snp);

      GDL_FREE (pos);
      GDL_FREE (line);
      line=0;
      i=j=0;
      s++;
    }
    return chrom;
  }
  return 0;

#undef NEXT_TOKEN

}

gdl_snp_map *
gdl_snp_map_fscanf_bimbam (FILE * stream)
{
  if (stream)
  {
    int c;
    size_t i, j, n, s, N;
    long offset;
    gdl_string * line = 0;
    gdl_string * rs, * pos, * allele0, * allele1;
    gdl_snp_map * chrom;
    gdl_snp * snp;

#define NEXT_TOKEN {for (j=i;isspace(line[j]) && j<n;j++);	\
      for (i=j;!isspace(line[i]) && i<n;i++);}

    offset = ftell (stream);

    gdl_snp_map_fscanf_dim (stream, &N);

    N -= 2; // skip 2 lines header

    fseek (stream, offset, SEEK_SET);

    chrom = gdl_snp_map_alloc (N);

    s=i=j=0;
    while(gdl_getline (&line, &n, stream)!=-1)
    {
      if (s < 2)
      {
	s++;
	GDL_FREE (line);
	line=0;
	continue;
      }
      NEXT_TOKEN
	rs = gdl_string_alloc (i);
      strncpy (rs, line, i);
      NEXT_TOKEN
	allele0 = gdl_string_alloc (i-j);
      strncpy (allele0, &line[j], i-j);
      NEXT_TOKEN
	allele1 = gdl_string_alloc (i-j);
      strncpy (allele1, &line[j], i-j);
      NEXT_TOKEN
	NEXT_TOKEN
	NEXT_TOKEN
	pos = gdl_string_alloc (i-j);
      strncpy (pos, &line[j], i-j);

      snp = gdl_snp_alloc (rs, allele0, allele1, atol(pos));

      gdl_snp_map_set (chrom, s-2, snp);

      GDL_FREE (pos);
      GDL_FREE (line);
      line=0;
      i=j=0;
      s++;
    }

    return chrom;
  }

  return 0;

#undef NEXT_TOKEN

}

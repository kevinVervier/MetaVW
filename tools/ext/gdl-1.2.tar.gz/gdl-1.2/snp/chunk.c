/*
 *  snp/chunk.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:27 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_snp_map.h>
#include <gdl/gdl_snp_data.h>
#include <gdl/gdl_snp_chromosome.h>


gdl_snp_chromosome_split_into_chunk *
gdl_snp_chromosome_chunk_alloc(const gdl_snp_chromosome * c, const size_t nchunk)
{
	gdl_snp_chromosome_split_into_chunk * ch;

	ch = GDL_CALLOC (gdl_snp_chromosome_split_into_chunk, 1);

	ch->size     = nchunk;
	ch->starts   = GDL_MALLOC (long, nchunk);
	ch->ends     = GDL_MALLOC (long, nchunk);
    ch->snp_from = GDL_MALLOC (size_t, nchunk);
    ch->snp_to   = GDL_MALLOC (size_t, nchunk);

    int i, j;
    const size_t N  = c->chrom->size;
    long L0   = c->chrom->snps[0]->position;
    long L    = (c->chrom->snps[N-1]->position-L0);
    long step = L / nchunk + L % nchunk; // assume L >> nchunk so L % nchunk = nchunk - 1 is not a big deal

    //printf ("NSNP = %d SIZE = %d NCHUNK = %d (step = %d)\n", N, L, nchunk, step);

    for(i = j = 0; i < nchunk; i++)
    {
    	ch->starts[i]   = L0-1;
    	ch->ends[i]     = L0 + step;
    	ch->snp_from[i] = j;
    	for(; j < N && c->chrom->snps[j]->position <= ch->ends[i]; j++);
    	ch->snp_to[i]   = j-1;
    	L0 += step+1;
    	//printf ("CHUNK %d START=%d END=%d (%d, %d)\n", i, ch->starts[i], ch->ends[i], ch->snp_from[i], ch->snp_to[i]);
    }

	return ch;
}

void
gdl_snp_chromosome_chunk_free (gdl_snp_chromosome_split_into_chunk * c)
{
	if (c)
	{
		GDL_FREE (c->starts);
		GDL_FREE (c->ends);
		GDL_FREE (c->snp_from);
		GDL_FREE (c->snp_to);
		GDL_FREE (c);
	}
}

int
gdl_snp_chromosome_chunk_which (const gdl_snp_chromosome_split_into_chunk * c, const long position)
{
	size_t i;
	for(i = 0; i < c->size; i++)
	{
		if (position > c->starts[i] && position <= c->ends[i])
		{
			return i;
		}
		else if (position < c->starts[i])
		{
			break;
		}
	}

	return -1;
}

/*
 *  snp/data.c
 *
 *  $Author: tflutre $, $Date: 2011/09/28 22:15:53 $, $Revision: 1.3 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_bit_vector.h>
#include <gdl/gdl_snp_data.h>

gdl_snp_data *
gdl_snp_data_alloc (const gdl_snp_data_type * T,
                    const size_t N, // number of individuals
                    const size_t L, // total number of snps (non imputed + imputed)
                    const size_t I, // number of imputed snps
                    const size_t P) // ploidy
{
  gdl_snp_data * v;

  v = GDL_CALLOC (gdl_snp_data, 1);

  v->T = T;
  v->N = N;
  v->L = L;
  v->P = P;
  if (T == gdl_snp_data_genotype)
  {
    v->data = GDL_CALLOC (unsigned char, N*L);
    v->data_stride = L;
  }
  else if (T == gdl_snp_data_haplotype)
  {
    v->data = GDL_CALLOC (unsigned char, N*L*P);
    v->data_stride = L*P;
  }
  else if (T == gdl_snp_data_imputed)
  {
    v->data          = GDL_CALLOC (unsigned char, N*(L-I));
    v->data_stride   = L-I;
    v->imp_stride    = P*I;
    v->is_imp        = gdl_bit_vector_alloc (L);
    v->imp_idx       = GDL_CALLOC (size_t, L);
    v->imp_data      = GDL_CALLOC (short int, N*v->imp_stride);
    v->imp_precision = 1000;
  }
  else if (T == gdl_snp_data_dose)
  {
    v->imp_stride    = L;
    v->imp_data      = GDL_CALLOC (short int, N*v->imp_stride);
    v->imp_precision = 1000;
  }
  return v;
}

void
gdl_snp_data_free (gdl_snp_data * v)
{
  if (v)
  {
    GDL_FREE (v->data);
    gdl_bit_vector_free (v->is_imp);
    GDL_FREE (v->imp_idx);
    GDL_FREE (v->imp_data);
    GDL_FREE (v);
  }
}

gdl_boolean
gdl_snp_data_is_missing (const gdl_snp_data * v, size_t i, size_t j)
{
  if (v->T == gdl_snp_data_imputed)
  {
    if (gdl_bit_vector_get(v->is_imp,j))
    {
      if (gdl_isnan(v->imp_data[i*v->imp_stride+v->imp_idx[j]]))
	return gdl_true;
      else
	return gdl_false;
    }
    else
    {
      return (v->data[i*v->data_stride+v->imp_idx[j]]=='9') ? gdl_true : gdl_false;
    }
  }
  else if (v->T == gdl_snp_data_dose)
  {
    if (v->imp_data[i*v->imp_stride+j]==0)
      return gdl_true;
    else
      return gdl_false;
  }
  else if (v->T == gdl_snp_data_genotype)
  {
    return (v->data[i*v->L+j]=='9') ? gdl_true : gdl_false;
  }
  else if (v->T == gdl_snp_data_haplotype)
  {
    return gdl_false;
  }
  else
  {
    return gdl_true;
  }
}

/** \brief Return the given genotype at the given SNP.
 *
 *  \param i index of the genotype
 *  \param j index of the SNP
 *  \return the genotype as an int, GDL_FAILURE if it is imputed
 *          or in the dose format
 */
int
gdl_snp_data_get (const gdl_snp_data * v, size_t i, size_t j)
{
  if (v->T == gdl_snp_data_genotype)
  {
    switch (v->data[i*v->L+j])
    {
    case '0':
      return 0;
    case '1':
      return 1;
    case '2':
      return 2;
    default:
      return -1;
    }
  }
  else if (v->T == gdl_snp_data_haplotype)
  {
    size_t k,a = 0;
    for(k = 0; k < v->P; k++)
    {
      switch (v->data[i*(v->L*v->P)+j*v->P+k])
      {
      case '1':
	a++;
	break;
      case '2':
	return -1;
      }
    }
    return a;
  }
  else
  {
    GDL_ERROR_VAL ("gdl_snp_data_get is not available in imputed/dose mode", GDL_FAILURE, 0);
  }
}

/**
 * Allelic dose
 */
double
gdl_snp_data_xget (const gdl_snp_data * v, size_t i, size_t j)
{
  if (gdl_snp_data_is_missing (v, i, j))
  {
    return GDL_NAN;
  }
  if (v->T == gdl_snp_data_dose)
  {
    return ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision;
  }

  size_t k;
  double a = 0;

  if (v->T == gdl_snp_data_genotype)
  {
    switch (v->data[i*v->L+j])
    {
    case '0':
      return 0.0;
    case '1':
      return 1.0;
    case '2':
      return 2.0;
    }
  }
  else if (v->T == gdl_snp_data_haplotype)
  {
    for(k = 0; k < v->P; k++)
    {
      if (v->data[i*(v->L*v->P)+j*v->P+k] == '1')
      {
	a+=1.0;
      }
    }
    return a;
  }
  else if (v->T == gdl_snp_data_imputed)
  {
    size_t jj = v->imp_idx[j];
    if (gdl_bit_vector_get(v->is_imp,j))
    {
      a  = (v->P)*((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision;
      if (v->P == 2)
      {
	// heterozygote
	a += 1.0-(((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision+((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
      }
      return a;
    }
    else
    {
      switch (v->data[i*v->data_stride+jj])
      {
      case '2':
	return 2.0;
      case '1':
	return 1.0;
      }
    }
  }
}

/**
 * Allelic dose + Dominance term
 */
void
gdl_snp_data_addom_get (const gdl_snp_data * v, size_t i, size_t j, double *a, double *d)
{
  if (gdl_snp_data_is_missing (v, i, j))
  {
    *a=*d=GDL_NAN;
  }
  size_t k;

  *a = *d = 0;

  if (v->T == gdl_snp_data_dose)
  {
    *a = ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision;
    *d = 0;
  }
  else if (v->T == gdl_snp_data_genotype)
  {
    switch (v->data[i*v->L+j])
    {
    case '1':
      *a=1.0;
      *d=v->P-1;
      break;
    case '2':
      *a=2;
      break;
    }
    return;
  }
  else if (v->T == gdl_snp_data_haplotype)
  {
    for(k = 0; k < v->P; k++)
    {
      if (v->data[i*(v->L*v->P)+j*v->P+k] == '1')
      {
	(*a)+=1.0;
      }
    }
    if (*a==1.0)
    {
      *d=1.0;
    }
    return;
  }
  else if (v->T == gdl_snp_data_imputed)
  {
    size_t jj = v->imp_idx[j];
    if (gdl_bit_vector_get(v->is_imp,j))
    {
      *a = (v->P)*((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision;
      if (v->P == 2)
      {
	*d = 1.0-(((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision+((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
	*a += *d;
      }
      return;
    }
    else
    {
      switch (v->data[i*v->data_stride+jj])
      {
      case '1':
	*a=1.0;
	*d=v->P-1;
	break;
      case '2':
	*a=2.0;
	break;
      }
      return;
    }
  }
}

/**
 * Allelic dose
 */
void
gdl_snp_data_add_get (const gdl_snp_data * v, size_t i, size_t j, double *a)
{
  if (gdl_snp_data_is_missing (v, i, j))
  {
    *a=GDL_NAN;
  }
  size_t k;
  
  *a = 0;
  
  if (v->T == gdl_snp_data_dose)
  {
    *a = ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision;
  }
  else if (v->T == gdl_snp_data_genotype)
  {
    switch (v->data[i*v->L+j])
    {
    case '1':
      *a=1.0;
      break;
    case '2':
      *a=2;
      break;
    }
    return;
  }
  else if (v->T == gdl_snp_data_haplotype)
  {
    for(k = 0; k < v->P; k++)
    {
      if (v->data[i*(v->L*v->P)+j*v->P+k] == '1')
      {
	(*a)+=1.0;
      }
    }
    return;
  }
  else if (v->T == gdl_snp_data_imputed)
  {
    size_t jj = v->imp_idx[j];
    if (gdl_bit_vector_get(v->is_imp,j))
    {
      *a = (v->P)*((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision;
      if (v->P == 2)
      {
	double d = 1.0-(((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision+((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
	*a += d;
      }
      return;
    }
    else
    {
      switch (v->data[i*v->data_stride+jj])
      {
      case '1':
	*a=1.0;
	break;
      case '2':
	*a=2.0;
	break;
      }
      return;
    }
  }
}

// Diploid x[1..2] = Pr(1/1) Pr(1/0 or 0/1) Pr(0/0)
// Haploid x[1..1] = Pr(1) Pr(0)
void
gdl_snp_data_iget (const gdl_snp_data * v, size_t i, size_t j, double x[])
{
  if (v->T == gdl_snp_data_imputed)
  {
    size_t k;
    size_t jj = v->imp_idx[j];

    if (gdl_snp_data_is_missing (v, i, j))
    {
      for(k = 0; k < v->P+1; k++)
      {
	x[k] = GDL_NAN;
      }
      return;
    }
    for(k = 0; k < v->P+1; k++)
    {
      x[k] = 0;
    }
    if (gdl_bit_vector_get(v->is_imp,j))
    {
      // 1/1 0/0
      for(k = 0; k < v->P; k++)
      {
	x[k] = ((double)v->imp_data[i*v->imp_stride+jj*v->P+k])/v->imp_precision;
      }
      if (v->P == 2)
      {
	x[2] = x[1];
	x[1] = 1.0 - (x[0] + x[2]);
      }
    }
    else
    {
      switch (v->data[i*v->data_stride+jj])
      {
      case '0':
	x[v->P]=1.0;
	break;
      case '2':
	x[0]=1.0;
	break;
      case '1':
	x[v->P-1]=1.0;
	break;
      }
    }
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_get is available only in imputed mode", GDL_FAILURE);
  }
}

int
gdl_snp_data_hget (const gdl_snp_data * v, size_t i, size_t j, size_t k)
{
  if (v->T != gdl_snp_data_haplotype)
  {
    GDL_ERROR_VAL ("gdl_snp_data_hget is only available in haplotype mode", GDL_FAILURE, 0);
  }
  else
  {
    switch (v->data[i*(v->L*v->P)+j*v->P+k])
    {
    case '0':
      return 0;
    case '1':
      return 1;
    default :
      return -1;
    }
  }
}

void
gdl_snp_data_set (const gdl_snp_data * v, size_t i, size_t j, unsigned char u)
{
  if (v->T == gdl_snp_data_genotype)
  {
    v->data[i*v->L+j]=u;
  }
  else if (v->T == gdl_snp_data_imputed)
  {
    size_t k, jj = v->imp_idx[j];
    if (gdl_bit_vector_get (v->is_imp, j))
    {
      for(k = 0; k < v->P; k++)
      {
	v->imp_data[i*v->imp_stride+jj+k] = 0;
      }
      switch(u)
      {
      case '0':
	if (v->P==2)
	{
	  v->imp_data[i*v->imp_stride+jj+1] = v->imp_precision;
	}
	break;
      case '1':
	if (v->P==1)
	{
	  v->imp_data[i*v->imp_stride+jj] = v->imp_precision;
	}
	break;
      case '2':
	if (v->P==2)
	{
	  v->imp_data[i*v->imp_stride+jj] = v->imp_precision;
	}
	break;
      }
    }
    else
    {
      v->data[i*v->data_stride+jj] = u;
    }
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_set is only available in genotype mode", GDL_FAILURE);
  }
}

void
gdl_snp_data_iset (const gdl_snp_data * v, size_t i, size_t j, const double x[])
{
  if (v->T == gdl_snp_data_imputed)
  {
    if (gdl_bit_vector_get (v->is_imp, j))
    {
      size_t k, jj = v->imp_idx[j];
      for(k = 0; k < v->P; k++)
      {
	v->imp_data[i*v->imp_stride+jj*v->P+k] = (short int) floor(x[k]*v->imp_precision);
      }
    }
    else
    {
      GDL_ERROR_VOID ("gdl_snp_data_iset is only available for imputed markers", GDL_FAILURE);
    }
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_iset is only available in imputed mode", GDL_FAILURE);
  }
}

void
gdl_snp_data_xset (const gdl_snp_data * v, size_t i, size_t j, const double x)
{
  if (v->T == gdl_snp_data_dose)
  {
    v->imp_data[i*v->imp_stride+j] = (short int) floor(x*v->imp_precision) + 1;
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_xset is only available in dose mode", GDL_FAILURE);
  }
}

void
gdl_snp_data_xmissing (gdl_snp_data * v, size_t i, size_t j)
{
  if (v->T == gdl_snp_data_dose)
  {
    v->imp_data[i*v->imp_stride+j] = 0;
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_xset is only available in dose mode", GDL_FAILURE);
  }
}

void
gdl_snp_data_hset (const gdl_snp_data * v, size_t i, size_t j, size_t k, unsigned char u)
{
  if (v->T == gdl_snp_data_haplotype)
  {
    v->data[i*(v->L*v->P)+j*v->P+k]=u;
  }
  else
  {
    GDL_ERROR_VOID ("gdl_snp_data_hset is only available in haplotype mode", GDL_FAILURE);
  }
}

void
gdl_snp_data_sample_copy (gdl_snp_data * dest, const size_t di, const gdl_snp_data * src, const size_t si)
{
  if ((src->L != dest->L) || (src->P != dest->P))
  {
    GDL_ERROR_VOID ("SNP dataset must have the same number of markers and the same ploidy", GDL_EINVAL);
  }
  if (src->T == gdl_snp_data_haplotype)
  {
    memcpy(&dest->data[di*(dest->L*dest->P)], &src->data[si*(src->L*src->P)], sizeof(unsigned char)*(dest->L*dest->P));
  }
  else if (src->T == gdl_snp_data_genotype)
  {
    memcpy(&dest->data[di*(dest->L)], &src->data[si*(src->L)], sizeof(unsigned char)*(dest->L));
  }
  else if (src->T == gdl_snp_data_imputed)
  {
    memcpy(&dest->imp_data[di*dest->imp_stride], &src->imp_data[si*src->imp_stride], sizeof(short int)*(src->imp_stride));
    memcpy(&dest->data[di*dest->data_stride], &src->data[si*src->data_stride], sizeof(unsigned char)*(src->data_stride));
  }
  else if (src->T == gdl_snp_data_dose)
  {
    memcpy(&dest->imp_data[di*dest->imp_stride], &src->imp_data[si*src->imp_stride], sizeof(short int)*(src->imp_stride));
  }
}

int
gdl_snp_data_genotype_fprintf (FILE * stream, const gdl_snp_data * v, const size_t i, const size_t j)
{
  if (gdl_snp_data_is_missing (v, i, j))
  {
    fprintf (stream, "?");
    return GDL_SUCCESS;
  }
  if (v->T == gdl_snp_data_dose)
  {
    fprintf (stream, "%.3f", ((double)v->imp_data[i*v->imp_stride+j]-1)/v->imp_precision);
  }
  else if (v->T == gdl_snp_data_imputed)
  {
    size_t jj = v->imp_idx[j];
    if (gdl_bit_vector_get (v->is_imp, j))
    {
      if (v->P == 1)
      {
	fprintf (stream, "%1.4f", ((double)v->imp_data[i*v->imp_stride+jj])/v->imp_precision);
      }
      else if (v->P == 2)
      {
	fprintf (stream, "%1.4f;%1.4f", ((double)v->imp_data[i*v->imp_stride+jj*v->P])/v->imp_precision, ((double)v->imp_data[i*v->imp_stride+jj*v->P+1])/v->imp_precision);
      }
    }
    else
    {
      fprintf (stream, "%c", v->data[i*v->data_stride+jj]);
    }
  }
  else
  {
    fprintf (stream, "%d", gdl_snp_data_get (v, i, j));
  }

  return GDL_SUCCESS;
}

const static gdl_snp_data_type _gdl_snp_data_genotype =
{
  "g"
};

const static gdl_snp_data_type _gdl_snp_data_haplotype =
{
  "h"
};

const static gdl_snp_data_type _gdl_snp_data_imputed =
{
  "i"
};

const static gdl_snp_data_type _gdl_snp_data_dose =
{
  "d"
};

const gdl_snp_data_type * gdl_snp_data_genotype  = &_gdl_snp_data_genotype;
const gdl_snp_data_type * gdl_snp_data_haplotype = &_gdl_snp_data_haplotype;
const gdl_snp_data_type * gdl_snp_data_imputed   = &_gdl_snp_data_imputed;
const gdl_snp_data_type * gdl_snp_data_dose      = &_gdl_snp_data_dose;

/*
 *  snp/gdl_snp_data.h
 *
 *  $Author: tflutre $, $Date: 2011/09/28 22:16:50 $, $Revision: 1.3 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#ifndef __GDL_SNP_DATA_H__
#define __GDL_SNP_DATA_H__

#include <stdio.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_bit_vector.h>
#include <gdl/gdl_snp_map.h>

__BEGIN_DECLS

typedef struct
{
	double * afreq;
	double * gfreq;
	size_t missing;
} gdl_snp_stats;

gdl_snp_stats * gdl_snp_stats_alloc (void);
void gdl_snp_stats_free (gdl_snp_stats * s);
void gdl_snp_stats_reset (gdl_snp_stats * s);

typedef struct
{
	size_t P;
	char na_char;
	gdl_boolean label;
	gdl_boolean haplo;
	gdl_boolean imputed;
	gdl_boolean dose;
	gdl_boolean bimbam;
	gdl_boolean impute2;
} gdl_snp_data_format;

gdl_snp_data_format * gdl_snp_data_format_alloc (const size_t P);
void gdl_snp_data_format_free (gdl_snp_data_format * f);

typedef struct
{
	gdl_string * name;
} gdl_snp_data_type;

GDL_VAR const gdl_snp_data_type * gdl_snp_data_genotype;
GDL_VAR const gdl_snp_data_type * gdl_snp_data_haplotype;
GDL_VAR const gdl_snp_data_type * gdl_snp_data_imputed;
GDL_VAR const gdl_snp_data_type * gdl_snp_data_dose;

typedef struct
{
	size_t N;
	size_t L;
	size_t P;
	const gdl_snp_data_type * T;
	size_t data_stride;
	unsigned char * data;
	gdl_bit_vector * is_imp;
	size_t imp_stride;
	size_t * imp_idx;
	short int * imp_data;
	unsigned int imp_precision; // e.g. 10, 100, 1000, 10000
} gdl_snp_data;

gdl_snp_data * gdl_snp_data_alloc (const gdl_snp_data_type * T, const size_t N, const size_t L, const size_t I, const size_t P);
void gdl_snp_data_free (gdl_snp_data * v);

gdl_boolean gdl_snp_data_is_missing (const gdl_snp_data * v, size_t i, size_t j);
double gdl_snp_data_xget (const gdl_snp_data * v, size_t i, size_t j);
int gdl_snp_data_get (const gdl_snp_data * v, size_t i, size_t j);
int gdl_snp_data_hget (const gdl_snp_data * v, size_t i, size_t j, size_t k);
void gdl_snp_data_iget (const gdl_snp_data * v, size_t i, size_t j, double x[]);
void gdl_snp_data_addom_get (const gdl_snp_data * v, size_t i, size_t j, double *a, double *d);
void gdl_snp_data_add_get (const gdl_snp_data * v, size_t i, size_t j, double *a);
void gdl_snp_data_set (const gdl_snp_data * v, size_t i, size_t j, unsigned char u);
void gdl_snp_data_hset (const gdl_snp_data * v, size_t i, size_t j, size_t k, unsigned char u);
void gdl_snp_data_iset (const gdl_snp_data * v, size_t i, size_t j, const double x[]);
void gdl_snp_data_xset (const gdl_snp_data * v, size_t i, size_t j, const double x);
void gdl_snp_data_xmissing (gdl_snp_data * v, size_t i, size_t j);
void gdl_snp_data_snp_stats (const gdl_snp_data * v, size_t i, gdl_snp_stats * s);

gdl_snp_data * gdl_snp_data_fread (FILE * stream);
gdl_snp_data * gdl_snp_data_fscanf (FILE * stream, const gdl_snp_data_format * T);
int gdl_snp_data_fwrite (FILE * stream, const gdl_snp_data * v);
int gdl_snp_data_fprintf (FILE * stream, const gdl_snp_data * v, const gdl_boolean dose_format);
int gdl_snp_data_genotype_fprintf (FILE * stream, const gdl_snp_data * v, const size_t i, const size_t j);

void gdl_snp_data_sample_copy (gdl_snp_data * dest, const size_t di, const gdl_snp_data * src, const size_t si);

int
gdl_snp_data_fscanf_impute2 (FILE * stream,
			     const gdl_snp_data_format * format,
			     gdl_snp_data ** pop,
			     gdl_snp_map ** chrom);

__END_DECLS

#endif

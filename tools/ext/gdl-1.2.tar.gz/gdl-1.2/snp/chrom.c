/*
 *  snp/chrom.c
 *
 *  $Author: tflutre $, $Date: 2011/10/18 16:55:13 $, $Revision: 1.8 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_sort_long.h>
#include <gdl/gdl_snp_map.h>
#include <gdl/gdl_snp_data.h>
#include <gdl/gdl_snp_chromosome.h>

typedef struct
{
  size_t i;
  size_t j;
} var_status;

static void
gdl_snp_map_pop_merge (gdl_snp_chromosome * cv,
		       const gdl_snp_map * c2,
		       const size_t p)
{
  size_t i=0, j=0, n=0;
  gdl_snp_map * c1;
  gdl_snp ** tmp;
  size_t  * posx, ** idx;
  long    * pos;
  gdl_hashtable * hash;

  c1 = cv->chrom;

  hash = gdl_hashtable_alloc (gdl_hash_default, 0);
  for (i = 0; i < c1->size; i++)
  {
    var_status * st = GDL_CALLOC (var_status, 1);
    st->i = i+1;
    gdl_hashtable_add (hash, c1->snps[i]->rs, st, 1);
  }
  for (j = 0; j < c2->size; j++)
  {
    var_status * st = gdl_hashtable_lookup(hash, c2->snps[j]->rs);
    if (!st)
    {
      st    = GDL_CALLOC (var_status, 1);
      st->j = j+1;
      gdl_hashtable_add (hash, c2->snps[j]->rs, st, 1);
    }
    else
    {
      st->j = j+1;
    }
  }

  n = gdl_hashtable_size (hash);

  if (!n)
  {
    return;
  }

  tmp  = GDL_MALLOC (gdl_snp *, n);
  idx  = GDL_MALLOC (size_t  *, n);
  pos  = GDL_MALLOC (long, n);
  posx = GDL_MALLOC (size_t, n);

  gdl_hashtable_itr * hitr = gdl_hashtable_iterator (hash);
  n=0;
  do
  {
    var_status * st = (var_status *)gdl_hashtable_iterator_value (hitr);
    if (st->i && st->j) // seen in both
    {
      tmp[n] = c1->snps[st->i-1];
      if (p > 1)
      {
	idx[n] = cv->idx[st->i-1];
      }
      else
      {
	idx[n]    = GDL_CALLOC (size_t, cv->npop);
	idx[n][0] = st->i;
      }
      idx[n][p] = st->j;
    }
    else if (st->i) // seen only in c1
    {
      tmp[n] = c1->snps[st->i-1];
      if (p > 1)
      {
	idx[n] = cv->idx[st->i-1];
      }
      else
      {
	idx[n]    = GDL_CALLOC (size_t, cv->npop);
	idx[n][0] = st->i;
      }
      tmp[n]->polypop = 'n';
    }
    else  // seen only in c2
    {
      tmp[n]    = gdl_snp_clone (c2->snps[st->j-1]);
      idx[n]    = GDL_CALLOC (size_t, cv->npop);
      idx[n][p] = st->j;
      tmp[n]->polypop = 'n';
    }
    pos[n] = tmp[n]->position;
    n++;
  }
  while(gdl_hashtable_iterator_next (hitr));

  gdl_hashtable_iterator_free (hitr);

  // SORT THE SNPS
  gdl_sort_long_index (posx, pos, 1, n);

  GDL_FREE (cv->idx);
  GDL_FREE (c1->snps);

  c1->size = n;
  c1->snps = GDL_MALLOC (gdl_snp *, n);
  cv->idx  = GDL_MALLOC (size_t  *, n);

  for(i = 0; i < n; i++)
  {
    c1->snps[i] = tmp[posx[i]];
    cv->idx[i]  = idx[posx[i]];
  }

  GDL_FREE (pos);
  GDL_FREE (posx);
  GDL_FREE (tmp);
  GDL_FREE (idx);
}

gdl_snp_chromosome *
gdl_snp_chromosome_alloc (const gdl_string * name,
			  gdl_string ** popdir,
			  const size_t npop,
			  const gdl_snp_data_format * format)
{
  size_t i;
  FILE * stream;
  gdl_snp_chromosome * v;

  v = GDL_CALLOC (gdl_snp_chromosome, 1);

  v->npop = npop;
  v->pops = GDL_MALLOC (gdl_snp_data *, npop);

  for (i = 0; i < npop; i++)
  {
    gdl_string * file = NULL;
    if (! format->impute2)
    {
      file = (format->bimbam) ? gdl_string_sprintf ("%s/%s.mean.genotype.txt", popdir[i], name) : gdl_string_sprintf ("%s/%s.snp", popdir[i], name);
      stream = gdl_fileopen (file, "r");
      fprintf (stdout, "READ %s %s\n", popdir[i], name);
      v->pops[i] = gdl_snp_data_fscanf (stream, format);
      gdl_fileclose (file, stream);
      gdl_string_free (file);
      file = (format->bimbam) ? gdl_string_sprintf ("%s/%s.snpdata.txt", popdir[i], name) : gdl_string_sprintf ("%s/%s.map", popdir[i], name);
      stream = gdl_fileopen (file, "r");
      if (i)
      {
	gdl_snp_map * tmp = (format->bimbam) ? gdl_snp_map_fscanf_bimbam (stream) : gdl_snp_map_fscanf (stream);
	gdl_snp_map_pop_merge (v, tmp, i);
	gdl_snp_map_free (tmp);
      }
      else
      {
	v->chrom = (format->bimbam) ? gdl_snp_map_fscanf_bimbam (stream) : gdl_snp_map_fscanf (stream);
      }
    }
    else
    {
      file = gdl_string_sprintf("%s/%s.snp", popdir[i], name);
      stream = gdl_fileopen(file, "r");
      fprintf(stdout, "READ %s %s\n", popdir[i], name);
      gdl_snp_data_fscanf_impute2(stream, format, &v->pops[i], &v->chrom);
    }
    gdl_fileclose(file, stream);
    gdl_string_free(file);
  }
  if (npop==1)
  {
    // Create the index (not necessary but for consistency when subsetting)
    v->idx = GDL_MATRIX_ALLOC (size_t, v->chrom->size, 1);
    for(i = 0; i < v->chrom->size; i++)
    {
      v->idx[i][0] = i+1;
    }
  }

  return v;
}

gdl_snp_chromosome *
gdl_snp_chromosome_alloc2 (const gdl_string * name,
			   gdl_string ** dirs,
			   const size_t ndir,
			   gdl_snp_data_format ** formats)
{
  size_t i;
  FILE * stream;
  gdl_snp_chromosome * v;

  v = GDL_CALLOC (gdl_snp_chromosome, 1);

  v->name = gdl_string_clone (name);
  v->npop = ndir;
  v->pops = GDL_MALLOC (gdl_snp_data *, ndir);

  for (i = 0; i < ndir; i++)
  {
    gdl_string * file = (formats[i]->bimbam) ? gdl_string_sprintf ("%s/%s.mean.genotype.txt", dirs[i], name) : gdl_string_sprintf ("%s/%s.snp", dirs[i], name);
    stream = gdl_fileopen (file, "r");
    v->pops[i] = gdl_snp_data_fscanf (stream, formats[i]);
    gdl_fileclose (file, stream);
    stream = gdl_fileopen (file, "r");
    gdl_string_free (file);
    file = (formats[i]->bimbam) ? gdl_string_sprintf ("%s/%s.snpdata.txt", dirs[i], name) : gdl_string_sprintf ("%s/%s.map", dirs[i], name);
    stream = gdl_fileopen (file, "r");
    if (i)
    {
      gdl_snp_map * tmp = (formats[i]->bimbam) ? gdl_snp_map_fscanf_bimbam (stream) : gdl_snp_map_fscanf (stream);
      gdl_snp_map_pop_merge (v, tmp, i);
      gdl_snp_map_free (tmp);
    }
    else
    {
      v->chrom = (formats[i]->bimbam) ? gdl_snp_map_fscanf_bimbam (stream) : gdl_snp_map_fscanf (stream);
    }
    gdl_fileclose (file, stream);
  }
  if (ndir==1)
  {
    // Create the index (not necessary but for consistency when subsetting)
    v->idx = GDL_MATRIX_ALLOC (size_t, v->chrom->size, 1);
    for(i = 0; i < v->chrom->size; i++)
    {
      v->idx[i][0] = i+1;
    }
  }

  return v;
}

void
gdl_snp_chromosome_free (gdl_snp_chromosome * v)
{
  if (v)
  {
    size_t i;
    if (v->idx)
    {
      for (i = 0; i < v->chrom->size; i++)
      {
	GDL_FREE (v->idx[i]);
      }
      GDL_FREE (v->idx);
    }
    for (i = 0; i < v->npop; i++)
    {
      gdl_snp_data_free (v->pops[i]);
    }
    GDL_FREE(v->pops);
    gdl_snp_map_free (v->chrom);
    gdl_string_free (v->name);
    GDL_FREE (v);
  }
}

size_t
gdl_snp_chromosome_nindiv (const gdl_snp_chromosome * v)
{
  size_t i,n=0;
  for(i = 0; i < v->npop; i++)
  {
    n+=v->pops[i]->N;
  }
  return n;
}

int *
gdl_snp_chromosome_get_genotypes (const gdl_snp_chromosome * v,
				  size_t snp,
				  size_t * n)
{
  size_t i,j,k;
  int * G;

  *n = gdl_snp_chromosome_nindiv (v);
  G  = GDL_MALLOC (int, *n);

  for(k = i = 0; i < v->npop; i++)
  {
    if (gdl_snp_chromosome_is_polymorphic (v, i, snp))
    {
      for(j = 0; j < v->pops[j]->N; j++, k++)
	G[k]=gdl_snp_chromosome_get_genotype (v, i, j, snp);
    }
    else
    {
      for(j = 0; j < v->pops[j]->N; j++, k++)
	G[k]=-1;
    }
  }

  return G;
}

int
gdl_snp_chromosome_get_genotype (const gdl_snp_chromosome * v,
				 size_t pop,
				 size_t indiv,
				 size_t snp)
{
  if (v->idx && v->idx[snp][pop])
  {
    return gdl_snp_data_get (v->pops[pop], indiv, v->idx[snp][pop]-1);
  }
  else if (!v->idx)
  {
    return gdl_snp_data_get (v->pops[pop], indiv, snp);
  }
  return -1;
}

void
gdl_snp_chromosome_get_adddom (const gdl_snp_chromosome * v,
			       size_t pop,
			       size_t indiv,
			       size_t snp,
			       double * a,
			       double * b)
{
  if (v->idx && v->idx[snp][pop])
  {
    gdl_snp_data_addom_get (v->pops[pop], indiv, v->idx[snp][pop]-1, a, b);
  }
  else if (!v->idx)
  {
    gdl_snp_data_addom_get (v->pops[pop], indiv, snp, a, b);
  }
}

void gdl_snp_chromosome_get_add (const gdl_snp_chromosome * v, size_t pop,
				 size_t indiv, size_t snp, double * a)
{
  if (v->idx && v->idx[snp][pop])
  {
    gdl_snp_data_add_get(v->pops[pop], indiv, v->idx[snp][pop]-1, a);
  }
  else if (!v->idx)
  {
    gdl_snp_data_add_get(v->pops[pop], indiv, snp, a);
  }
}

int
gdl_snp_chromosome_get_haplotype (const gdl_snp_chromosome * v,
				  size_t pop,
				  size_t indiv,
				  size_t snp,
				  size_t k)
{
  if (v->idx && v->idx[snp][pop])
  {
    return gdl_snp_data_hget (v->pops[pop], indiv, v->idx[snp][pop]-1, k);
  }
  else if (!v->idx)
  {
    return gdl_snp_data_hget (v->pops[pop], indiv, snp, k);
  }
  return -1;
}

gdl_boolean
gdl_snp_chromosome_is_polymorphic (const gdl_snp_chromosome * v,
				   size_t pop,
				   size_t snp)
{
  if ((v->idx && v->idx[snp][pop]) || !v->idx)
    return gdl_true;
  else
    return gdl_false;
}

gdl_boolean
gdl_snp_chromosome_is_missing (const gdl_snp_chromosome * v,
			       size_t pop,
			       size_t indiv,
			       size_t snp)
{
  if (v->idx && v->idx[snp][pop])
  {
    return gdl_snp_data_is_missing (v->pops[pop], indiv, v->idx[snp][pop]-1);
  }
  else if (!v->idx)
  {
    return gdl_snp_data_is_missing (v->pops[pop], indiv, snp);
  }
  return gdl_true;
}


double
gdl_snp_chromosome_get_pop_frequency (const gdl_snp_chromosome * c,
				      size_t pop,
				      size_t snp)
{
  size_t s;
  double f;

  if (c->idx && c->idx[snp][pop])
  {
    s = c->idx[snp][pop]-1;
  }
  else if (!c->idx)
  {
    s = snp;
  }
  else
  {
    return 0.0;
  }

  gdl_snp_stats * stats = gdl_snp_stats_alloc ();

  gdl_snp_data_snp_stats (c->pops[pop], s, stats);

  f = stats->afreq[1];

  gdl_snp_stats_free (stats);

  return f;
}

double
gdl_snp_chromosome_get_frequency (const gdl_snp_chromosome * c,
				  size_t snp)
{
  size_t i, N = 0;
  double f = 0;

  for (i = 0; i< c->npop; i++)
  {
    if (gdl_snp_chromosome_is_polymorphic(c, i, snp))
    {
      double x = gdl_snp_chromosome_get_pop_frequency (c, i, snp);
      f += c->pops[i]->N*x;
      N += c->pops[i]->N;
    }
  }
  return f/N;
}

double
gdl_snp_chromosome_get_MAF (const gdl_snp_chromosome * c, size_t snp, size_t * which)
{
  size_t i, N = 0;
  double f = 0;

  *which=1;

  for (i = 0; i< c->npop; i++)
  {
    if (gdl_snp_chromosome_is_polymorphic(c, i, snp))
    {
      double x = gdl_snp_chromosome_get_pop_frequency (c, i, snp);
      f += c->pops[i]->N*x;
      N += c->pops[i]->N;
    }
  }
  f=f/N;
  if (f > 0.5)
  {
    *which=0;
    return 1.0-f;
  }
  else
  {
    return f;
  }
}

size_t
gdl_snp_chromosome_select_snp (gdl_snp_chromosome * c,
			       const double fmin,
			       const double gmin,
			       const gdl_boolean poly_pop,
			       const gdl_boolean within_pop)
{
  size_t i, j, k, N, * idx, rm=0;
  double f, g0, g1;
  gdl_snp_stats * stats;
  gdl_snp ** snps = c->chrom->snps;

  stats = gdl_snp_stats_alloc ();

  for (i = 0; i < c->chrom->size; i++)
  {
    if (snps[i]->ignore == 'y')
    {
      continue;
    }
    if (poly_pop && snps[i]->polypop == 'n')
    {
      snps[i]->ignore = 'y';
      if (c->logger)
      {
	fprintf (c->logger, "Discard SNP %s %ld on chromosome %s: not polymorphic in all populations\n", snps[i]->rs, snps[i]->position, c->name);
      }
      rm++;
    }
    else if ((fmin < 1 && fmin > 0) || (gmin < 1 && gmin > 0))
    {
      if (!within_pop)
      {
	g0 = g1 = f = 0; // compute the snp frequency
	N = 0;
	for (j = 0; j < c->npop; j++)
	{
	  if (c->idx && c->idx[i][j])
	  {
	    gdl_snp_data_snp_stats (c->pops[j], c->idx[i][j]-1, stats);
	    f  += c->pops[j]->N*stats->afreq[0];
	    g0 += c->pops[j]->N*stats->gfreq[0];
	    g1 += c->pops[j]->N*stats->gfreq[1];
	    N += c->pops[j]->N;
	  }
	  else if (!c->idx)
	  {
	    gdl_snp_data_snp_stats (c->pops[j], i, stats);
	    f  += c->pops[j]->N*stats->afreq[0];
	    g0 += c->pops[j]->N*stats->gfreq[0];
	    g1 += c->pops[j]->N*stats->gfreq[1];
	    N += c->pops[j]->N;
	  }
	}
	f/=N;
	g0/=N;
	g1/=N;
	//printf (">SNP %d %1.3f %1.3f\n", i, f, fmin);
	if (   (f < fmin || 1-f < fmin)
	       || (g0 < gmin || g1 < gmin)
	       || (1-g0-g1 < gmin))
	{
	  snps[i]->ignore = 'y';
	  if (c->logger)
	  {
	    fprintf (c->logger, "Discard SNP %s %ld on chromosome %s: frequency %1.5f under threshold %1.5f\n", snps[i]->rs, snps[i]->position, c->name, f, fmin);
	  }
	  rm++;
	}
      }
      else
      {
	size_t np = 0;
	for (j = 0; j < c->npop; j++)
	{
	  if (c->idx && c->idx[i][j])
	  {
	    gdl_snp_data_snp_stats (c->pops[j], c->idx[i][j]-1, stats);
	    f  = stats->afreq[0];
	    g0 = stats->gfreq[0];
	    g1 = stats->gfreq[1];
	  }
	  else if (!c->idx)
	  {
	    gdl_snp_data_snp_stats (c->pops[j], i, stats);
	    f  = stats->afreq[0];
	    g0 = stats->gfreq[0];
	    g1 = stats->gfreq[1];
	  }
	  if (   (f < fmin || 1-f < fmin)
		 || (g0 < gmin || g1 < gmin)
		 || (1-g0-g1 < gmin))
	  {
	    np++;
	  }
	}
	if (np == c->npop)
	{
	  snps[i]->ignore = 'y';
	  if (c->logger)
	  {
	    fprintf (c->logger, "Discard SNP %s %ld on chromosome %s: frequency %1.5f under threshold %1.5f\n", snps[i]->rs, snps[i]->position, c->name, f, fmin);
	  }
	  rm++;
	}
      }
    }
  }

  gdl_snp_stats_free (stats);

  return rm;
}

size_t
gdl_snp_chromosome_select_min_allele (gdl_snp_chromosome * c,
				      const double amin,
				      const int poly_group)
{
  size_t i, j, rm=0;
  double a0, a1;
  gdl_snp_stats * stats;
  gdl_snp ** snps = c->chrom->snps;

  stats = gdl_snp_stats_alloc ();

  for (i = 0; i < c->chrom->size; i++)
  {
    if (snps[i]->ignore == 'y')
    {
      continue;
    }
    if (poly_group != -1 && snps[i]->group != poly_group)
    {
      continue;
    }
    a0 = a1 = 0;
    for (j = 0; j < c->npop; j++)
    {
      if (c->idx && c->idx[i][j])
      {
	gdl_snp_data_snp_stats (c->pops[j], c->idx[i][j]-1, stats);
      }
      else if (!c->idx)
      {
	gdl_snp_data_snp_stats (c->pops[j], i, stats);
      }
      a0 += (c->pops[j]->P)*(c->pops[j]->N-stats->missing)*stats->afreq[0];
      a1 += (c->pops[j]->P)*(c->pops[j]->N-stats->missing)*stats->afreq[1];
    }
    if (a0 < amin || a1 < amin)
    {
      snps[i]->ignore = 'y';
      if (c->logger)
      {
	fprintf (c->logger, "Discard SNP %s %ld on chromosome %s: allele counts (0=%.1f, 1=%.1f) under threshold %.1f\n", snps[i]->rs, snps[i]->position, c->name, a0, a1, amin);
      }
      rm++;
    }
  }

  gdl_snp_stats_free (stats);

  return rm;
}

gdl_cnv_clone **
gdl_snp_chromosome_get_cnv_clones (const gdl_snp_chromosome * c,
				   long from,
				   long to,
				   size_t * n)
{
  if (!c->cnvs)
    return 0;

  size_t i;
  gdl_cnv_data * data = c->cnvs[0];
  gdl_list * tmp = gdl_list_alloc (gdl_list_default);

  const size_t L = data->L;

  for (i = 0; i < L; i++)
  {
    if (data->clones[i]->start >= from && data->clones[i]->end <= to)
    {
      data->clones[i]->idx = i;
      gdl_list_push_back (tmp, data->clones[i], 0);
    }
  }

  if (!gdl_list_size (tmp))
  {
    *n=0;
    return 0;
  }

  *n = gdl_list_size (tmp);

  gdl_cnv_clone ** clones = GDL_MALLOC (gdl_cnv_clone *, *n);

  i=0;

  gdl_list_itr * itr = gdl_list_iterator_front (tmp);

  do
  {
    clones[i] = (gdl_cnv_clone *) gdl_list_iterator_value (itr);
    i++;
  }
  while (gdl_list_iterator_next (itr));

  gdl_list_iterator_free (itr);

  gdl_list_free (tmp);

  return clones;
}

FILE *
gdl_snp_chromosome_set_logger (gdl_snp_chromosome * c,
			       FILE * logger)
{
  FILE * out = c->logger;
  c->logger = logger;
  return out;
}

int
gdl_snp_chromosome_fprintf (const gdl_snp_chromosome * c,
			    gdl_string ** pop_names,
			    const gdl_string * output)
{
  size_t i,j,jj,k;
  gdl_string * file1, * file2;
  FILE * stream;

  for(i = 0; i < c->npop; i++)
  {
    if (pop_names)
    {
      file1 = gdl_string_sprintf ("%s/%s/%s.snp", output, pop_names[i], c->name);
      file2 = gdl_string_sprintf ("%s/%s/%s.map", output, pop_names[i], c->name);
    }
    else
    {
      file1 = gdl_string_sprintf ("%s/Pop_%d/%s.snp", output, i+1, c->name);
      file2 = gdl_string_sprintf ("%s/Pop_%d/%s.map", output, i+1, c->name);
    }
    // Map
    stream = gdl_fileopen (file2, "w");
    for(j = 0; j < c->chrom->size; j++)
    {
      if ((c->idx && c->idx[j][i]) || !c->idx)
      {
	gdl_snp * snp = c->chrom->snps[j];
	fprintf (stream, "%s %ld %s %s\n", snp->rs, snp->position, snp->alleles[0], snp->alleles[1]);
	fflush (stream);
      }
    }
    gdl_fileclose (file2, stream);
    // Genotypes
    stream = gdl_fileopen (file1, "w");
    gdl_snp_data_fprintf (stream, c->pops[i], gdl_false);
    gdl_fileclose (file2, stream);
  }
}

int
gdl_snp_chromosome_genoptype_fprintf (FILE * stream,
				      const gdl_snp_chromosome * c,
				      const size_t pop,
				      const size_t indiv,
				      const size_t snp)
{
  size_t s;

  if (c->idx && c->idx[snp][pop])
  {
    s = c->idx[snp][pop]-1;
  }
  else if (!c->idx)
  {
    s = snp;
  }
  else
  {
    fprintf (stream, "?");
    return GDL_SUCCESS;
  }

  gdl_snp_data_genotype_fprintf (stream, c->pops[pop], indiv, s);

  return GDL_SUCCESS;
}

int
gdl_snp_chromosome_join_poly_fprintf (const gdl_snp_chromosome * c,
				      const gdl_string * output)
{
  size_t i,j,k,l;
  double a, d;
  gdl_string * file;
  FILE * stream;

  file = gdl_string_sprintf ("%s/%s.map", output, c->name);
  // Map
  stream = gdl_fileopen (file, "w");
  for(j = 0; j < c->chrom->size; j++)
  {
    gdl_snp * snp = c->chrom->snps[j];
    fprintf (stream, "%s %ld %s %s\n", snp->rs, snp->position, snp->alleles[0], snp->alleles[1]);
    fflush (stream);
  }
  gdl_fileclose (file, stream);
  gdl_string_free (file);
  // Genotypes
  file   = gdl_string_sprintf ("%s/%s.snp", output, c->name);
  stream = gdl_fileopen (file, "w");
  for(j = 0; j < c->chrom->size; j++)
  {
    for(k = 0; k < c->npop; k++)
    {
      for(i = 0; i < c->pops[k]->N; i++)
      {
	if (c->idx && c->idx[j][k])
	{
	  gdl_snp_data_addom_get (c->pops[k], i, c->idx[j][k]-1, &a, &d);
	  fprintf(stream,  "%1.3f", a);
	}
	else if (!c->idx)
	{
	  gdl_snp_data_addom_get (c->pops[k], i, j, &a, &d);
	  fprintf(stream,  "%1.3f", a);
	}
	else
	{
	  fprintf (stream, "?");
	}
	if (k != c->npop-1 || i != c->pops[k]->N-1)
	{
	  fprintf(stream, " ");
	}
      }
    }
    fprintf(stream, "\n");
  }
  gdl_fileclose (file, stream);
  gdl_string_free (file);

  return GDL_SUCCESS;
}

int
gdl_snp_chromosome_join_sample_fprintf (const gdl_snp_chromosome * c,
					const gdl_string * output)
{
  size_t i,j,k,l;
  double a, d;
  gdl_string * file;
  FILE * stream;

  file = gdl_string_sprintf ("%s/%s.map", output, c->name);
  // Map
  stream = gdl_fileopen (file, "w");
  for(j = 0; j < c->chrom->size; j++)
  {
    gdl_snp * snp = c->chrom->snps[j];
    fprintf (stream, "%s %ld %s %s\n", snp->rs, snp->position, snp->alleles[0], snp->alleles[1]);
    fflush (stream);
  }
  gdl_fileclose (file, stream);
  gdl_string_free (file);
  // Genotypes
  file   = gdl_string_sprintf ("%s/%s.snp", output, c->name);
  stream = gdl_fileopen (file, "w");
  for(j = 0; j < c->chrom->size; j++)
  {
    // Which dataset contains the genotype for that marker ?
    for(k = l = 0; k < c->npop; k++)
    {
      if (c->idx[j][k])
      {
	l = c->idx[j][k]-1;
	break;
      }
    }
    if (k == c->npop)
    {
      GDL_ERROR_VAL ("Internal Error", GDL_FAILURE, GDL_FAILURE);
    }
    for(i = 0; i < c->pops[k]->N; i++)
    {
      gdl_snp_data_addom_get (c->pops[k], i, l, &a, &d);
      fprintf(stream,  "%1.3f", a);
      if (k != c->npop-1 || i != c->pops[k]->N-1)
      {
	fprintf(stream, " ");
      }
    }
    fprintf(stream, "\n");
  }
  gdl_fileclose (file, stream);
  gdl_string_free (file);

  return GDL_SUCCESS;
}

int
gdl_snp_chromosome_get_group (const gdl_snp_chromosome * G,
			      const gdl_string * POLY_GROUP)
{
  if (!G->_ngroup)
  {
    GDL_ERROR_VAL("No group of polymorphisms defined in the database", GDL_EINVAL, GDL_EINVAL);
  }
  if (!strcmp(POLY_GROUP, "snp"))  // reserved term
  {
    return 0;
  }
  else
  {
    size_t i;

    for(i = 0; i < G->_ngroup; i++)
    {
      if (!strcmp(G->_group_names[i], POLY_GROUP))
      {
	break;
      }
    }
    if (i == G->_ngroup)
    {
      GDL_ERROR_VAL(gdl_string_sprintf ("No group of polymorphisms called %s in the database", POLY_GROUP), GDL_EINVAL, GDL_EINVAL);
    }
    return i+1;
  }
}

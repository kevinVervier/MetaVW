/* 
 * stats/qnorm.c
 * 
 * Copyright (C) 2008 Jean-Baptiste Veyrieras
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <math.h> 

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_sort_double.h>

double *
gdl_stats_qqnorm (const double * x, const size_t n)
{
	size_t i,j,nm=0;
	double pr, * y, * qx; 
	size_t * yx;
	
	qx  = GDL_CALLOC (double, n);
	y   = GDL_CALLOC (double, n);
	for(i = j = 0; i < n ; i++)
	{
		if (gdl_isnan(x[i]))
		{
			qx[i] = GDL_NAN;
			nm++;
		}
		else
		{
			y[j++]=x[i];	
		}
	}
	yx = GDL_CALLOC (size_t, n - nm);
	gdl_sort_index (yx, y, 1, n - nm);
	for (j = 0; j < n - nm; j++)
	{
		pr = ((double)(j + 0.5))/((double)(n - nm + 1));
		y[yx[j]] = gdl_ran_ugaussian_quantile (pr);
	}
	for(i = j = 0; i < n; i++)
	{
		if (!gdl_isnan(x[i])) 
		{
			qx[i] = y[j++];
		}
	}
	GDL_FREE (y);
	GDL_FREE (yx);
	
	return qx;
}

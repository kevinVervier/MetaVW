#ifndef __GDL_STATISTICS_H__
#define __GDL_STATISTICS_H__

#include <gdl/gdl_statistics_long_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_statistics_float.h>

#include <gdl/gdl_statistics_ulong.h>
#include <gdl/gdl_statistics_long.h>

#include <gdl/gdl_statistics_uint.h>
#include <gdl/gdl_statistics_int.h>

#include <gdl/gdl_statistics_ushort.h>
#include <gdl/gdl_statistics_short.h>

#include <gdl/gdl_statistics_uchar.h>
#include <gdl/gdl_statistics_char.h>

#endif /* __GDL_STATISTICS_H__ */

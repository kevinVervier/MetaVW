#! /bin/sh

# Run this to generate all the auto-generated files needed by the GNU
# configure program

if hash libtoolize 2>&-
then
	libtoolize --automake
else  #for Mac
	glibtoolize --automake
fi
aclocal
automake --add-missing --gnu
autoconf
echo "Now use ./configure --enable-maintainer-mode"

/*
 * 	table/gdl_table.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, BioMiningLabs.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_TABLE_H__
#define __GDL_TABLE_H__

#include <string.h>
#include <stdio.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_matrix.h>
#include <gdl/gdl_vector.h>
#include <gdl/gdl_common.h>
#include <gdl/gdl_labeled_matrix.h>

__BEGIN_DECLS

typedef struct
{
	size_t nrow;
	size_t ncol; // = nfactor + nvector
	size_t nfactor;
	size_t nvector;
	gdl_string ** row_names;
	gdl_string ** col_names;
	gdl_string *** levels;
	size_t * var_index;
	unsigned char * var_types;
	size_t * level_by_factor;
	int    ** factors;
	double ** vectors;
} gdl_table;

gdl_table * gdl_table_alloc (const size_t nrow, const size_t ncol);
void gdl_table_free (gdl_table * t);
gdl_table * gdl_table_fscanf (FILE * stream, const gdl_string * na_string);
int gdl_table_fwrite (FILE * stream, const gdl_table * t);
gdl_table * gdl_table_fread (FILE * stream);
//double * gdl_table_get_var (const gdl_table * p, const gdl_string * name);
size_t * gdl_table_get_factor (const gdl_table * p, const gdl_string * name, size_t * nz);
gdl_string * gdl_table_get_cell (const gdl_table * p, const size_t r, const size_t c, const gdl_string * na_string);
gdl_table * gdl_table_row_subset (const gdl_table * t, gdl_string ** row_names, const size_t nrow);
gdl_table * gdl_table_col_subset (const gdl_table * t, gdl_string ** col_names, const size_t ncol);
gdl_table * gdl_table_join (const gdl_table * t1, const gdl_table * t2, const char type);
int gdl_table_fprintf (FILE * stream, const gdl_table * table);
gdl_table * gdl_table_clone (const gdl_table * t1);
gdl_labeled_matrix * gdl_table_design_matrix (const gdl_table * t);
gdl_boolean gdl_table_has_variable (const gdl_table * t, const gdl_string * name);

__END_DECLS

#endif /* __GDL_TABLE_H__ */

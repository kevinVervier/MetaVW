/*  
 * 	table/test.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_test.h>
#include <gdl/gdl_table.h>

void
test_table1 (void)
{
	FILE * stream;
	gdl_table * t;
	
	stream = gdl_fileopen ("test_table_1.txt", "r");
	
	t = gdl_table_fscanf (stream, "NA");
	
	gdl_fileclose ("test_table_1.txt", stream);
	
	gdl_test (t == 0, "test_table1: gdl_table_alloc returns valid pointer");
	
	gdl_test (t->nrow != 210, "test_table1: table->nrow is ok");
	
	gdl_test (t->ncol != 3, "test_table1: table->ncol is ok");
	
	gdl_table_free (t);
}


int
main (void)
{
	test_table1 ();
	exit (gdl_test_summary());
}

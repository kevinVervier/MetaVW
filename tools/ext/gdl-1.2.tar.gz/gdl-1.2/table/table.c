/*
 * 	table/table.c
 *
 *  $Author: tflutre $, $Date: 2011/10/02 20:37:38 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, BioMiningLabs.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <string.h>
#include <stdio.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_matrix.h>
#include <gdl/gdl_vector.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_hash.h>

#include <gdl/gdl_table.h>

gdl_table *
gdl_table_alloc (const size_t nrow, const size_t ncol)
{
	size_t j;
	gdl_table * i;

	i = GDL_CALLOC (gdl_table, 1);

	i->nrow = nrow;
	i->ncol = ncol;

	i->row_names = GDL_CALLOC (gdl_string *, i->nrow);
	if (i->ncol)
	{
		i->col_names = GDL_CALLOC (gdl_string *, i->ncol);
	}

	return i;
}

void
gdl_table_free (gdl_table * p)
{
	if (p)
	{
		size_t i,j;
		for(i = 0; i < p->nrow; i++)
		{
			GDL_FREE (p->row_names[i]);
		}
		GDL_FREE (p->row_names);
		for(i = 0; i < p->ncol; i++)
		{
			GDL_FREE (p->col_names[i]);
		}
		GDL_FREE (p->col_names);
		GDL_FREE (p->var_types);
		if (p->nfactor)
		{
			GDL_MATRIX_FREE (p->factors, p->nfactor);
		}
		if (p->nvector)
		{
			GDL_MATRIX_FREE (p->vectors, p->nvector);
		}
		for(i = 0; i < p->nfactor; i++)
		{
			for(j = 0; j < p->level_by_factor[i]; j++)
			{
				GDL_FREE (p->levels[i][j]);
			}
			GDL_FREE (p->levels[i]);
		}
		GDL_FREE (p->levels);
		GDL_FREE (p->level_by_factor);
		GDL_FREE (p->var_index);
		GDL_FREE (p);
	}
}

static gdl_boolean
_is_float (const gdl_string * tok)
{
	size_t i,p=0,e=0,s=0,n=strlen(tok);
	for(i = 0; i < n; i++)
	{
		if (!isdigit(tok[i]))
		{
			if (tok[i]=='.' && p==0)
				p=1;
			else if ((tok[i]=='+' || tok[i]=='-'))
				s++;
			else if (tok[i]=='e' && e == 0)
				e++;
			else
				break;
		}
	}
	if (i < n || (e == 1 && s > 2) || (e > 1) || (e == 0 && s > 1))
	{
		return gdl_false;
	}
	return gdl_true;
}
/**
 *
 */
gdl_table *
gdl_table_fscanf (FILE * stream, const gdl_string * na_string)
{
	size_t i,ii,j,jj,n,k,l=0,m,lx,fx,vx,*lxx,nrow,ncol,nfactor,nvector;
	long offset;
	unsigned char * var_types;
	gdl_string * line = 0, * tok;
	gdl_hashtable * buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
	gdl_hashtable * _levels;
	gdl_table * p;

	// First count the number of rows and columns
	offset = ftell (stream);
	l = nrow = ncol = 0;
	while (gdl_getline (&line, &n, stream) != -1)
	{
		i = j = 0;
		if (l == 0) // header
		{
			while (j < n && j !=  n - 1)
			{
				tok = gdl_string_next_token (line, n, &i, &j);
				if (gdl_hashtable_lookup (buffer, tok))
				{
					GDL_ERROR_VAL (gdl_string_sprintf ("Two columns share the same name %s\n", tok), GDL_EINVAL, 0);
				}
				gdl_hashtable_add (buffer, tok, tok, 0);
				ncol++;
			}
		}
		else
		{
			if (l == 1) // determine the variable type
			{
				var_types = GDL_CALLOC (unsigned char, ncol);
				for(k = 0; k < ncol; k++) var_types[k] = '?';
				nvector   = 0;
				nfactor   = 0;
			}
			if (nvector + nfactor < ncol)
			{
				tok = gdl_string_next_token (line, n, &i, &j);
				if (j < n)
				{
					for(k = 0; k < ncol; k++)
					{
						tok = gdl_string_next_token (line, n, &i, &j);
						if (j == n-1 && k < ncol-1)
						{
							GDL_ERROR_VAL (gdl_string_sprintf ("Row %d has less columns than expected\n", nrow), GDL_EINVAL, 0);
						}
						if (strcmp(tok, na_string) && var_types[k] == '?')
						{
							if (_is_float (tok))
							{
								var_types[k]='v';
								nvector++;
							}
							else
							{
							   var_types[k]='f';
							   nfactor++;
							}
						}
						gdl_string_free (tok);
					}
				}
			}
			// check if the number of columns is still the same
			nrow++;
		}
		// end of line
		gdl_string_free (line);
		line=0;
		l++;
	}
	if (!nfactor && !nvector)
	{
		p = gdl_table_alloc (nrow+1, 0);
	}
	else
	{
		p = gdl_table_alloc (nrow, ncol);
		p->nfactor = nfactor;
		p->nvector = nvector;
		p->var_types = var_types;
		p->var_index = GDL_CALLOC (size_t, p->ncol);
		for(i = nfactor = nvector = 0; i < p->ncol; i++)
		{
			switch(p->var_types[i])
			{
				case 'f':
					p->var_index[i]=nfactor;
					nfactor++;
					break;
				case 'v':
					p->var_index[i]=nvector;
					nvector++;
					break;
			}
		}
		if (p->nfactor)
		{
			_levels    = gdl_hashtable_alloc (gdl_hash_default, p->nfactor);
			p->factors = GDL_MATRIX_ALLOC (int, p->nfactor, p->nrow);
		}
		if (p->nvector)
		{
			p->vectors =  GDL_MATRIX_ALLOC (double, p->nvector, p->nrow);
		}
	}
	// come back to the beginning of the file
	fseek (stream, offset, SEEK_SET);
	l = 0;
	// Parse the content of the cells
	while (gdl_getline (&line, &n, stream) != -1)
	{
		//printf ("LINE %s\n", line);
		i = j = 0;
		if (l == 0) // header
		{
			if (p->ncol)
			{
				p->col_names = GDL_MALLOC (gdl_string *, p->ncol);
				for(k = 0; k < p->ncol; k++)
				{
					tok = gdl_string_next_token (line, n, &i, &j);
					p->col_names[k] = tok;
				}
				gdl_hashtable_free (buffer);
			}
			else
			{
				tok = gdl_string_next_token (line, n, &i, &j);
				p->row_names[l] = tok;
			}
		}
		else
		{
			if (p->ncol)
			{
				tok = gdl_string_next_token (line, n, &i, &j);
				p->row_names[l-1] = tok;
				for(fx = vx = k = 0; k < p->ncol; k++)
				{
					tok = gdl_string_next_token (line, n, &i, &j);
					//printf ("TOK %s\n", tok);
					switch(p->var_types[k])
					{
						case 'f':
							//printf ("VARIABLE %d %s\n", k, p->col_names[k]);
							//fflush(stdout);
							if (strcmp(tok, na_string))
							{
								buffer = gdl_hashtable_lookup(_levels, p->col_names[k]);
								//printf ("%p <== %s\n", buffer, p->col_names[k]);
								if (!buffer)
								{
									buffer = gdl_hashtable_alloc (gdl_interface_uint, 0);
									gdl_hashtable_add (_levels, p->col_names[k], buffer, 0);
								}
								if ((lxx=gdl_hashtable_lookup (buffer, tok))==0)
								{
									lxx = GDL_MALLOC (size_t, 1);
									*lxx = lx = gdl_hashtable_size (buffer);
									//printf ("%s %s ==> %d\n", p->col_names[k], tok, *lxx);
									gdl_hashtable_add (buffer, tok, lxx, 1);
								}
								p->factors[fx][l-1] = *lxx;
							}
							else
							{
								p->factors[fx][l-1] = -1;
							}
							(fx)++;
							break;
						case 'v':
							if (strcmp(tok, na_string))
							{
								p->vectors[vx][l-1] = (double)atof(tok);
							}
							else
							{
								p->vectors[vx][l-1] = GDL_NAN;
							}
							(vx)++;
							break;
					}
					gdl_string_free (tok);
				}
			}
			else
			{
				tok = gdl_string_next_token (line, n, &i, &j);
				p->row_names[l] = tok;
			}
		}
		// end of line
		gdl_string_free (line);
		line=0;
		l++;
	}
	//printf ("nfactor = %d\n", p->nfactor);
	// Create the level matrix for factors
	if (p->nfactor)
	{
		p->level_by_factor = GDL_MALLOC (size_t, p->nfactor);
		p->levels = GDL_MALLOC (gdl_string **, p->nfactor);
		for(fx = k = 0; k < p->ncol; k++)
		{
			if (p->var_types[k] != 'f')
				continue;
			buffer = gdl_hashtable_lookup (_levels, p->col_names[k]);
			p->level_by_factor[fx] = gdl_hashtable_size (buffer);
			p->levels[fx]          = GDL_MALLOC (gdl_string *, p->level_by_factor[fx]);
			gdl_hashtable_itr * itr = gdl_hashtable_iterator (buffer);
			do
			{
				size_t * itmp = (size_t *) gdl_hashtable_iterator_value (itr);
				p->levels[fx][*itmp] = gdl_string_clone (gdl_hashtable_iterator_key (itr));
				//printf ("FACTOR %d LEVEL %d %s\n", fx, *itmp, p->levels[fx][*itmp]);
			}
			while(gdl_hashtable_iterator_next (itr));
			gdl_hashtable_iterator_free (itr);
			gdl_hashtable_free (buffer);
			fx++;
		}
		gdl_hashtable_free (_levels);
	}

	return p;
}

int
gdl_table_fwrite (FILE * stream, const gdl_table * p)
{
	if (stream && p)
	{
		size_t i,j;
		int status;

		status = fwrite (&(p->nrow), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(p->ncol), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(p->nfactor), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(p->nvector), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		for(i = 0; i < p->nrow; i++)
		{
			status = gdl_string_fwrite (stream, p->row_names[i]);
			GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		}
		if (p->ncol)
		{
			status = fwrite (p->var_types, sizeof(unsigned char), p->ncol, stream);
			GDL_FWRITE_STATUS (status, p->ncol, 1);
			status = fwrite (p->var_index, sizeof(size_t), p->ncol, stream);
			GDL_FWRITE_STATUS (status, p->ncol, 1);
			for(i = 0; i < p->ncol; i++)
			{
				status = gdl_string_fwrite (stream, p->col_names[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
			if (p->nfactor)
			{
				status = fwrite (p->level_by_factor, sizeof(size_t), p->nfactor, stream);
				GDL_FWRITE_STATUS (status, p->nfactor, 1);
				for(i = 0; i < p->nfactor; i++)
				{
					status = fwrite (p->factors[i], sizeof(int), p->nrow, stream);
					GDL_FWRITE_STATUS (status, p->nrow, 1);
				}
				for(i = 0; i < p->nfactor; i++)
				{
					for(j = 0; j < p->level_by_factor[i]; j++)
					{
						status = gdl_string_fwrite (stream, p->levels[i][j]);
						GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
					}
				}
			}
			for(i = 0; i < p->nvector; i++)
			{
				status = fwrite (p->vectors[i], sizeof(double), p->nrow, stream);
				GDL_FWRITE_STATUS (status, p->nrow, 1);
			}
		}
		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

gdl_table *
gdl_table_fread (FILE * stream)
{
	if (stream)
	{
		size_t i,j;
		int status;
		gdl_table * p;

		p = GDL_CALLOC (gdl_table, 1);

		status = fread (&(p->nrow), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(p->ncol), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(p->nfactor), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(p->nvector), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		p->row_names = GDL_MALLOC (gdl_string *, p->nrow);

		for(i = 0; i < p->nrow; i++)
		{
			p->row_names[i] = gdl_string_fread (stream);
			GDL_FREAD_STATUS (p->row_names[i]!=0, 1, NULL);
		}
		if (p->ncol)
		{
			p->var_types = GDL_MALLOC (unsigned char, p->ncol);
			p->var_index = GDL_MALLOC (size_t, p->ncol);
			p->col_names = GDL_MALLOC (gdl_string *, p->ncol);

			status = fread (p->var_types, sizeof(unsigned char), p->ncol, stream);
			GDL_FREAD_STATUS (status, p->ncol, NULL);
			status = fread (p->var_index, sizeof(size_t), p->ncol, stream);
			GDL_FREAD_STATUS (status, p->ncol, NULL);
			for(i = 0; i < p->ncol; i++)
			{
				p->col_names[i] = gdl_string_fread (stream);
				GDL_FREAD_STATUS (p->col_names[i]!=0, 1, NULL);
			}
			if (p->nfactor)
			{
				p->level_by_factor = GDL_MALLOC (size_t, p->nfactor);
				p->factors = GDL_MATRIX_ALLOC (int, p->nfactor, p->nrow);
				p->levels  = GDL_MALLOC (gdl_string **, p->nfactor);

				status = fread (p->level_by_factor, sizeof(size_t), p->nfactor, stream);
				GDL_FREAD_STATUS (status, p->nfactor, NULL);

				for(i = 0; i < p->nfactor; i++)
				{
					status = fread (p->factors[i], sizeof(int), p->nrow, stream);
					GDL_FREAD_STATUS (status, p->nrow, NULL);
				}

				for(i = 0; i < p->nfactor; i++)
				{
					p->levels[i] = GDL_MALLOC (gdl_string *, p->level_by_factor[i]);
					for(j = 0; j < p->level_by_factor[i]; j++)
					{
						p->levels[i][j] = gdl_string_fread (stream);
						GDL_FREAD_STATUS (p->levels[i][j]!=0, 1, NULL);
					}
				}
			}
			if (p->nvector)
			{
				p->vectors = GDL_MATRIX_ALLOC (double, p->nvector, p->nrow);
				for(i = 0; i < p->nvector; i++)
				{
					status = fread (p->vectors[i], sizeof(double), p->nrow, stream);
					GDL_FREAD_STATUS (status, p->nrow, NULL);
				}
			}
		}

		return p;
	}
	return 0;
}

double *
gdl_table_get_row (const gdl_table * p, const gdl_string * name)
{
	size_t i,f=0,v=0;
	double * x = 0;

	for(i = 0; i < p->ncol; i++)
	{
		if (!strcmp(p->col_names[i], name))
		{
			break;
		}
		switch(p->var_types[i])
		{
			case 'f':
				f++;
				break;
			case 'v':
				v++;
				break;
		}
	}
	if (i == p->ncol)
	{
		return x;
	}
	x = GDL_MALLOC (double, p->nrow);
	switch(p->var_types[i])
	{
		case 'f':
			for(i = 0; i < p->nrow; i++)
			{
				if (p->factors[f][i] == -1)
					x[i] = GDL_NAN;
				else
					x[i] = (double) p->factors[f][i];
			}
			break;
		case 'v':
			memcpy(x, p->vectors[v], sizeof(double)*p->nrow);
			break;
	}
	return x;
}

gdl_string *
gdl_table_get_cell (const gdl_table * p, const size_t r, const size_t c, const gdl_string * na_string)
{
	//printf("TYPE %d %d (%d, %d) %c ==> %d %d\n", r, c, p->nrow, p->ncol, p->var_types[c], p->var_index[c], p->factors[p->var_index[c]][r]);
	switch(p->var_types[c])
	{
		case 'f':
			if (p->factors[p->var_index[c]][r] != -1)
			{
				return gdl_string_clone (p->levels[p->var_index[c]][p->factors[p->var_index[c]][r]]);
			}
			break;
		case 'v':
			if (!gdl_isnan (p->vectors[p->var_index[c]][r]))
			{
				return gdl_string_sprintf ("%e", p->vectors[p->var_index[c]][r]);
			}
			break;
	}
	return gdl_string_clone (na_string);
}

size_t *
gdl_table_get_factor (const gdl_table * p, const gdl_string * name, size_t *nz)
{
	size_t i,f=0;
	size_t * x = 0;

	(*nz) = 0;

	for(i = 0; i < p->ncol; i++)
	{
		if (!strcmp(p->col_names[i], name))
		{
			break;
		}
		switch(p->var_types[i])
		{
			case 'f':
				f++;
				break;
			default:
				break;
		}
	}
	if (i == p->ncol)
	{
		return x;
	}
	switch(p->var_types[i])
	{
		case 'f':
			x = GDL_MALLOC (size_t, p->nrow);
			for(i = 0; i < p->nrow; i++)
			{
				x[i] = p->factors[f][i];
			}
			(*nz) = p->level_by_factor[f];
			return x;
		case 'v':
			return x;
	}
}

gdl_table *
gdl_table_row_subset (const gdl_table * t, gdl_string ** row_names, const size_t nrow)
{
	size_t i,j,n=0;
	int * rowx;
	gdl_table * s = 0;

	rowx = GDL_MALLOC (int, nrow);
	for(i = 0; i < nrow; i++)
	{
		rowx[i]=-1;
		for(j = 0; j < t->nrow; j++)
		{
			if (!strcmp(row_names[i], t->row_names[j]))
			{
				rowx[i] = j;
				n++;
				break;
			}
		}
	}
	if (n)
	{
		s = gdl_table_alloc (n, t->ncol);

		s->nfactor = t->nfactor;
		s->nvector = t->nvector;

		s->col_names = GDL_MALLOC (gdl_string *, s->ncol);
		for(i = 0; i < s->ncol; i++)
		{
			s->col_names[i] = gdl_string_clone (t->col_names[i]);
		}

		s->row_names = GDL_MALLOC (gdl_string *, s->nrow);
		for(j = i = 0; i < nrow; i++)
		{
			if (rowx[i]!=-1)
			{
				s->row_names[j++] = gdl_string_clone (t->row_names[rowx[i]]);
			}
		}

		s->var_index = GDL_MALLOC (size_t, s->ncol);
		memcpy(s->var_index, t->var_index, sizeof(size_t)*s->ncol);

		s->var_types = GDL_MALLOC (unsigned char, s->ncol);
		memcpy(s->var_types, t->var_types, sizeof(unsigned char)*s->ncol);

		if (s->nfactor)
		{
			s->level_by_factor = GDL_MALLOC (size_t, s->nfactor);
			memcpy(s->level_by_factor, t->level_by_factor, sizeof(size_t)*s->ncol);
			s->levels  = GDL_MALLOC (gdl_string **, s->nfactor);
			for(i = 0; i < s->nfactor; i++)
			{
				s->levels[i] = GDL_MALLOC (gdl_string *, s->level_by_factor[i]);
				for(j = 0; j < s->level_by_factor[i]; j++)
				{
					s->levels[i][j] = gdl_string_clone (t->levels[i][j]);
				}
			}
			s->factors = GDL_MATRIX_ALLOC(int, s->nfactor, s->nrow);
			for(i = 0; i < s->nfactor; i++)
			{
				size_t k = 0;
				for(j = 0; j < nrow; j++)
				{
					if (rowx[j]!=-1)
					{
						s->factors[i][k++] = t->factors[i][rowx[j]];
						//printf("%d %d ==> %d\n", i, k-1, t->factors[i][rowx[j]]);
					}
				}
			}
		}
		if (s->nvector)
		{
			s->vectors = GDL_MATRIX_ALLOC(double, s->nvector, s->nrow);
			for(i = 0; i < s->nvector; i++)
			{
				size_t k = 0;
				for(j = 0; j < nrow; j++)
				{
					if (rowx[j]!=-1)
					{
						s->vectors[i][k++] = t->vectors[i][rowx[j]];
					}
				}
			}
		}
	}

	GDL_FREE (rowx);
	return s;
}

gdl_table *
gdl_table_col_subset (const gdl_table * t, gdl_string ** col_names, const size_t ncol)
{
	size_t i,j,n=0;
	int * colx;
	gdl_table * s = 0;

	s = gdl_table_alloc (t->nrow, ncol);

	s->col_names = GDL_MALLOC (gdl_string *, s->ncol);
	for(i = 0; i < ncol; i++)
	{
		s->col_names[i] = gdl_string_clone (col_names[i]);
	}

	s->row_names = GDL_MALLOC (gdl_string *, s->nrow);
	for(i = 0; i < t->nrow; i++)
	{
		s->row_names[i] = gdl_string_clone (t->row_names[i]);
	}

	s->var_types = GDL_CALLOC (unsigned char, ncol);
	s->var_index = GDL_CALLOC (size_t, ncol);

	colx = GDL_MALLOC (int, ncol);
	for(i = 0; i < t->ncol; i++)
	{
		for(j = 0; j < ncol; j++)
		{
			if (!strcmp(t->col_names[i], col_names[j]))
			{
				colx[j] = i;
				s->var_types[j] = t->var_types[i];
				if (t->var_types[i] == 'f')
				{
					s->var_index[j] = (s->nfactor)++;
				}
				else
				{
					s->var_index[j] = (s->nvector)++;
				}
				break;
			}
		}
	}
	if (s->nvector)
	{
		s->vectors = GDL_MATRIX_ALLOC (double, s->nvector, s->nrow);
	}
	if (s->nfactor)
	{
		s->factors = GDL_MATRIX_ALLOC (int, s->nfactor, s->nrow);
		s->level_by_factor = GDL_MALLOC (size_t, s->nfactor);
		s->levels = GDL_CALLOC (gdl_string **, s->nfactor);
	}
	for(i = 0; i < s->ncol; i++)
	{
		size_t ti = t->var_index[colx[i]];
		size_t si = s->var_index[i];
		if (s->var_types[i] == 'f')
		{
			s->level_by_factor[si] = t->level_by_factor[ti];
			s->levels[si] = GDL_MALLOC (gdl_string *, s->level_by_factor[si]);
			for(j = 0; j < s->level_by_factor[si]; j++)
			{
				s->levels[si][j] = gdl_string_clone (t->levels[ti][j]);
			}
			memcpy(s->factors[si], t->factors[ti], sizeof(int)*t->nrow);
		}
		else
		{
			memcpy (s->vectors[si], t->vectors[ti], sizeof(double)*t->nrow);
		}
	}

	GDL_FREE (colx);

	return s;
}

/**
 * Join two tables using their row_names as keys.
 * The type of join determine the structure of
 * joined table
 * switch(type)
 * {
 *    case 'b'
 * 		nrow(table) = nrow(t1) + nrow(t2)
 * 	  case '1'
 * 		nrow(table) = nrow(t1)
 * 	  case '2'
 * 		nrow(table) = nrow(t2)
 * }
 * }
 *
 */
gdl_table *
gdl_table_join (const gdl_table * t1, const gdl_table * t2, const char type)
{
	size_t i,j,k;
	size_t nmatch;
	int * row_match;
	gdl_table * t12 = 0;

	switch(type)
	{
		case '1':
			row_match = gdl_string_match (t1->row_names, t1->nrow, t2->row_names, t2->nrow, &nmatch);
			if (nmatch)
			{
				t12 = gdl_table_alloc(t1->nrow, t1->ncol + t2->ncol);
				t12->var_index = GDL_MALLOC (size_t, t12->ncol);
				t12->var_types = GDL_MALLOC (unsigned char, t12->ncol);
				t12->nfactor = t1->nfactor + t2->nfactor;
				t12->nvector = t1->nvector + t2->nvector;
				for(i = 0; i < t12->nrow; i++)
				{
					t12->row_names[i] = gdl_string_clone (t1->row_names[i]);
				}

				for(i = j = 0; i < t1->ncol; i++, j++)
				{
					t12->col_names[j] = gdl_string_clone (t1->col_names[i]);
					t12->var_index[j] = t1->var_index[i];
					t12->var_types[j] = t1->var_types[i];
				}
				for(i = 0; i < t2->ncol; i++, j++)
				{
					t12->col_names[j] = gdl_string_clone (t2->col_names[i]);
					t12->var_index[j] = t1->ncol + t2->var_index[i];
					t12->var_types[j] = t2->var_types[i];
				}
				if (t12->nfactor)
				{
					t12->level_by_factor = GDL_MALLOC (size_t, t12->nfactor);
					for(i = j = 0; i < t1->nfactor; i++, j++)
					{
						t12->level_by_factor[j] = t1->level_by_factor[i];
					}
					for(i = 0; i < t2->nfactor; i++, j++)
					{
						t12->level_by_factor[j] = t2->level_by_factor[i];
					}
					t12->levels = GDL_MALLOC (gdl_string **, t12->nfactor);
					for(i = j = 0; i < t1->nfactor; i++, j++)
					{
						t12->levels[j] = GDL_MALLOC (gdl_string *, t1->level_by_factor[i]);
						for(k = 0; k <  t1->level_by_factor[i]; k++)
						{
							t12->levels[j][k] = gdl_string_clone (t1->levels[i][k]);
						}
					}
					for(i = 0; i < t2->nfactor; i++, j++)
					{
						t12->levels[j] = GDL_MALLOC (gdl_string *, t2->level_by_factor[i]);
						for(k = 0; k <  t2->level_by_factor[i]; k++)
						{
							t12->levels[j][k] = gdl_string_clone (t2->levels[i][k]);
						}
					}
					t12->factors = GDL_MATRIX_ALLOC (int, t12->nfactor, t12->nrow);
					for(i = j = 0; i < t1->nfactor; i++, j++)
					{
						memcpy(t12->factors[j], t1->factors[i], sizeof(int)*t12->nrow);
					}
					for(i = 0; i < t2->nfactor; i++, j++)
					{
						for(k = 0; k < t12->nrow; k++)
						{
							t12->factors[j][k] = -1;
						}
						for(k = 0; k < t2->nrow; k++)
						{
							if (row_match[k] != -1)
							{
								t12->factors[j][row_match[k]] = t2->factors[i][k];
							}
						}
					}
				}
				if (t12->nvector)
				{
					t12->vectors = GDL_MATRIX_ALLOC (double, t12->nvector, t12->nrow);
					for(i = j = 0; i < t1->nvector; i++, j++)
					{
						memcpy(t12->vectors[j], t1->vectors[i], sizeof(int)*t12->nrow);
					}
					for(i = 0; i < t2->nvector; i++, j++)
					{
						for(k = 0; k < t12->nrow; k++)
						{
							t12->vectors[j][k] = GDL_NAN;
						}
						for(k = 0; k < t2->nrow; k++)
						{
							if (row_match[k] != -1)
							{
								t12->vectors[j][row_match[k]] = t2->vectors[i][k];
							}
						}
					}
				}
			}
			break;
		case '2':
			break;
		case 'b':
			break;
	}

	return t12;
}

int
gdl_table_fprintf (FILE * stream, const gdl_table * table)
{
	size_t i, j;

	if (table->ncol)
	{
		fprintf (stream, "%s", table->col_names[0]);
		for(j = 1; j < table->ncol; j++)
		{
			fprintf (stream, "\t%s", table->col_names[j]);
		}
		fprintf (stream, "\n");
	}
	for(i = 0; i < table->nrow; i++)
	{
		fprintf (stream, "%s", table->row_names[i]);
		for(j = 0; j < table->ncol; j++)
		{
			gdl_string * cell = gdl_table_get_cell (table, i, j, "NA");
		    fprintf (stream, "\t%s", cell);
		    gdl_string_free (cell);
		}
		fprintf (stream, "\n");
	}
	return GDL_SUCCESS;
}

gdl_table *
gdl_table_clone (const gdl_table * t1)
{
	size_t i,j,k;
	gdl_table * t12 = 0;
	t12 = gdl_table_alloc(t1->nrow, t1->ncol);
	if (t12->ncol)
	{
		t12->var_index = GDL_MALLOC (size_t, t12->ncol);
		t12->var_types = GDL_MALLOC (unsigned char, t12->ncol);
	}
	t12->nfactor = t1->nfactor;
	t12->nvector = t1->nvector;
	for(i = 0; i < t12->nrow; i++)
	{
		t12->row_names[i] = gdl_string_clone (t1->row_names[i]);
	}
	for(i = 0; i < t1->ncol; i++)
	{
		t12->col_names[i] = gdl_string_clone (t1->col_names[i]);
		t12->var_index[i] = t1->var_index[i];
		t12->var_types[i] = t1->var_types[i];
	}
	if (t12->nfactor)
	{
		t12->level_by_factor = GDL_MALLOC (size_t, t12->nfactor);
		t12->levels = GDL_MALLOC (gdl_string **, t12->nfactor);
		t12->factors = GDL_MATRIX_ALLOC (int, t12->nfactor, t12->nrow);
		for(i = 0; i < t1->nfactor; i++)
		{
			t12->level_by_factor[i] = t1->level_by_factor[i];
			t12->levels[i] = GDL_MALLOC (gdl_string *, t1->level_by_factor[i]);
			for(k = 0; k <  t1->level_by_factor[i]; k++)
			{
				t12->levels[i][k] = gdl_string_clone (t1->levels[i][k]);
			}
			memcpy(t12->factors[i], t1->factors[i], sizeof(int)*t12->nrow);
		}
	}
	if (t12->nvector)
	{
		t12->vectors = GDL_MATRIX_ALLOC (double, t12->nvector, t12->nrow);
		for(i = 0; i < t1->nvector; i++)
		{
			memcpy(t12->vectors[i], t1->vectors[i], sizeof(int)*t12->nrow);
		}
	}
	return t12;
}

gdl_labeled_matrix *
gdl_table_design_matrix (const gdl_table * p)
{
	size_t i, j, k, l, v, M = 0, N;
	gdl_labeled_matrix * Xl;

	if (p->ncol==0)
	{
		return 0;
	}

	// number of samples
	N = p->nrow;
	// number of predictors
	for(i = 0; i < p->nfactor; i++)
	{
		M += p->level_by_factor[i]-1;
	}
	M += p->nvector;

	Xl = gdl_labeled_matrix_alloc (N, M);
	// fill the row names
	for(i = 0; i < N; i++)
	{
		Xl->row_names[i] = gdl_string_clone (p->row_names[i]);
	}
	// file the column names
	k = 0;
	for(i = l = 0; i < p->ncol; i++)
	{
		switch(p->var_types[i])
		{
			case 'f':
				for(j = 0; j < p->level_by_factor[l]-1; j++, k++)
				{
					Xl->col_names[k] = gdl_string_sprintf ("%s_%s", p->col_names[i], p->levels[l][j]);
				}
				l++;
				break;
			case 'v':
				Xl->col_names[k] = gdl_string_clone (p->col_names[i]);
				k++;
				break;
		}
	}
	// fill the design matrix
	k = 0;
	for(i = l = v = 0; i < p->ncol; i++)
	{
		switch(p->var_types[i])
		{
			case 'f':
				for(j = 0; j < N; j++)
				{
					if (p->factors[l][j] == p->level_by_factor[l] - 1)
						continue;
					gdl_matrix_set (Xl->X, j, k + p->factors[l][j], 1.0);
				}
				k += p->level_by_factor[l] - 1;
				l++;
				break;
			case 'v':
				for(j = 0; j < N; j++)
				{
					gdl_matrix_set (Xl->X, j, k, p->vectors[v][j]);
				}
				k++;
				v++;
				break;
		}
	}

	return Xl;
}

gdl_boolean
gdl_table_has_variable (const gdl_table * t, const gdl_string * name)
{
	size_t i;

	for(i = 0; i < t->ncol; i++)
	{
		if (!strcmp(t->col_names[i], name))
		{
			return gdl_true;
		}
	}

	return gdl_false;
}

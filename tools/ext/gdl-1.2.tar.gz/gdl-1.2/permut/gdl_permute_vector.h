#ifndef __GDL_PERMUTE_VECTOR_H__
#define __GDL_PERMUTE_VECTOR_H__

//#include <gdl/gdl_permute_vector_long_double.h>
#include <gdl/gdl_permute_vector_double.h>
//#include <gdl/gdl_permute_vector_float.h>

//#include <gdl/gdl_permute_vector_ulong.h>
//#include <gdl/gdl_permute_vector_long.h>
//
//#include <gdl/gdl_permute_vector_uint.h>
#include <gdl/gdl_permute_vector_int.h>

//#include <gdl/gdl_permute_vector_ushort.h>
//#include <gdl/gdl_permute_vector_short.h>
//
//#include <gdl/gdl_permute_vector_uchar.h>
//#include <gdl/gdl_permute_vector_char.h>

#endif /* __GDL_PERMUTE_VECTOR_H__ */

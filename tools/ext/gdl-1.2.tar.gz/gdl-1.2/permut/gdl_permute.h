#ifndef __GDL_PERMUTE_H__
#define __GDL_PERMUTE_H__

#include <gdl/gdl_permute_long_double.h>
#include <gdl/gdl_permute_double.h>
#include <gdl/gdl_permute_float.h>

#include <gdl/gdl_permute_ulong.h>
#include <gdl/gdl_permute_long.h>

#include <gdl/gdl_permute_uint.h>
#include <gdl/gdl_permute_int.h>

#include <gdl/gdl_permute_ushort.h>
#include <gdl/gdl_permute_short.h>

#include <gdl/gdl_permute_uchar.h>
#include <gdl/gdl_permute_char.h>

#endif /* __GDL_PERMUTE_H__ */

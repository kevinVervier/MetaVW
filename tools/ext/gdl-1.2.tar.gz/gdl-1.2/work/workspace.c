/*  
 * 	work/workspace.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
 
#include <gdl/gdl_common.h>
#include <gdl/gdl_workspace.h>

gdl_workspace *
gdl_workspace_alloc (gdl_runtime * run)
{
	gdl_workspace * w;
	
	w = GDL_MALLOC (gdl_workspace, 1);
	
	w->run  = run;
	
	w->data = NULL;
}

void
gdl_workspace_free (gdl_workspace * w)
{
	if ( w == 0 ) return;
	w->run  = NULL;
	w->data = NULL;
	GDL_FREE (w);
}

void
gdl_workspace_attach_data (gdl_workspace * w, gdl_gview * x)
{
	w->data = x;
}

gdl_gview *
gdl_workspace_detach_data (gdl_workspace * w)
{
	gdl_gview * x = w->data;
	w->data = NULL;
	return x;
}

gdl_gview *
gdl_workspace_get_data (gdl_workspace * w)
{
	return w->data;
}

gdl_runtime *
gdl_workspace_get_runtime (gdl_workspace * w)
{
	return w->run;	
}


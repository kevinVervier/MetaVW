/* test/results.c
 * 
 * Copyright (C) 1996, 1997, 1998, 1999, 2000 Gerard Jungman, Brian Gough
 * 
 * Modified by Jean-Baptiste Veyrieras, 2006.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_test.h>

static unsigned int tests = 0;
static unsigned int passed = 0;
static unsigned int failed = 0;
static unsigned int verbose = 1;

void
gdl_test (int status, const char *test_description,...)
{

  tests++;

  if (status == 0)
    {
      passed++;
      if (verbose)
        printf ("PASS: ");
    }
  else
    {
      failed++;
      if (verbose)
        printf ("FAIL: ");
    }

  if (verbose)
    {

      va_list ap;
      va_start (ap, test_description);
      vprintf (test_description, ap);
      va_end (ap);
      printf("\n");
      fflush (stdout);
    }
}



void
gdl_test_verbose (int v)
{
  verbose = v;
}

int
gdl_test_summary (void)
{

  if (verbose && 0)             /* FIXME: turned it off, this annoys me */
    printf ("%d tests, passed %d, failed %d.\n", tests, passed, failed);

  if (failed != 0)
    {

      if (verbose && 0)         /* FIXME: turned it off, this annoys me */
        {
          printf ("%d TEST%s FAILED.\n", failed, failed == 1 ? "" : "S");
        }
      return EXIT_FAILURE;
    }

  if (tests != passed + failed)
    {
      if (verbose)
        printf ("TEST RESULTS DO NOT ADD UP %d != %d + %d\n",
                tests, passed, failed);
      return EXIT_FAILURE;
    }

  if (passed == tests)
    {
      if (verbose && 0)         /* FIXME: turned it off, this annoys me */
        printf ("All tests passed successfully\n");
      return EXIT_SUCCESS;
    }

  return EXIT_FAILURE;
}

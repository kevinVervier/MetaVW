#! /bin/bash

DIR="run util gblock test gmatrix work nrec \
     gmap gview meta gpoint string hview hstruct pstruct hmap \
     view gpart fuzzy phase result \
     gstats labels pca gpca mask gglm \
     multireg graphics plot hsmap \
     dna locus"

for i in $DIR
do
echo "Enter directory $i";
cd $i;
rm -rf *.texi
for j in *.h
do
../headdoc.pl $i $j;
done
echo "Leave directory $i";
cd ..;
done

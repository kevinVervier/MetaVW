/*  
 * 	util/prog.c
 * 
 *  $Author: tflutre $, $Date: 2011/07/11 19:31:56 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
 
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_util.h>

/** \brief Display a progress bar.
 *
 * \param stream a stream (eg. a logger or stdout)
 * \param N display length of the bar (usually 25)
 * \param idx index of the current step
 * \param tot total number of steps
 */
int
gdl_progress_bar (FILE * stream, 
		  const size_t N, 
		  const size_t idx, 
		  const size_t tot)
{
  if (N <= 0 || tot <= 0)
  {
    GDL_ERROR_VAL ("Negative or null argument(s) to gdl_progress_bar()",
		   GDL_FAILURE,
		   1);
  }
  float bar_size = (tot < N) ? tot/N : 1;
  float bar_cur  = (idx+1) / bar_size;
  size_t i;
  if (idx)
  {
    for (i = 0; i < N+11; i++)
    {
      fprintf(stream, "\b");
      fflush(stream);
    }
  }
  fprintf (stream, "0\% |");
  fflush(stream);
  for (i = 0; i < N; i++)
  {
    if (i < bar_cur)
      fprintf(stream, "=");
    else
      fprintf (stream, " ");
    fflush(stream);
  }
  if (idx+1 < tot)
    fprintf (stream, "| %3.0f\%\r", 100*((double)idx+1)/tot);
  else
    fprintf (stream, "| 100\%\n");
  fflush(stream);
}

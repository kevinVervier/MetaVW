/*
 *  util/gdl_util.h
 *
 *  $Author: tflutre $, $Date: 2011/09/24 18:43:53 $, $Revision: 1.4 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#ifndef __GDL_UTIL_H__
#define __GDL_UTIL_H__

#include <time.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>

#define GDL_ARRAY_FREAD(type, num, stream) \
        ((type *) gdl_array_fread (sizeof(type), (num), (stream)))
#define GDL_ARRAY_FWRITE(vector, type, num, stream) \
        (gdl_array_fwrite ((vector), sizeof(type), (num), (stream)))

__BEGIN_DECLS

FILE * gdl_fileopen (const char * filename, char * mode);
void gdl_fileclose (const char * filename, FILE * stream);
size_t gdl_file_exists (const char * filename);
size_t gdl_file_get_nb_uncommented_lines (const gdl_string * filename);
int gdl_getline (gdl_string ** line, size_t * n, FILE * stream);
gdl_string * gdl_get_elapsed_time(time_t startRawTime, time_t endRawTime);

gdl_string * gdl_time2ascii (void);
void * gdl_array_fread (size_t atomic, size_t num, FILE * stream);
int gdl_array_fwrite (void * v, size_t atomic, size_t num, FILE * stream);
int gdl_getline (gdl_string ** line, size_t * n, FILE * stream);
int gdl_significant_star_fprintf (FILE * stream, const double value, const double thresh, const double mult, const size_t max);
int gdl_is_number(char *buffer);
int gdl_eoff(FILE *f);
int gdl_progress_bar (FILE * stream, const size_t ncount, const size_t cur, const size_t tot);

typedef struct
{
	size_t npop;
	size_t * pop_sizes;
	size_t ** popx;
	size_t ** pidx;
	size_t keepop;
} gdl_sub_sample_mapping_t;

void gdl_sub_sample_mapping_t_free (gdl_sub_sample_mapping_t * p);

gdl_sub_sample_mapping_t * gdl_sub_sample_mapping_by_pop (gdl_string ** samples, const size_t pop_sizes[], const size_t npop, gdl_string ** sub_samples, const size_t nsub_sample);

__END_DECLS

#endif /* __GDL_UTIL_H__ */

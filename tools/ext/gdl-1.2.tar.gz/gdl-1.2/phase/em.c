/*  
 * 	phase/em.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_gview.h>
#include <gdl/gdl_hview.h>
#include <gdl/gdl_view.h>
#include <gdl/gdl_phase_em.h>

gdl_phase_em_param *
gdl_phase_em_param_alloc (const gdl_view * v,
                          const gdl_mask * m,
                          const gdl_rng * rng,
                          double pmt)
{
	gdl_phase_em_param * P;
	
	P = GDL_MALLOC (gdl_phase_em_param, 1);
	
	P->v = v;
	P->m = m;
	P->r = rng;
	P->pmt = pmt;
	
	return P;
}

void
gdl_phase_em_param_free (gdl_phase_em_param * P)
{
	GDL_FREE (P);
}

gdl_phase_em_workspace *
gdl_phase_em_workspace_alloc (const gdl_phase_em_workspace_type * T,
                                    gdl_phase_em_param * P)
{
	gdl_phase_em_workspace * w;
	
	w = GDL_MALLOC (gdl_phase_em_workspace, 1);
	
	w->type = T;
	
	w->param = P;
	
	w->state = gdl_malloc (w->type->size);
	
	(w->type->alloc)(w->state, P);
	
	return w;
}

void
gdl_phase_em_workspace_free (gdl_phase_em_workspace * w)
{
	if (w)
	{
		(w->type->free)(w->state);
		GDL_FREE (w->state);
		gdl_phase_em_param_free (w->param);
		GDL_FREE (w);
	}	
}

int
gdl_phase_em_workspace_init_rng (gdl_phase_em_workspace * w)
{
	return (w->type->init_rng)(w->state);
}

int
gdl_phase_em_workspace_init_static (gdl_phase_em_workspace * w, void * start)
{
	return (w->type->init_static)(w->state, start);
}


int
gdl_phase_em_workspace_iterate (gdl_phase_em_workspace * w)
{
	return (w->type->iterate)(w->state);	
}

double
gdl_phase_em_workspace_loglikelihood (const gdl_phase_em_workspace * w)
{
	return (w->type->loglikelihood)(w->state);
}

double
gdl_phase_em_workspace_residual_abs (const gdl_phase_em_workspace * w)
{
	return (w->type->residual_abs)(w->state);
}

double
gdl_phase_em_workspace_residual_sq (const gdl_phase_em_workspace * w)
{
	return (w->type->residual_sq)(w->state);
}

void *
gdl_phase_em_workspace_result (const gdl_phase_em_workspace * w)
{
	return (w->type->result)(w->state);	
}

int
gdl_phase_em_workspace_fread (FILE * stream, gdl_phase_em_workspace * w)
{
		
}

int
gdl_phase_em_workspace_fwrite (FILE * stream, const gdl_phase_em_workspace * w)
{
	
}

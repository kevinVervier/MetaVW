#ifndef __GDL_VECTOR_H__
#define __GDL_VECTOR_H__

#include <gdl/gdl_vector_long_double.h>
#include <gdl/gdl_vector_double.h>
#include <gdl/gdl_vector_float.h>

#include <gdl/gdl_vector_ulong.h>
#include <gdl/gdl_vector_long.h>

#include <gdl/gdl_vector_uint.h>
#include <gdl/gdl_vector_int.h>

#include <gdl/gdl_vector_ushort.h>
#include <gdl/gdl_vector_short.h>

#include <gdl/gdl_vector_uchar.h>
#include <gdl/gdl_vector_char.h>


#endif /* __GDL_VECTOR_H__ */

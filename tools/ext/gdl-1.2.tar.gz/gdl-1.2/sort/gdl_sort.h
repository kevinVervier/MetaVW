#ifndef __GDL_SORT_H__
#define __GDL_SORT_H__

#include <gdl/gdl_sort_long_double.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_sort_float.h>

#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_sort_long.h>

#include <gdl/gdl_sort_uint.h>
#include <gdl/gdl_sort_int.h>

#include <gdl/gdl_sort_ushort.h>
#include <gdl/gdl_sort_short.h>

#include <gdl/gdl_sort_uchar.h>
#include <gdl/gdl_sort_char.h>

#endif /* __GDL_SORT_H__ */

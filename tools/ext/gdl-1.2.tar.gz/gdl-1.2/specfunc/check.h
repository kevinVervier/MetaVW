/* check for underflow */

#define CHECK_UNDERFLOW(r) if (fabs((r)->val) < GDL_DBL_MIN) GDL_ERROR("underflow", GDL_EUNDRFLW);

/* Author:  G. Jungman */

        
/* Convenience header */
#ifndef __GDL_SPECFUNC_H__
#define __GDL_SPECFUNC_H__

#include <gdl/gdl_sf.h>

#endif /* __GDL_SPECFUNC_H__ */

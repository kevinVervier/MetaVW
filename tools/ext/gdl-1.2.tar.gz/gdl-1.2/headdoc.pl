#! /usr/bin/perl

use strict;
use IO::File;

my $ATOMIC;
my $POINTER;
my $FUNCTION;
my $SIGNATURE;

my $DIR    = $ARGV[0];
my $stream = new IO::File ($ARGV[1], "r") || die "$! $ARGV[1] ";
my $output = new IO::File ($DIR.".texi", "a") || die "$!";


while (<$stream>)
{
   chomp;
   if (/^\s*(\S+)\s*(\*{0,2})\s*([^\(]+)\s*\(\s*([^\)]+)\)\s*;\s*$/)
   {
      if ($3 !~ /\*/)
      {
	   $ATOMIC=$1;
	   $POINTER=$2;
	   $FUNCTION=$3;
	   $SIGNATURE=$4;
           print $output "\@deftypefun ";
	   print $output "{" if ($POINTER ne "");
	   print $output $ATOMIC," ",$POINTER;
           print $output "} " if ($POINTER ne "");
           print $output $FUNCTION," (";
	   print $output $SIGNATURE,")\n";
           print $output "\@end deftypefun\n";
	   print $output "This function...\n";
	   print $output "\n";
      }
   }
}
close ($stream);
close ($output);

##
# Attempt of R code for the online sparse coding
# algorihtm of Mairal et al. (2009)
##
rng_signal<-function(n=10,m=10)
{
   X<-matrix(0,nrow=m,ncol=n)
   u<-rnorm(m,mean=5)
   v<-rnorm(m,mean=-5)
   for(i in 1:n/2)
   {
      for(j in 1:m) 
      {
          X[j,i] <- rnorm(1, mean=v[j], sd=0.25)
      }
   }
   for(i in (n/2+1):n)
   {
      for(j in 1:m) 
      {
          X[j,i] <- rnorm(1, mean=u[j], sd=0.25)
      }
   }
   X
}

rng_dico<-function(X,k=10)
{
   m    <- dim(X)[1]
   D    <- matrix(rnorm(m*k),nrow=m,ncol=k)
   u    <- sqrt(apply(D^2, 2, sum))
   D    <- scale(D, center=FALSE, scale=u)
   D
}

sc_enet<-function(X,D,lambda=0.1,alpha=0.9)
{
   n     <- dim(X)[2]
   alpha <- matrix(0, nrow=n, ncol=dim(D)[2])
   for(i in 1:n)
   {
      sc        <- glmnet(D, X[,i], family="gaussian", alpha=alpha, lambda=lambda)
      alpha[i,] <- sc$beta[,1]
   }
   alpha
}

online_dico_learning<-function(X,D0,lambda=0.1,T=5,neta=512,alpha=0.9)
{
   require(glmnet)
   k    <- dim(D0)[2]
   m    <- dim(X)[1]
   n    <- dim(X)[2]
   neta <- min(c(neta, n))
   A    <- matrix(0, nrow=k, ncol=k)
   B    <- matrix(0, nrow=m, ncol=k)
   D    <- D0
   for(t in 1:T)
   {
      xt    <- sample(1:n, neta)
      Xt    <- X[,xt]
      # Sparse Coding
      for(i in 1:neta)
      {
         sc    <- glmnet(D, Xt[,i], family="gaussian", alpha=alpha, lambda=lambda)
         alpha <- matrix(sc$beta[,1], ncol=1, nrow=length(sc$beta))
         A     <- A + alpha%*%t(alpha)/neta
         B     <- B + Xt[,i,drop=FALSE]%*%t(alpha)/neta
      }
      # Dictionary Learning
      Dt <- D
      for(i in 1:5)
      {
         for(j in 1:k)
         {
             uj     <- (1/A[j,j])*(B[,j]-Dt%*%A[,j,drop=FALSE]) + Dt[,j]
             Dt[,j] <- uj/max(c(sqrt(sum(uj^2)),1))
         }
         epsilon <- sum(apply((D-Dt)^2,2,sum))
         cat("Epsilon = ", epsilon,"\n")
         D       <- Dt
         if (epsilon < 1.e-5)
         {
            break
         }
      }
   }
   D
}


/*  
 *  pstruct/gdl_pstruct_odb.h
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:29 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_meta.h>
#include <gdl/gdl_odb.h>
#include <gdl/gdl_pstruct_result.h>

static gdl_meta *
_gdl_pstruct_result_meta (const void * obj)
{
	gdl_meta_tag * tag;
	gdl_meta * meta = gdl_meta_alloc ();
	gdl_pstruct_result * work = (gdl_pstruct_result *) obj;
	
	tag = gdl_meta_tag_alloc ();
	gdl_meta_tag_name (tag, "K");
	gdl_meta_tag_value (tag, "%d", gdl_pstruct_result_population_size (work));
	gdl_meta_add (meta, tag);
	tag = gdl_meta_tag_alloc ();
	gdl_meta_tag_name (tag, "loglikelihood");
	gdl_meta_tag_value (tag, "%.1f", gdl_pstruct_result_loglikelihood (work));
	gdl_meta_add (meta, tag);
	
	return meta;
}

static void *
_gdl_pstruct_result_fread (FILE * stream)
{
	return gdl_pstruct_result_fread (stream);
}

static int
_gdl_pstruct_result_fwrite (FILE * stream, const void * obj)
{
	const gdl_pstruct_result * result = (gdl_pstruct_result *) obj;
	return gdl_pstruct_result_fwrite (stream, result);
}

static int
_gdl_pstruct_result_fprintf (FILE * stream, const void * obj)
{
	const gdl_pstruct_result * result = (gdl_pstruct_result *) obj;
	return gdl_pstruct_result_fprintf (stream, result);
}

static const gdl_odriver _gdl_pstruct_result_driver =
{
    "gdl_pstruct_result",
    "1.0",
    &_gdl_pstruct_result_meta,
    &_gdl_pstruct_result_fread,
    &_gdl_pstruct_result_fwrite,
    &_gdl_pstruct_result_fprintf
};

const gdl_odriver * gdl_pstruct_result_driver = &_gdl_pstruct_result_driver;

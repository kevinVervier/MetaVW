/*  
 *  pstruct/import.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:29 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <math.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_hview.h>
#include <gdl/gdl_clustering.h>
#include <gdl/gdl_pstruct.h>
#include <gdl/gdl_pstruct_result.h>

//struct _gdl_pstruct_result 
//{
//	const gdl_pstruct_workspace_type * type;
//   size_t k;
//  	size_t n;
//  	size_t p;
//  	size_t l;
//  	size_t tna;
//  	size_t * na;
//  	gdl_hnblock  * f;
//  	gdl_block    * q;
//  	double       * pi;
//  	double loglikelihood;
//  	double residual;
//  	double tw_residual;
//  	gdl_glabels  * labels;
//};

gdl_pstruct_result *
gdl_pstruct_result_structure_read (FILE * stream, const gdl_gview * data)
{
   if (!stream)
   {
   	return 0;
   }
   
   int ch;
   size_t i,n, k;
   gdl_string * line=0;
   gdl_string * tmp;
   gdl_pstruct_result * result;
   
   result = GDL_CALLOC (gdl_pstruct_result, 1);
 	
 	for(;;)
 	{  
 		if (gdl_getline (&line, &n, stream)==-1)
 			break;
 		if (n)
 		{
 			tmp = strtok (line, " ");
 			if (!strcmp(line, "Run parameters:"))
 			{
 				//printf ("%s\n", strtok (line, " "));
 				for(i=0;i<3;i++) {gdl_string_free(line);line=0;gdl_getline (&line, &n, stream);}
 				//printf ("K = %s\n", strtok (line, " "));
 				result->k = atoi(strtok (line, " "));
 			}
 			if (!strcmp(tmp, "Estimated"))
 			{
 				tmp = strtok (line, "=");
 				tmp = strtok (0, "=");
 				result->loglikelihood = (double)atof(tmp);
 				printf ("LOG = %g\n", result->loglikelihood);
 			}
		   // result parameter
		   
		   // ancestries
		   
		   // frequencies
		   
		   // type
 		}
 		gdl_string_free (line);line=0;
 	}
 	
 	return result;
}

/*  
 *  pstruct/criter.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:29 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_pstruct.h>
#include <gdl/gdl_pstruct_result.h>
#include <gdl/gdl_pstruct_criterion.h>

struct _gdl_pstruct_criterion 
{
	const gdl_pstruct_result * r;
};

gdl_pstruct_criterion *
gdl_pstruct_criterion_alloc (const gdl_pstruct_result * r)
{
	gdl_pstruct_criterion * c;
	
	c = GDL_MALLOC (gdl_pstruct_criterion, 1);
	
	c->r = r;
	
	return c;	
}

void
gdl_pstruct_criterion_free (gdl_pstruct_criterion * c)
{
	GDL_FREE (c);	
}

double
gdl_pstruct_criterion_value (const gdl_pstruct_criterion * c, const gdl_pstruct_criterion_type * T)
{
	return (T->value)(c->r);
}

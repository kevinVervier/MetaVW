/*
 *  bayreg/view.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:24:37 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <math.h>
#include <stdio.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_machine.h>
#include <gdl/gdl_bayesian_regression.h>

gdl_bayreg_model_view *
gdl_bayreg_model_view_alloc (const gdl_bayreg_model * m)
{
	gdl_bayreg_model_view * v;

	v = GDL_CALLOC (gdl_bayreg_model_view, 1);

	if (m->puradd)
	{
		v->puradd = GDL_CALLOC (gdl_bayreg_model_subview, 1);
		v->puradd->grid_ignore = GDL_CALLOC (gdl_boolean, m->puradd->g->size);
		v->puradd->grid_skip   = GDL_CALLOC (gdl_boolean, m->puradd->g->size);
	}
	if (m->adddom)
	{
		v->adddom = GDL_CALLOC (gdl_bayreg_model_subview, 1);
		v->adddom->grid_ignore = GDL_CALLOC (gdl_boolean, m->adddom->g->size);
		v->adddom->grid_skip   = GDL_CALLOC (gdl_boolean, m->adddom->g->size);
	}
	if (m->resdom)
	{
		v->resdom = GDL_CALLOC (gdl_bayreg_model_subview, 1);
		v->resdom->grid_ignore = GDL_CALLOC (gdl_boolean, m->resdom->g->size);
		v->resdom->grid_skip   = GDL_CALLOC (gdl_boolean, m->resdom->g->size);
	}

	return v;
}

static void
gdl_bayreg_model_subview_free (gdl_bayreg_model_subview * sv)
{
	if (sv)
	{
		GDL_FREE (sv->grid_ignore);
		GDL_FREE (sv->grid_skip);
		GDL_FREE (sv);
	}
}

void
gdl_bayreg_model_view_free (gdl_bayreg_model_view * v)
{
	if (v)
	{
		gdl_bayreg_model_subview_free (v->puradd);
		gdl_bayreg_model_subview_free (v->adddom);
		gdl_bayreg_model_subview_free (v->resdom);
		GDL_FREE (v);
	}
}

static void
gdl_bayreg_model_subview_summary(gdl_bayreg_model_subview * sv, const size_t n)
{
	size_t i, ni=0, ns=0;

	if (sv->ignore || sv->skip)
	{
		for(i = 0; i < n; i++)
		{
			sv->grid_ignore[i] = sv->ignore;
			sv->grid_skip[i]   = (sv->skip || sv->ignore);
		}
	}
	else
	{
		for(i = 0; i < n; i++)
		{
			ni += (sv->grid_ignore[i]);
			ns += (sv->grid_skip[i]);
		}
		if (ni == n)
		{
			sv->ignore = gdl_true;
			sv->skip   = gdl_true;
		}
		if (ns == n)
		{
			sv->skip = gdl_true;
		}
	}
}

static gdl_bayreg_model_subview *
gdl_bayreg_model_subview_fread (FILE * stream, const size_t n)
{
	if (stream)
	{
		int status;
		gdl_bayreg_model_subview * sv;

		sv = GDL_CALLOC (gdl_bayreg_model_subview, 1);

		sv->grid_ignore = GDL_MALLOC (gdl_boolean, n);
		sv->grid_skip   = GDL_MALLOC (gdl_boolean, n);

		status = fread (sv->grid_ignore, sizeof(gdl_boolean), n, stream);
		GDL_FREAD_STATUS (status, n, NULL);
		status = fread (sv->grid_skip, sizeof(gdl_boolean), n, stream);
		GDL_FREAD_STATUS (status, n, NULL);

		gdl_bayreg_model_subview_summary(sv, n);

		return sv;
	}

	return 0;
}

gdl_bayreg_model_view *
gdl_bayreg_model_view_fread (FILE * stream, const gdl_bayreg_model * m)
{
	if (stream)
	{
		int status;
		gdl_bayreg_model_view * v;

		v = GDL_CALLOC (gdl_bayreg_model_view, 1);

		if (m->puradd)
		{
			v->puradd = gdl_bayreg_model_subview_fread (stream, m->puradd->g->size);
			GDL_FREAD_STATUS (v->puradd!=0, 1, NULL);
		}
		if (m->adddom)
		{
			v->adddom = gdl_bayreg_model_subview_fread (stream, m->adddom->g->size);
			GDL_FREAD_STATUS (v->adddom!=0, 1, NULL);
		}
		if (m->resdom)
		{
			v->resdom = gdl_bayreg_model_subview_fread (stream, m->resdom->g->size);
			GDL_FREAD_STATUS (v->resdom!=0, 1, NULL);
		}

		return v;
	}

	return 0;
}

static int
gdl_bayreg_model_subview_fwrite (FILE * stream, const gdl_bayreg_model_subview * sv, const size_t n)
{
	if (stream && sv)
	{
		int status;

		status = fwrite (sv->grid_ignore, sizeof(gdl_boolean), n, stream);
		GDL_FWRITE_STATUS (status, n, 1);
		status = fwrite (sv->grid_skip, sizeof(gdl_boolean), n, stream);
		GDL_FWRITE_STATUS (status, n, 1);

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}

int
gdl_bayreg_model_view_fwrite (FILE * stream, const gdl_bayreg_model_view * v, const gdl_bayreg_model * m)
{
	if (stream && v && m)
	{
		int status;

		if (m->puradd)
		{
			status = gdl_bayreg_model_subview_fwrite (stream, v->puradd, m->puradd->g->size);
			GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		}
		if (m->adddom)
		{
			status = gdl_bayreg_model_subview_fwrite (stream, v->adddom, m->adddom->g->size);
			GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		}
		if (m->resdom)
		{
			status = gdl_bayreg_model_subview_fwrite (stream, v->resdom, m->resdom->g->size);
			GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		}

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}

void
gdl_bayreg_model_view_summary (gdl_bayreg_model_view * v, const gdl_bayreg_model * m)
{
	if (m->puradd)
	{
		gdl_bayreg_model_subview_summary (v->puradd, m->puradd->g->size);
	}
	if (m->adddom)
	{
		gdl_bayreg_model_subview_summary (v->adddom, m->adddom->g->size);
	}
	if (m->resdom)
	{
		gdl_bayreg_model_subview_summary (v->resdom, m->resdom->g->size);
	}
}

static void
_gdl_bayreg_model_theta_init_storage (gdl_bayreg_model_theta * t, const size_t size)
{
	t->size      = size;
	t->values    = GDL_MALLOC (double **, t->size);
	t->nt        = GDL_MALLOC (size_t, t->size);
	t->names     = GDL_MALLOC (gdl_string *, t->size);
}

static void
_gdl_bayreg_model_theta_push_grid (gdl_bayreg_model_theta * t,
		                           const size_t ti,
		                           const gdl_string * name,
		                           const gdl_bayreg_grid * g,
		                           const gdl_bayreg_model_subview * sv)
{
	size_t i, j, size=0;

	for(i = 0; i < g->size; i++)
	{
		size += (sv->grid_skip[i]) ? 0 : 1;
	}
	if (size)
	{
		t->values[ti] = GDL_MALLOC (double *, size);
		t->nt[ti]     = size;
		t->names[ti]  = gdl_string_clone (name);
		for(i = j = 0; i < g->size; i++)
		{
			if (sv->grid_skip[i])
			{
				continue;
			}
			(t->nvalue)++;
			t->values[ti][j++] = &(g->weight[i]);
		}
	}
}

gdl_bayreg_model_theta *
gdl_bayreg_model_parameters_view (const gdl_bayreg_model * m, gdl_bayreg_model_view * v)
{
	size_t p,i=0,nm=0;
	gdl_bayreg_model_theta * t;

	gdl_bayreg_model_view_summary (v, m);

	t = GDL_CALLOC (gdl_bayreg_model_theta, 1);

	if (m->puradd && !(v->puradd->skip)) {t->size += 1;nm++;}
	if (m->adddom && !(v->adddom->skip)) {t->size += 1;nm++;}
	if (m->resdom && !(v->resdom->skip)) {t->size += 2;nm++;}

	if (nm==1)
	{
		if (m->puradd && !(v->puradd->skip))
		{
			_gdl_bayreg_model_theta_init_storage (t, t->size);
			_gdl_bayreg_model_theta_push_grid (t, 0, "additive model (sigma)", m->puradd->g, v->puradd);
		}
		if (m->adddom && !(v->adddom->skip))
		{
			_gdl_bayreg_model_theta_init_storage (t, t->size);
			_gdl_bayreg_model_theta_push_grid (t, 0, "additive+dominance model (sigma)", m->adddom->g, v->adddom);
		}
		if (m->resdom && !(v->resdom->skip))
		{
			_gdl_bayreg_model_theta_init_storage (t, t->size);
			t->nt[0]        = 2;
			t->names[0]     = gdl_string_sprintf ("recessive+dominance model (weight)");
			t->values[0][0] = &(m->resdom->pres);
			t->values[0][1] = &(m->resdom->pdom);
			_gdl_bayreg_model_theta_push_grid (t, 0, "recessive+dominance model (sigma)", m->resdom->g, v->resdom);
		}
	}
	else if (nm > 1)
	{
		_gdl_bayreg_model_theta_init_storage (t, t->size+1);

		t->values[0] = GDL_MALLOC (double *, nm);
		t->nt[0]     = nm;
		t->names[0]  = gdl_string_sprintf ("model type (weight)");
		t->nvalue    = nm;

		i  = 1;
		nm = 0;
		if (m->puradd)
		{
			const gdl_bayreg_grid * g = m->puradd->g;
			t->values[0][nm++] = &(m->puradd->w);
			_gdl_bayreg_model_theta_push_grid (t, i, "additive model (sigma)", m->puradd->g, v->puradd);
			i++;
		}
		if (m->adddom)
		{
			const gdl_bayreg_grid * g = m->adddom->g;
			t->values[0][nm++] = &(m->adddom->w);
			_gdl_bayreg_model_theta_push_grid (t, i, "additive+dominance model (sigma)", m->adddom->g, v->adddom);
			i++;
		}
		if (m->resdom)
		{
			const gdl_bayreg_grid * g = m->resdom->g;
			t->values[0][nm++] = &(m->resdom->w);
			t->values[i] = GDL_MALLOC (double *, 2);
			t->nt[i]     = 2;
			t->names[i]  = gdl_string_sprintf ("recessive+dominance model (weight)");
			t->values[i][0] = &(m->resdom->pres);
			t->values[i][1] = &(m->resdom->pdom);
			t->nvalue+=2;
			i++;
			_gdl_bayreg_model_theta_push_grid (t, i, "recessive+dominance model (sigma)", m->resdom->g, v->resdom);
			i++;
		}
	}

	return t;
}

size_t
gdl_bayreg_model_parameter_size_view (const gdl_bayreg_model * m, gdl_bayreg_model_view * v)
{
	size_t i, np = 0, nm = 0;

	gdl_bayreg_model_view_summary (v, m);

	if (m->puradd && !(v->puradd->ignore))
	{
		np += m->puradd->g->size;
		nm++;
	}
	if (m->adddom && !(v->adddom->ignore))
	{
		np += m->adddom->g->size;
		nm++;
	}
	if (m->resdom && !(v->resdom->ignore))
	{
		np += m->resdom->g->size + 1;
		nm++;
	}
	np += (nm) ? nm-1 : 0;

	return np;
}

double
gdl_bayreg_model_average_zip_bf_view (const gdl_bayreg_model * m, const gdl_bayreg_model_view * v, const gdl_bayreg_bf_zip * zip, const double w0, const double w1, const double w2, const double w3, const double wt)
{
	size_t i;
	double bf0=0,bf1=0,bf2=0,bf3=0;

	for(i = 0; i < zip->n; i++)
	{
		switch(zip->m[i])
		{
			case 0:
				if (m->puradd && !(v->puradd->ignore || v->puradd->grid_ignore[zip->w[i]]))
				{
					bf0 += (m->puradd->g->weight[zip->w[i]]*zip->bf[i]*m->puradd->w)/(w0*wt);
				}
				break;
			case 1:
				if (m->adddom && !(v->adddom->ignore || v->adddom->grid_ignore[zip->w[i]]))
				{
					bf1 += (m->adddom->g->weight[zip->w[i]]*zip->bf[i]*m->adddom->w)/(w1*wt);
				}
				break;
			case 2:
				if (m->resdom && !(v->resdom->ignore || v->resdom->grid_ignore[zip->w[i]]))
				{
					bf2 += (m->resdom->g->weight[zip->w[i]]*zip->bf[i]*m->resdom->w*m->resdom->pres)/(w2*w3*wt);
				}
				break;
			case 3:
				if (m->resdom && !(v->resdom->ignore || v->resdom->grid_ignore[zip->w[i]]))
				{
					bf3 += (m->resdom->g->weight[zip->w[i]]*zip->bf[i]*m->resdom->w*m->resdom->pdom)/(w2*w3*wt);
				}
				break;
		}
	}

	return (bf0+bf1+bf2+bf3);

}

double
gdl_bayreg_model_best_zip_bf_view (const gdl_bayreg_model * m,
		                           const gdl_bayreg_model_view * v,
		                           const gdl_bayreg_bf_zip * zip,
		                           size_t * which,
		                           const double w0,
		                           const double w1,
		                           const double w2,
		                           const double w3,
		                           const double wt)
{
	size_t i, imax = 0;
	double bfi, max = 0;

	for(i = 0; i < zip->n; i++)
	{
		switch(zip->m[i])
		{
			case 0:
				if (m->puradd && !(v->puradd->ignore || v->puradd->grid_ignore[zip->w[i]]))
				{
					 bfi = (m->puradd->g->weight[zip->w[i]]*zip->bf[i]*m->puradd->w)/(w0*wt);
					 if (bfi > max)
					 {
						max  = bfi;
						imax = i;
					 }
				}
				break;
			case 1:
				if (m->adddom && !(v->adddom->ignore || v->adddom->grid_ignore[zip->w[i]]))
				{
					bfi = (m->adddom->g->weight[zip->w[i]]*zip->bf[i]*m->adddom->w)/(w1*wt);
					if (bfi > max)
					{
						max  = bfi;
						imax = i;
					}
				}
				break;
			case 2:
				if (m->resdom && !(v->resdom->ignore || v->resdom->grid_ignore[zip->w[i]]))
				{
					bfi = (m->resdom->g->weight[zip->w[i]]*zip->bf[i]*m->resdom->w*m->resdom->pres)/(w2*w3*wt);
					if (bfi > max)
					{
						max  = bfi;
						imax = i;
					}
				}
				break;
			case 3:
				if (m->resdom && !(v->resdom->ignore || v->resdom->grid_ignore[zip->w[i]]))
				{
					bfi = (m->resdom->g->weight[zip->w[i]]*zip->bf[i]*m->resdom->w*m->resdom->pdom)/(w2*w3*wt);
					if (bfi > max)
					{
						max  = bfi;
						imax = i;
					}
				}
				break;
		}
	}
	*which = imax;
	return max;
}

void
gdl_bayreg_model_average_zip_w_view (const gdl_bayreg_model * m,
		                             const gdl_bayreg_model_view * v,
		                             double * w0,
		                             double * w1,
		                             double * w2,
		                             double * w3,
		                             double * wt)
{
	size_t p;

	*w0 = *w1 = *w2 = *w3 = *wt = 0;

	if (m->puradd && !v->puradd->ignore)
	{
		*wt += m->puradd->w;
		const gdl_bayreg_grid * g = m->puradd->g;
		for(p = 0; p < g->size; p++)
		{
			if (v->puradd->grid_ignore[p])
			{
				continue;
			}
			*w0 += g->weight[p];
		}
	}
	if (m->adddom && !v->adddom->ignore)
	{
		*wt += m->adddom->w;
		const gdl_bayreg_grid * g = m->adddom->g;
		for(p = 0; p < g->size; p++)
		{
			if (v->adddom->grid_ignore[p])
			{
				continue;
			}
			*w1 += g->weight[p];
		}
	}
	if (m->resdom && !v->resdom->ignore)
	{
		*wt += m->resdom->w;
		*w3 += m->resdom->pres;
		*w3 += m->resdom->pdom;
		const gdl_bayreg_grid * g = m->resdom->g;
		for(p = 0; p < g->size; p++)
		{
			if (v->resdom->grid_ignore[p])
			{
				continue;
			}
			*w2 += g->weight[p];
		}
	}
}


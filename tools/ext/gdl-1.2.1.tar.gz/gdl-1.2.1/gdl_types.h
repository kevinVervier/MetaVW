/* gdl_types.h
 */
#ifndef __GDL_TYPES_H__
#define __GDL_TYPES_H__

#ifndef GDL_VAR

#ifdef WIN32
#  ifdef GDL_DLL
#    ifdef DLL_EXPORT
#      define GDL_VAR extern __declspec(dllexport)
#    else
#      define GDL_VAR extern __declspec(dllimport)
#    endif
#  else
#    define GDL_VAR extern
#  endif
#else
#  define GDL_VAR extern
#endif

#endif

#endif /* __GDL_TYPES_H__ */

/*
 *  expr/gene_f.c
 *
 *  $Author: tflutre $, $Date: 2011/07/10 22:28:26 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, University of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

/** \brief Count the probes of a given gene and summarize their expression levels.
 *
 * \param c chromosome
 * \param idx index of the given gene
 * \param p parameter
 * \return Y summarized expression at the gene level
*/
double **
gdl_expr_feature_gene_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p)
{
	size_t i, j, k, np = 0;
	double ** Y  = 0;

	// count the nb of probes non-ignored and having an expression level
	for(np = i = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		k=i;
		np++;
	}
    if (np > 1)
    {
    	gdl_string * gene_index = gdl_hashtable_lookup (p->values, "GeneIndex");

    	if (gene_index && (!strcmp(gene_index, "e2g") && c->genes[idx[0]]->nexon > 1))
    	{
    		size_t e, es, ne = c->genes[idx[0]]->nexon;
    		double *** X = GDL_MALLOC (double **, ne);

    		// First, exon by exon summarization
    		for(e = es = 0; e < ne; e++)
    		{
    			np = 0;
    			for(i = 0; i < c->genes[idx[0]]->nprobe; i++)
    			{
    				gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
					if (probe->ignore == 'y' || probe->data == 0)
					{
						continue;
					}
					for(j = 0; j < probe->nexon; j++)
					{
						if (probe->gx_idx[j] == idx[0] && probe->ex_idx[j] == e)
						{
							np++;
							break;
						}
					}
    			}
    			if (np)
    			{
    				idx[1]  = e;
    				X[es++] = gdl_expr_feature_exon_data (c, idx, p);
    			}
    		}

    		// Second, gene summarization from exon levels
    		Y = gdl_expr_summarize (X, es, c->npop, c->pop_sizes, p);

    		for(e = 0; e < es; e++)
    		{
    			GDL_MATRIX_FREE (X[e], c->npop);
    		}
    		GDL_FREE (X);
    	}
    	else
    	{
			double *** X = GDL_MALLOC (double **, np);

			for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
			{
				gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
				if (probe->ignore == 'y' || probe->data == 0)
				{
					continue;
				}
				X[j++] = probe->data;
			}

			Y = gdl_expr_summarize (X, np, c->npop, c->pop_sizes, p);

			GDL_FREE (X);
    	}
    }
    else if (np==1)
    {
    	Y = GDL_MALLOC(double *, c->npop);
		for(i = 0; i < c->npop; i++)
		{
		   Y[i] = GDL_MALLOC (double, c->pop_sizes[i]);
		   memcpy(Y[i], c->probes[c->genes[idx[0]]->probe_idx[k]]->data[i], sizeof(double)*c->pop_sizes[i]);
		}
    }

	return Y;
}

/** \brief Summarize the expression levels over all probes
 *         for each gene of a given chromosome.
 */
static int
_gdl_expr_feature_gene_alloc (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
	size_t i, j, k, l, * idx, ngene = 0;
	size_t min_probe = 1;

	if (progress)
	{
		fprintf (progress, ">>Create gene features for Chromosome %s\n", c->name);
		fflush (progress);
	}
	if (!c->ngene)
	{
		GDL_WARNING ("No gene defined for that chromosome\n", GDL_EINVAL);
		f->nfeature = 0;
		f->features = 0;
		return GDL_EINVAL;
	}
	if (p)
	{
		gdl_string * min_probe_str = gdl_hashtable_lookup (p->values, "MinimumProbeNumber");
		if (min_probe_str)
		{
			min_probe = (size_t)atoi(min_probe_str);
		}
	}
	// how many gene with at least one probe within having an expression level
	for(i = 0; i < c->ngene; i++)
	{
		for(k = j = 0; j < c->genes[i]->nprobe; j++)
		{
			gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[j]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
			k++;
		}
		if (k >= min_probe)
		{
			ngene += 1;
		}
	}
	if (progress)
	{
		fprintf (progress, " #Gene(s) with >=%ld non-ignored probe(s) having an expression level = %ld\n", min_probe, ngene);
		fflush (progress);
	}

	f->nfeature = ngene;
	f->features = GDL_MALLOC (gdl_expr_feature *, ngene);

	for(i = j = 0; i < c->ngene; i++)
	{
		for(k = l = 0; l < c->genes[i]->nprobe; l++)
		{
			gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[l]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
			k++;
		}
		if (k >= min_probe)
		{
			idx    = GDL_MALLOC (size_t, 2);
			idx[0] = i;
			f->features[j]         = gdl_expr_feature_alloc (gdl_expr_feature_gene, &i);
			f->features[j]->data   = gdl_expr_feature_gene_data(c, idx, p);
			f->features[j]->name   = gdl_string_clone (c->genes[i]->name);
			f->features[j]->nprobe = k;
			f->features[j]->probe_idx = GDL_MALLOC (size_t, f->features[j]->nprobe);
			for(k = l = 0; l < c->genes[i]->nprobe; l++)
			{
				gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[l]];
				if (probe->ignore == 'y' || probe->data == 0)
				{
					continue;
				}
				f->features[j]->probe_idx[k++] = c->genes[i]->probe_idx[l];
			}
			gdl_expr_feature_set_probe_positions (c, f->features[j]);
			j++;
			GDL_FREE (idx);
		}
	}

	return GDL_SUCCESS;
}

static void *
_gdl_expr_feature_gene_get (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]];
}

static const long *
_gdl_expr_feature_gene_starts (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->ntxStart;
	return c->genes[idx[0]]->txStarts;
}

static const long *
_gdl_expr_feature_gene_ends (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->ntxEnd;
	return c->genes[idx[0]]->txEnds;
}

static unsigned char
_gdl_expr_feature_gene_strand (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->strand;
}

static size_t
_gdl_expr_feature_gene_unit_size (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->ntx;
}

static void
_gdl_expr_feature_gene_unit_starts(const gdl_expr_chromosome * c, const size_t idx[], long starts[])
{
	size_t  i;
	for(i = 0; i < c->genes[idx[0]]->ntx; i++)
	{
		starts[i] = c->genes[idx[0]]->transcripts[i]->txStart;
	}
}

static void
_gdl_expr_feature_gene_unit_ends(const gdl_expr_chromosome * c, const size_t idx[], long ends[])
{
	size_t  i;
	for(i = 0; i < c->genes[idx[0]]->ntx; i++)
	{
		ends[i] = c->genes[idx[0]]->transcripts[i]->txEnd;
	}
}

static long
_gdl_expr_feature_gene_unit_start (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->transcripts[unit_idx]->txStart;
}

static long
_gdl_expr_feature_gene_unit_end (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->transcripts[unit_idx]->txEnd;
}

static gdl_expr_feature_entities *
_gdl_expr_feature_gene_unit_entities (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	gdl_expr_feature_entities * e = GDL_CALLOC (gdl_expr_feature_entities, 1);

	e->gene       = c->genes[idx[0]];
	e->transcript = e->gene->transcripts[unit_idx];

	return e;
}

static const gdl_expr_feature_type _gdl_expr_feature_gene =
{
	"gdl_expr_feature_gene",
	"gene",
	1,
	&_gdl_expr_feature_gene_alloc,
	&_gdl_expr_feature_gene_get,
	&_gdl_expr_feature_gene_starts,
	&_gdl_expr_feature_gene_ends,
	&_gdl_expr_feature_gene_strand,
	&gdl_expr_feature_gene_data,
	&_gdl_expr_feature_gene_unit_size,
	&_gdl_expr_feature_gene_unit_starts,
	&_gdl_expr_feature_gene_unit_ends,
	&_gdl_expr_feature_gene_unit_start,
	&_gdl_expr_feature_gene_unit_end,
	&_gdl_expr_feature_gene_unit_entities
};

const gdl_expr_feature_type * gdl_expr_feature_gene       = &_gdl_expr_feature_gene;

/*
 *  expr/probe.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_sort.h>
#include <gdl/gdl_statistics.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_specfunc.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_expr_probe.h>
#include <gdl/gdl_expr_chromosome.h>

gdl_expr_probe *
gdl_expr_probe_alloc (const gdl_string * name, const unsigned char strand, long * start, long * end, const size_t nunit)
{
	gdl_expr_probe * p;

	p = GDL_CALLOC (gdl_expr_probe, 1);

	p->name    = gdl_string_clone (name);
	p->npos    = nunit;
	p->starts  = start;
	p->ends    = end;
	p->ignore  = 'n';
	p->strand  = strand;

	return p;
}

void
gdl_expr_probe_free (gdl_expr_probe * p, const size_t npop)
{
	if (p)
	{
		if (p->data)
		{
			size_t i;
			for (i = 0; i < npop; i++)
			{
				GDL_FREE (p->data[i]);
			}
			GDL_FREE (p->data);
		}
		GDL_FREE (p->starts);
		GDL_FREE (p->ends);
		GDL_FREE (p->ex_idx);
		GDL_FREE (p->gx_idx);
		gdl_string_free (p->name);
		GDL_FREE (p);
	}
}


gdl_expr_probe *
gdl_expr_probe_fread (FILE * stream, const size_t npop, const size_t * pop_sizes)
{
	if (stream)
	{
		int status;
		size_t size;
		long * end, * start;
		unsigned char has, strand;
		gdl_string * name;
		gdl_expr_probe * p;

		status = fread(&size, sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&strand, sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		start = GDL_MALLOC (long, size);
		status = fread(start, sizeof(long), size, stream);
		GDL_FREAD_STATUS (status, size, NULL);
		end = GDL_MALLOC (long, size);
		status = fread(end, sizeof(long), size, stream);
		GDL_FREAD_STATUS (status, size, NULL);
		name = gdl_string_fread (stream);
		GDL_FREAD_STATUS (name!=0, 1, NULL);

		p = gdl_expr_probe_alloc (name, strand, start, end, size);

		gdl_string_free (name);

		status = fread(&(has), sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		if (npop && has == 'y')
		{
			size_t i;
			p->data = GDL_CALLOC (double *, npop);
			for (i = 0; i < npop; i++)
			{
				if (pop_sizes[i])
				{
					p->data[i] = GDL_MALLOC (double, pop_sizes[i]);
					status = fread(p->data[i], sizeof(double), pop_sizes[i], stream);
					GDL_FREAD_STATUS (status, pop_sizes[i], NULL);
				}
			}
		}

		status = fread(&(p->ignore), sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		status = fread(&(p->nexon), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		if (p->nexon)
		{
			p->gx_idx = GDL_MALLOC (size_t, p->nexon);
			status = fread(p->gx_idx, sizeof(size_t), p->nexon, stream);
			GDL_FREAD_STATUS (status, p->nexon, NULL);
			p->ex_idx = GDL_MALLOC (size_t, p->nexon);
			status = fread(p->ex_idx, sizeof(size_t), p->nexon, stream);
			GDL_FREAD_STATUS (status, p->nexon, NULL);
		}

		return p;
	}
	return 0;
}

int
gdl_expr_probe_fwrite (FILE * stream, const gdl_expr_probe * p, const size_t npop, const size_t * pop_sizes)
{
	if (stream && p)
	{
		int status;
		unsigned char has;

		status = fwrite(&p->npos, sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, NULL);
		status = fwrite(&p->strand, sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, NULL);
		status = fwrite(p->starts, sizeof(long), p->npos, stream);
		GDL_FWRITE_STATUS (status, p->npos, NULL);
		status = fwrite(p->ends, sizeof(long), p->npos, stream);
		GDL_FWRITE_STATUS (status, p->npos, NULL);
		status = gdl_string_fwrite (stream, p->name);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, NULL);
		has = (p->data) ? 'y' : 'n';
		status = fwrite(&(has), sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, NULL);
		if (npop && has == 'y')
		{
			size_t i;
			for (i = 0; i < npop; i++)
			{
				if (pop_sizes[i])
				{
					status = fwrite(p->data[i], sizeof(double), pop_sizes[i], stream);
					GDL_FWRITE_STATUS (status, pop_sizes[i], NULL);
				}
			}

		}
		status = fwrite(&p->ignore, sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, NULL);

		status = fwrite(&(p->nexon), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, NULL);

		if (p->nexon)
		{
			status = fwrite(p->gx_idx, sizeof(size_t), p->nexon, stream);
			GDL_FWRITE_STATUS (status, p->nexon, NULL);
			status = fwrite(p->ex_idx, sizeof(size_t), p->nexon, stream);
			GDL_FWRITE_STATUS (status, p->nexon, NULL);
		}

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

gdl_boolean
gdl_expr_probe_is_missing (const gdl_expr_probe * p, const size_t i, const size_t j)
{
	if (gdl_isnan(p->data[i][j]))
	{
		return gdl_true;
	}
	return gdl_false;
}

size_t
gdl_expr_probe_add_exon (gdl_expr_probe * p, const size_t g, const size_t e)
{
	if (p->nexon)
	{
		size_t * tmp = GDL_MALLOC (size_t, p->nexon + 1);
		memcpy(tmp, p->ex_idx, sizeof(size_t)*p->nexon);
		GDL_FREE (p->ex_idx);
		p->ex_idx = tmp;
		tmp = GDL_MALLOC (size_t, p->nexon + 1);
		memcpy(tmp, p->gx_idx, sizeof(size_t)*p->nexon);
		GDL_FREE (p->gx_idx);
		p->gx_idx = tmp;
	}
	else
	{
		p->ex_idx = GDL_MALLOC (size_t, 1);
		p->gx_idx = GDL_MALLOC (size_t, 1);
	}
	p->gx_idx[p->nexon] = g;
	p->ex_idx[p->nexon] = e;

	return ++(p->nexon);
}

/*
 *  expr/gdl_expr_exon.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_EXON_H__
#define __GDL_EXPR_EXON_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_expr_exon.h>
#include <gdl/gdl_expr_probe.h>
#include <gdl/gdl_expr_transcript.h>

__BEGIN_DECLS

/*! \struct gdl_expr_exon
 *  \brief An exon
 *
 *  An exon is the smaller unit of a gene. In partice it corresponds
 *  to any transcripted units within the gene region
 */
struct gdl_expr_exon
{
	size_t start;				/**< The 5' starting position of the exon           */
	size_t end;					/**< The 3' ending position of the exon             */
	size_t ntx;	                /**< The number of transcripts containing this exon */
	size_t * tx_idx;            /**< The transcript indexes (within the gene)       */
	size_t nprobe;				/**< The number of probes interogate this exon      */
	size_t * probe_idx;			/**< The probe indexes		  				        */
};

/*! \typedef gdl_expr_exon
 *  \brief A gene
 */
typedef struct gdl_expr_exon gdl_expr_exon;

gdl_expr_exon * gdl_expr_exon_alloc (const size_t start, const size_t end);
void gdl_expr_exon_free (gdl_expr_exon * g);
gdl_expr_exon * gdl_expr_exon_clone (const gdl_expr_exon * gene);
gdl_expr_exon * gdl_expr_exon_fread (FILE * stream);
int gdl_expr_exon_fwrite (FILE * stream, const gdl_expr_exon * g);

size_t gdl_expr_exon_add_tx (gdl_expr_exon * e, const size_t tx);

__END_DECLS

#endif

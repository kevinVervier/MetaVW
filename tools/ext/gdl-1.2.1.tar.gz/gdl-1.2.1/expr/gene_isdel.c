/*
 *  expr/gene_isdel.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_expr_gene.h>

static double
_get_fraction (const long s1, const long e1, const long s2, const long e2)
{
	if (s1 >= s2 && e1 <= e2)
	{
		return 1.0;
	}
	else if (s2 >= s1 && e2 <= e1)
	{
		return ((double)(e2-s2+1))/(e1-s1+1);
	}
	else if (s1 < s2 && (e1 >= s2 && e1 <= e2))
	{
		return ((double)(e1-s2+1))/(e1-s1+1);
	}
	else if (e1 > e2 && (s1 >= s2 && s1 <= e2))
	{
		return ((double)(e2-s1+1))/(e1-s1+1);
	}
	return 0.0;
}

// Return the fraction of the tx that is depleted by the deletion
double
gdl_expr_gene_is_del_within(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	return _get_fraction (tx->txStart, tx->txEnd, position, position+size);
}

double
gdl_expr_gene_is_del_5utr(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (gene->strand == '+')
	{
		return _get_fraction(tx->txStart, tx->cdsStart, position, position+size);
	}
	else
	{
		return _get_fraction(tx->cdsEnd, tx->txEnd, position, position+size);
	}
}

double
gdl_expr_gene_is_del_3utr(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (gene->strand == '+')
	{
		return _get_fraction(tx->cdsEnd, tx->txEnd, position, position+size);
	}
	else
	{
		return _get_fraction(tx->txStart, tx->cdsStart, position, position+size);
	}
}

double
gdl_expr_gene_is_del_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i;
	double w = 0;

	for(i = 0; i < tx->nexon; i++)
	{
	    w += _get_fraction(gene->exons[tx->exon_idx[i]]->start, gene->exons[tx->exon_idx[i]]->end, position, position+size);
	}

	return w / tx->nexon;
}

double
gdl_expr_gene_is_del_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i;
	double w = 0;

	for(i = 0; i < tx->nexon-1; i++)
	{
		w += _get_fraction(gene->exons[tx->exon_idx[i]]->end, gene->exons[tx->exon_idx[i+1]]->start, position, position+size);
	}

	return w / tx->nexon;
}

double
gdl_expr_gene_is_del_cds_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i, n = 0;
	double w = 0;

	for(i = 0; i < tx->nexon-1; i++)
	{
		if (gene->exons[tx->exon_idx[i]]->end > tx->cdsEnd || gene->exons[tx->exon_idx[i+1]]->start < tx->cdsStart)
		{
			continue;
		}
		w += _get_fraction(GDL_MAX(tx->cdsStart, gene->exons[tx->exon_idx[i]]->end), GDL_MIN(tx->cdsEnd, gene->exons[tx->exon_idx[i+1]]->start), position, position+size);
		n++;
	}

	return (n) ? w / n : 0.0;
}

double
gdl_expr_gene_is_del_non_cds_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i, n = 0;
	double w = 0;

	for(i = 0; i < tx->nexon-1; i++)
	{
		if (gene->exons[tx->exon_idx[i]]->end >= tx->cdsStart && gene->exons[tx->exon_idx[i+1]]->start <= tx->cdsEnd)
		{
			continue;
		}
		if (gene->exons[tx->exon_idx[i]]->end < tx->cdsStart && gene->exons[tx->exon_idx[i+1]]->start > tx->cdsStart)
		{
			w += _get_fraction(gene->exons[tx->exon_idx[i]]->end, tx->cdsStart, position, position+size);
			n++;
		}
		if (gene->exons[tx->exon_idx[i]]->end < tx->cdsEnd && gene->exons[tx->exon_idx[i+1]]->start > tx->cdsEnd)
		{
			w += _get_fraction(tx->cdsEnd, gene->exons[tx->exon_idx[i+1]]->start, position, position+size);
			n++;
		}
	}

	return (n) ? w / n : 0.0;
}

double
gdl_expr_gene_is_del_first_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (tx->nexon == 1)
	{
		return 0.0;
	}
	if (gene->strand == '+')
	{
		return _get_fraction(GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->end), GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[1]]->start), position, position+size);
	}
	else
	{
		return _get_fraction(GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->start), GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-2]]->end), position, position+size);
	}
}

double
gdl_expr_gene_is_del_last_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (tx->nexon <= 2)
	{
		return 0.0;
	}
	if (gene->strand == '-')
	{
		return _get_fraction(GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->end), GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[1]]->start), position, position+size);
	}
	else
	{
		return _get_fraction(GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->start), GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-2]]->end), position, position+size);
	}
}

double
gdl_expr_gene_is_del_cds_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i, n = 0;
	double w = 0;

	for(i = 0; i < tx->nexon; i++)
	{
		if (gene->exons[tx->exon_idx[i]]->start > tx->cdsEnd || gene->exons[tx->exon_idx[i]]->end < tx->cdsStart)
		{
			continue;
		}
		w += _get_fraction(GDL_MAX(tx->cdsStart, gene->exons[tx->exon_idx[i]]->start), GDL_MIN(tx->cdsEnd, gene->exons[tx->exon_idx[i]]->end), position, position+size);
		n++;
	}

	return (n) ? w / n : 0.0;
}

double
gdl_expr_gene_is_del_non_cds_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	size_t i, n = 0;
	double w = 0;

	for(i = 0; i < tx->nexon; i++)
	{
		if (gene->exons[tx->exon_idx[i]]->start >= tx->cdsStart && gene->exons[tx->exon_idx[i]]->end <= tx->cdsEnd)
		{
			continue;
		}
		if (gene->exons[tx->exon_idx[i]]->start < tx->cdsStart && gene->exons[tx->exon_idx[i]]->end > tx->cdsStart)
		{
			w += _get_fraction(gene->exons[tx->exon_idx[i]]->start, tx->cdsStart, position, position+size);
			n++;
		}
		if (gene->exons[tx->exon_idx[i]]->start < tx->cdsEnd && gene->exons[tx->exon_idx[i]]->end > tx->cdsEnd)
		{
			w += _get_fraction(tx->cdsEnd, gene->exons[tx->exon_idx[i]]->end, position, position+size);
			n++;
		}
	}

	return (n) ? w / n : 0.0;
}

double
gdl_expr_gene_is_del_first_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (tx->nexon == 1)
	{
		return 0.0;
	}
	if (gene->strand == '+')
	{
		return _get_fraction(GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->start), GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->end), position, position+size);
	}
	else
	{
		return _get_fraction(GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->start), GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->end), position, position+size);
	}
}

double
gdl_expr_gene_is_del_last_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, const long size)
{
	if (tx->nexon == 1)
	{
		return 0.0;
	}
	if (gene->strand == '-')
	{
		return _get_fraction(GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->start), GDL_MIN(tx->cdsStart, gene->exons[tx->exon_idx[0]]->end), position, position+size);
	}
	else
	{
		return _get_fraction(GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->start), GDL_MAX(tx->cdsEnd, gene->exons[tx->exon_idx[tx->nexon-1]]->end), position, position+size);
	}
}


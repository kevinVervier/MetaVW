/*
 *  expr/gdl_expr_meta_exon.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2010  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_META_EXON_H__
#define __GDL_EXPR_META_EXON_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_vector_uint.h>
#include <gdl/gdl_expr_gene.h>
#include <gdl/gdl_expr_exon.h>

__BEGIN_DECLS

/*! \struct gdl_expr_meta_exon
 *  \brief A meta exon
 *
 *  A meta exon is a combination of several overlapping exons
 */
struct gdl_expr_meta_exon
{
	size_t nex;				/**< The number of overlapping exons          */
	size_t npr;		        /**< The number of probes for that meta exon  */
	size_t ntx;             /**< The number of transcripts including at least one overlapping exons */
	size_t * ex_idx;        /**< The exon indexes                          */
	size_t * tx_idx;        /**< The transcript indexes                    */
	size_t * pr_idx;        /**< The probes indexes                        */
	size_t nexStart;		/**< The number of exon starts 				   */
	size_t nexEnd;          /**< The number of exon ends  				   */
	size_t * exStarts; 		/**< The exon starts 				           */
	size_t * exEnds; 		/**< The exon ends 				               */
	size_t ntxStart;		/**< The number of tx starts 				   */
	size_t ntxEnd;          /**< The number of tx ends  				   */
	size_t * txStarts; 		/**< The tx starts 				               */
	size_t * txEnds; 		/**< The tx ends 				               */
};

/*! \typedef gdl_expr_meta_exon
 *  \brief A probe
 */
typedef struct gdl_expr_meta_exon gdl_expr_meta_exon;

gdl_expr_meta_exon * gdl_expr_meta_exon_alloc (const size_t nex, const size_t ntx, const size_t npr);
void gdl_expr_meta_exon_free (gdl_expr_meta_exon * b);

gdl_expr_meta_exon * gdl_expr_meta_exon_fread (FILE * stream);
int gdl_expr_meta_exon_fwrite (FILE * stream, const gdl_expr_meta_exon * p);

__END_DECLS

#endif

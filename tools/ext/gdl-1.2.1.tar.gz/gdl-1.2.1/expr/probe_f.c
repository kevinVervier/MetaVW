/*
 *  expr/probe_f.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

static int
_gdl_expr_feature_probe_alloc (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
	size_t i, j, k, * idx, np = 0;
	gdl_string * method;

	// how many active probes
	//printf ("PROBE %p %d %c %p\n", c->probes[i], i, c->probes[i]->ignore, c->probes[i]->data);
	if (c->ngene)
	{
		for(i = 0; i < c->nprobe; i++)
		{
			if ((c->probes[i]->ignore != 'y' && c->probes[i]->data != 0) && c->probes[i]->nexon != 0)
			{
				np++;
			}
		}
	}
	else
	{
		for(i = 0; i < c->nprobe; i++)
		{
			if (c->probes[i]->ignore != 'y' && c->probes[i]->data != 0)
			{
				np++;
			}
		}
	}

	if (np)
	{
		f->nfeature = np;
		f->features = GDL_MALLOC (gdl_expr_feature *, f->nfeature);

		idx = GDL_MALLOC (size_t, 2);

		if (c->ngene)
		{
			for(i = j = 0; i < c->nprobe; i++)
			{
				gdl_expr_probe * probe = c->probes[i];
				if ((probe->ignore == 'y' || probe->data==0) || probe->nexon==0)
				{
					continue;
				}
				gdl_expr_gene * gene = c->genes[probe->gx_idx[0]];
				idx[0] = probe->gx_idx[0]; // By default we assign the probe to the first gene of the list
				for(k = 0; k < gene->nprobe; k++)
				{
					if (gene->probe_idx[k] == i)
					{
						break;
					}
				}
				if (k == gene->nprobe)
				{
					GDL_ERROR_VAL ("Internal error", GDL_FAILURE, GDL_FAILURE);
				}
				idx[1] = k;
				f->features[j] = gdl_expr_feature_alloc (gdl_expr_feature_probe, idx);
				f->features[j]->data = probe->data;
				if ((method = gdl_hashtable_lookup (p->values, "SummarizationMethod"))!=0)
				{
					if (!strcmp(method, "qnorm"))
					{
						f->features[j]->data = gdl_expr_summarize_qnorm (&(f->features[j]->data), 1, c->npop, c->pop_sizes);
					}
				}
				f->features[j]->nprobe = 1;
				f->features[j]->probe_idx = GDL_MALLOC (size_t, 1);
				f->features[j]->probe_idx[0] = i;
				f->features[j]->name = gdl_string_clone (probe->name);
				gdl_expr_feature_set_probe_positions (c, f->features[j]);
				j++;
			}
//			for(k = j = 0; k < c->ngene; k++)
//			{
//				for(i = 0; i < c->genes[k]->nprobe; i++)
//				{
//					gdl_expr_probe * probe = c->probes[c->genes[k]->probe_idx[i]];
//					if (probe->ignore == 'y' || probe->data==0)
//					{
//						continue;
//					}
//					idx[0] = k;
//					idx[1] = i;
//					f->features[j] = gdl_expr_feature_alloc (gdl_expr_feature_probe, idx);
//					f->features[j]->data = probe->data;
//					f->features[j]->nprobe = 1;
//					f->features[j]->probe_idx = GDL_MALLOC (size_t, 1);
//					f->features[j]->probe_idx[0] = c->genes[k]->probe_idx[i];
//					f->features[j]->name = gdl_string_clone (probe->name);
//					gdl_expr_feature_set_probe_positions (c, f->features[j]);
//					j++;
//				}
//			}
		}
		else
		{
			for(i = j = 0; i < c->nprobe; i++)
			{
				gdl_expr_probe * probe = c->probes[i];
				if (probe->ignore == 'y' || probe->data==0)
				{
					continue;
				}
				idx[0] = idx[1] = i;
				f->features[j] = gdl_expr_feature_alloc (gdl_expr_feature_probe, idx);
				f->features[j]->data = probe->data;
				if ((method = gdl_hashtable_lookup (p->values, "SummarizationMethod"))!=0)
				{
					if (!strcmp(method, "qnorm"))
					{
						f->features[j]->data = gdl_expr_summarize_qnorm (&(f->features[j]->data), 1, c->npop, c->pop_sizes);
					}
				}
				f->features[j]->nprobe = 1;
				f->features[j]->probe_idx = GDL_MALLOC (size_t, 1);
				f->features[j]->probe_idx[0] = i;
				f->features[j]->name = gdl_string_clone (probe->name);
				gdl_expr_feature_set_probe_positions (c, f->features[j]);
				j++;
			}
		}
		GDL_FREE (idx);
	}

	return GDL_SUCCESS;
}

static void *
_gdl_expr_feature_probe_get (const gdl_expr_chromosome * c, const size_t idx[])
{
	if (c->ngene)
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]];
	else
		return c->probes[idx[0]];
}

static const long *
_gdl_expr_feature_probe_starts (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	if (c->ngene)
	{
		*n = c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->npos;
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->starts;
	}
	else
	{
		*n = c->probes[idx[0]]->npos;
		return c->probes[idx[0]]->starts;
	}
}

static const long *
_gdl_expr_feature_probe_ends (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	if (c->ngene)
	{
		*n = c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->npos;
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->ends;
	}
	else
	{
		*n = c->probes[idx[0]]->npos;
		return c->probes[idx[0]]->ends;
	}
}

static unsigned char
_gdl_expr_feature_probe_strand (const gdl_expr_chromosome * c, const size_t idx[])
{
	if (c->ngene)
	{
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->strand;
	}
	else
	{
		return c->probes[idx[0]]->strand;
	}
}

static double **
_gdl_expr_feature_probe_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * parameter)
{
	if (c->ngene)
	{
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->data;
	}
	else
	{
		return c->probes[idx[0]]->data;
	}
}

static size_t
_gdl_expr_feature_probe_unit_size (const gdl_expr_chromosome * c, const size_t idx[])
{
	if (c->ngene)
	{
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->npos;
	}
	else
	{
		return c->probes[idx[0]]->npos;
	}
}

static void
_gdl_expr_feature_probe_unit_starts(const gdl_expr_chromosome * c, const size_t idx[], long starts[])
{
	size_t i;
	if (c->ngene)
	{
		for(i = 0; i < c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->npos; i++)
		{
			starts[i] = c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->starts[i];
		}
	}
	else
	{
		for(i = 0; i < c->probes[idx[0]]->npos; i++)
		{
			starts[i] = c->probes[idx[0]]->starts[i];
		}
	}
}

static void
_gdl_expr_feature_probe_unit_ends(const gdl_expr_chromosome * c, const size_t idx[], long ends[])
{
	size_t i;
	if (c->ngene)
	{
		for(i = 0; i < c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->npos; i++)
		{
			ends[i] = c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->ends[i];
		}
	}
	else
	{
		for(i = 0; i < c->probes[idx[0]]->npos; i++)
		{
			ends[i] = c->probes[idx[0]]->ends[i];
		}
	}
}

static long
_gdl_expr_feature_probe_unit_start (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	if (c->ngene)
	{
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->starts[unit_idx];
	}
	else
	{
		return c->probes[idx[0]]->starts[unit_idx];
	}
}

static long
_gdl_expr_feature_probe_unit_end (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	if (c->ngene)
	{
		return c->probes[c->genes[idx[0]]->probe_idx[idx[1]]]->ends[unit_idx];
	}
	else
	{
		return c->probes[idx[0]]->ends[unit_idx];
	}
}

static gdl_expr_feature_entities *
_gdl_expr_feature_probe_unit_entities (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	gdl_expr_feature_entities * e = GDL_CALLOC (gdl_expr_feature_entities, 1);
	if (c->ngene)
	{
		e->gene  = c->genes[idx[0]];
		e->probe = c->probes[e->gene->probe_idx[idx[1]]];
	}
	else
	{
		e->probe = c->probes[idx[0]];
	}
	return e;
}

static const gdl_expr_feature_type _gdl_expr_feature_probe =
{
	"gdl_expr_feature_probe",
	"probe",
	2,
	&_gdl_expr_feature_probe_alloc,
	&_gdl_expr_feature_probe_get,
	&_gdl_expr_feature_probe_starts,
	&_gdl_expr_feature_probe_ends,
	&_gdl_expr_feature_probe_strand,
	&_gdl_expr_feature_probe_data,
	&_gdl_expr_feature_probe_unit_size,
	&_gdl_expr_feature_probe_unit_starts,
	&_gdl_expr_feature_probe_unit_ends,
	&_gdl_expr_feature_probe_unit_start,
	&_gdl_expr_feature_probe_unit_end,
	&_gdl_expr_feature_probe_unit_entities
};

const gdl_expr_feature_type * gdl_expr_feature_probe = &_gdl_expr_feature_probe;

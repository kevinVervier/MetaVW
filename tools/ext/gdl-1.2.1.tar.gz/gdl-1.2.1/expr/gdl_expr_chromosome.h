/*
 *  expr/gdl_expr_chromosome.h
 *
 *  $Author: tflutre $, $Date: 2011/07/10 21:15:45 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_CHROMOSOME_H__
#define __GDL_EXPR_CHROMOSOME_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_expr_gene.h>
#include <gdl/gdl_expr_probe.h>
#include <gdl/gdl_expr_prbtxset.h>
#include <gdl/gdl_expr_prbexset.h>

__BEGIN_DECLS

typedef struct
{
	gdl_string    * name;		/**< The name of the chromosome */
	size_t        npop;			/**< The number of populations */
	size_t		  nsample;      /**< The total number of samples */
	size_t        * pop_sizes;  /**< The number of samples per population */
	size_t        ngene;		/**< The number of genes  */
	size_t        nprobe;		/**< The number of probes */
	gdl_expr_gene  ** genes;		/**< The genes  */
	gdl_expr_probe ** probes;	/**< The probes */
	// utilities
	gdl_hashtable * _gene_dico;		/**< The gene dictionary (for fast retrieve by name) */
	gdl_hashtable * _probe_dico;	/**< The probe dictionary (for fast retrieve by name) */
} gdl_expr_chromosome;

gdl_expr_chromosome * gdl_expr_chromosome_alloc (gdl_string * name, const size_t npop);
void gdl_expr_chromosome_free (gdl_expr_chromosome * c);

gdl_expr_chromosome * gdl_expr_chromosome_fread (FILE * stream);
int gdl_expr_chromosome_fwrite (FILE * stream, const gdl_expr_chromosome * c);

int gdl_expr_chromosome_fscanf_annotation (FILE * stream, gdl_expr_chromosome * c);
int gdl_expr_chromosome_fscanf_annotation2 (FILE * stream, gdl_expr_chromosome * c);
int gdl_expr_chromosome_fscanf_expression (FILE * stream, const size_t pop, gdl_expr_chromosome * chrom, const gdl_string * na_token);
int gdl_expr_chromosome_fscanf_exon_expression (FILE * stream, const size_t pop, gdl_expr_chromosome * chrom, const gdl_string * na_token);
int gdl_expr_chromosome_fscanf_txtable (FILE * stream, gdl_expr_chromosome * c);
int gdl_expr_chromosome_fscanf_txtable2 (FILE * stream, gdl_expr_chromosome * chrom);

int gdl_expr_chromosome_map_probe (gdl_expr_chromosome * c, FILE * logger);
int gdl_exp_chromosome_ngenes_with_probe (gdl_expr_chromosome * c);
int gdl_expr_chromosome_init_global_gene_measurment (gdl_expr_chromosome * c);
int gdl_expr_chromosome_init_global_exon_measurment (gdl_expr_chromosome * c);
int gdl_expr_chromosome_create_prbwindow (gdl_expr_chromosome * c, const long window, FILE * logger);
gdl_expr_prbtxset ** gdl_expr_prbtxset_create (gdl_expr_chromosome * c, const size_t gx, gdl_expr_gene * gene, size_t * n);
gdl_expr_prbexset ** gdl_expr_prbexset_create (gdl_expr_chromosome * c, const size_t gx, gdl_expr_gene * gene, size_t * n);

int gdl_expr_chromosome_fprintf (const gdl_expr_chromosome * c, gdl_string ** pop_names, const gdl_string * output);

__END_DECLS

#endif

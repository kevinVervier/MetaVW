/*
 *  expr/gdl_expr_transcript.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_TRANSCRIPT_H__
#define __GDL_EXPR_TRANSCRIPT_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_hash.h>

__BEGIN_DECLS

/*! \struct gdl_expr_transcript
 *  \brief A transcript
 *
 *  A transcript is an exon path
 */
struct gdl_expr_transcript
{
	gdl_string * name;          /**< The name of the transcript                           */
	size_t nexon;			    /**< The number of probes falling into that transcript    */
	size_t * exon_idx;			/**< The indexes of the exon from 5' to 3'                */
	size_t nprobe;				/**< The number of probes interogate this transcript      */
	size_t * probe_idx;			/**< The probe indexes								      */
	size_t txStart;				/**< The 5' starting position of the tx */
	size_t txEnd;				/**< The 3' ending position of the tx */
	size_t cdsStart;			/**< The 5' ending position of the cds within the tx */
	size_t cdsEnd;				/**< The 3' ending position of the cds within the tx */
};

/*! \typedef gdl_expr_transcript
 *  \brief A gene
 */
typedef struct gdl_expr_transcript gdl_expr_transcript;

gdl_expr_transcript * gdl_expr_transcript_alloc (const gdl_string * name, const size_t nexon);
void gdl_expr_transcript_free (gdl_expr_transcript * g);
gdl_expr_transcript * gdl_expr_transcript_clone (const gdl_expr_transcript * gene);
gdl_expr_transcript * gdl_expr_transcript_fread (FILE * stream);
int gdl_expr_transcript_fwrite (FILE * stream, const gdl_expr_transcript * g);
size_t gdl_expr_transcript_add_probe (gdl_expr_transcript * p, const size_t e);

__END_DECLS

#endif

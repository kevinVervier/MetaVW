/*
 *  expr/exon_f.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

static double **
_gdl_expr_feature_transcript_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p)
{
	size_t i, j, np=0;
	double ** Y = 0;
	gdl_expr_prbtxset * pts = c->genes[idx[0]]->prbtxsets[idx[1]];

	for(i = 0; i < pts->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		np++;
	}
	if (np > 1)
	{
		double *** X = GDL_MALLOC (double **, np);

	    for(i = j = 0; i < pts->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
			X[j++] = probe->data;
		}

		Y = gdl_expr_summarize (X, np, c->npop, c->pop_sizes, p);

		GDL_FREE (X);
	}
	else
	{
		for(i = 0; i < pts->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
			if (probe->ignore != 'y' && probe->data != 0)
			{
				break;
			}
	    }
		Y = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]]->data;
	}

	return Y;
}

static int
_gdl_expr_feature_transcript_alloc (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
	size_t i, j, k, l, m, * idx, npts = 0;
	size_t min_probe;

	if (progress)
	{
		fprintf (progress, ">>Create Transcript Features for Chromosome %s\n", c->name);
		fflush (progress);
	}
	if (!c->ngene)
	{
		GDL_WARNING ("No gene defined for that chromosome\n", GDL_EINVAL);
		f->nfeature = 0;
		f->features = 0;
		return GDL_EINVAL;
	}
	if (p)
	{
		gdl_string * min_probe_str = gdl_hashtable_lookup (p->values, "MinimumProbeNumber");
		if (min_probe_str)
		{
			min_probe = (size_t)atoi(min_probe_str);
		}
	}
	// how many probe transcript set ??
	for(i = 0; i < c->ngene; i++)
	{
		for(j = 0; j < c->genes[i]->nprbtxset; j++)
		{
			for(l = k = 0; k < c->genes[i]->prbtxsets[j]->nprobe; k++)
			{
				gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbtxsets[j]->probe_idx[k]]];
				if (probe->ignore == 'y' || probe->data == 0)
				{
					l++;
				}
			}
			if (l < c->genes[i]->prbtxsets[j]->nprobe)
			{
				npts += 1;
			}
		}
	}
	if (progress)
	{
		fprintf (progress, " #Transcript(i.e set of tx with at least one common probe) = %ld\n", npts);
		fflush (progress);
	}

	if (npts)
	{
		f->nfeature = npts;
		f->features = GDL_MALLOC (gdl_expr_feature *, npts);

		idx = GDL_MALLOC (size_t, 2);

		for(i = k = 0; i < c->ngene; i++)
		{
			idx[0] = i;
			for(j = 0; j < c->genes[i]->nprbtxset; j++)
			{
				for(l = m = 0; m < c->genes[i]->prbtxsets[j]->nprobe; m++)
				{
					gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbtxsets[j]->probe_idx[m]]];
					if (probe->ignore == 'y' || probe->data == 0)
					{
						l++;
					}
				}
				if (l < c->genes[i]->prbtxsets[j]->nprobe)
				{
					idx[1] = j;
					f->features[k]           = gdl_expr_feature_alloc (gdl_expr_feature_transcript, idx);
					f->features[k]->data     = _gdl_expr_feature_transcript_data(c, idx, p);
					f->features[k]->nprobe   = c->genes[i]->prbtxsets[j]->nprobe - l;
					f->features[k]->probe_idx = GDL_MALLOC (size_t, f->features[k]->nprobe);
					for(m = l = 0; m < c->genes[i]->prbtxsets[j]->nprobe; m++)
					{
						gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbtxsets[j]->probe_idx[m]]];
						if (probe->ignore == 'y' || probe->data == 0)
						{
							continue;
						}
						f->features[k]->probe_idx[l++] = c->genes[i]->probe_idx[c->genes[i]->prbtxsets[j]->probe_idx[m]];
					}
					gdl_expr_feature_set_probe_positions (c, f->features[k]);
					gdl_expr_feature_create_name (c, f->features[k], c->genes[i]->name);
					k++;
				}
			}
		}

		GDL_FREE (idx);
	}

	return GDL_SUCCESS;
}

static void *
_gdl_expr_feature_transcript_get (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->prbtxsets[idx[1]];
}

static const long *
_gdl_expr_feature_transcript_starts (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->prbtxsets[idx[1]]->ntxStart;
	return c->genes[idx[0]]->prbtxsets[idx[1]]->txStarts;
}

static const long *
_gdl_expr_feature_transcript_ends (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->prbtxsets[idx[1]]->ntxEnd;
	return c->genes[idx[0]]->prbtxsets[idx[1]]->txEnds;
}

static unsigned char
_gdl_expr_feature_transcript_strand (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->strand;
}

static size_t
_gdl_expr_feature_transcript_unit_size (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->prbtxsets[idx[1]]->ntx;
}

static void
_gdl_expr_feature_transcript_unit_starts(const gdl_expr_chromosome * c, const size_t idx[], long starts[])
{
	size_t i;
	for(i = 0; i < c->genes[idx[0]]->prbtxsets[idx[1]]->ntx; i++)
	{
		starts[i] = c->genes[idx[0]]->transcripts[c->genes[idx[0]]->prbtxsets[idx[1]]->tx_idx[i]]->txStart;
	}
}

static void
_gdl_expr_feature_transcript_unit_ends(const gdl_expr_chromosome * c, const size_t idx[], long ends[])
{
	size_t i;
	for(i = 0; i < c->genes[idx[0]]->prbtxsets[idx[1]]->ntx; i++)
	{
		ends[i] = c->genes[idx[0]]->transcripts[c->genes[idx[0]]->prbtxsets[idx[1]]->tx_idx[i]]->txEnd;
	}
}

static long
_gdl_expr_feature_transcript_unit_start (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->transcripts[c->genes[idx[0]]->prbtxsets[idx[1]]->tx_idx[unit_idx]]->txStart;
}

static long
_gdl_expr_feature_transcript_unit_end (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->transcripts[c->genes[idx[0]]->prbtxsets[idx[1]]->tx_idx[unit_idx]]->txEnd;
}

static gdl_expr_feature_entities *
_gdl_expr_feature_transcript_unit_entities (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	gdl_expr_feature_entities * e = GDL_CALLOC (gdl_expr_feature_entities, 1);

	e->gene       = c->genes[idx[0]];
	e->prbtxset   = e->gene->prbtxsets[idx[1]];
	e->transcript = e->gene->transcripts[e->prbtxset->tx_idx[unit_idx]];

	return e;
}

static const gdl_expr_feature_type _gdl_expr_feature_transcript =
{
	"gdl_expr_transcript_transcript",
	"transcript",
	2,
	&_gdl_expr_feature_transcript_alloc,
	&_gdl_expr_feature_transcript_get,
	&_gdl_expr_feature_transcript_starts,
	&_gdl_expr_feature_transcript_ends,
	&_gdl_expr_feature_transcript_strand,
	&_gdl_expr_feature_transcript_data,
	&_gdl_expr_feature_transcript_unit_size,
	&_gdl_expr_feature_transcript_unit_starts,
	&_gdl_expr_feature_transcript_unit_ends,
	&_gdl_expr_feature_transcript_unit_start,
	&_gdl_expr_feature_transcript_unit_end,
	&_gdl_expr_feature_transcript_unit_entities,
};

const gdl_expr_feature_type * gdl_expr_feature_transcript = &_gdl_expr_feature_transcript;

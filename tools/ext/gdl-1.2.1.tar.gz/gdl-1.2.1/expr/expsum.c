/*
 *  expr/gene_f.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <math.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_pca.h>
#include <gdl/gdl_matrix.h>
#include <gdl/gdl_vector.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_expr_feature.h>

static double **
gdl_expr_summarize_mean (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k, n;
	double ** Y;

	Y = GDL_MALLOC (double *, npop);
	for(i = 0; i < npop; i++)
	{
		Y[i] = GDL_CALLOC (double, pop_sizes[i]);
		for(j = 0; j < pop_sizes[i]; j++)
		{
			for(n = k = 0; k < K; k++)
			{
				if (!gdl_isnan (X[k][i][j]))
				{
					Y[i][j] += X[k][i][j];
					n++;
				}
			}
			if (n)
			{
				Y[i][j] /= n;
			}
			else
			{
				Y[i][j] = GDL_NAN;
			}
		}
	}

	return Y;
}

static double **
gdl_expr_summarize_median (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k, n;
	double ** Y;

	Y = GDL_MALLOC (double *, npop);
	for(i = 0; i < npop; i++)
	{
		Y[i] = GDL_CALLOC (double, pop_sizes[i]);
		for(j = 0; j < pop_sizes[i]; j++)
		{
			for(n = k = 0; k < K; k++)
			{
				if (!gdl_isnan (X[k][i][j]))
				{
					n++;
				}
			}
			if (n)
			{
				size_t lhs, rhs;
				double * x = GDL_MALLOC (double, n);

				for(n = k = 0; k < K; k++)
				{
					if (!gdl_isnan (X[k][i][j]))
					{
						x[n++]=X[k][i][j];
					}
				}

				gdl_sort (x, 1, n);

				lhs = (n -1)/2;
				rhs = n/2;

				if (lhs == rhs)
				{
					Y[i][j] = x[lhs];
				}
				else
				{
					Y[i][j] = (x[lhs] + x[rhs])/2.0;
				}

				GDL_FREE (x);
			}
			else
			{
				Y[i][j] = GDL_NAN;
			}
		}
	}

	return Y;
}


static double **
gdl_expr_summarize_median_polish (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k;
	double ** Y, t, ** x, * c, * z;

	Y = GDL_MALLOC (double *, npop);
	// we do the median polish within each population
	for(i = 0; i < npop; i++)
	{
		Y[i] = GDL_CALLOC (double, pop_sizes[i]);
		// workspace
		x = GDL_MATRIX_ALLOC (double, K, pop_sizes[i]);
		c = GDL_CALLOC (double, K);
		z = GDL_CALLOC (double, pop_sizes[i]*K);

		for(j = 0; j < K; j++)
		{
			memcpy(x[j], X[j][i], sizeof(double)*pop_sizes[i]);
		}

		gdl_stats_medpolish (x, K, pop_sizes[i], 1.e-3, 25, &t, c, Y[i], z);

		// add the overall mean
		for(j = 0; j < pop_sizes[i]; j++)
		{
			Y[i][j] += t;
		}

		GDL_MATRIX_FREE (x, K);
		GDL_FREE (c);
		GDL_FREE (z);
	}

	return Y;
}

static double **
gdl_expr_summarize_pca (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k;
	double ** Y;
	gdl_matrix * x;

	Y = GDL_MALLOC (double *, npop);
	// we do the pca within each population
	for(i = 0; i < npop; i++)
	{
		gdl_pca_workspace * pca = gdl_pca_workspace_alloc (gdl_pca_covariance);

		x = gdl_matrix_alloc (pop_sizes[i], K);

		// Greedy copy of X[.][i][.] --> x
		for(j = 0; j < pop_sizes[i]; j++)
		{
			for(k = 0; k < K; k++)
			{
				gdl_matrix_set (x, j, k, X[k][i][j]);
			}
		}

   		if (pop_sizes[i] >= K)
   		{
   			gdl_pca_workspace_perform (pca, x);
   		}
   		else
   		{
   			gdl_matrix * tx = gdl_matrix_alloc (x->size2, x->size1);
			gdl_matrix_transpose_memcpy (tx, x);
   			gdl_pca_workspace_perform_transpose (pca, tx);
   			gdl_matrix_free (tx);
   		}
   		const gdl_matrix * U = gdl_pca_workspace_projection (pca);
   		//const gdl_vector * S = gdl_pca_workspace_weights (pca);
   		//double prop_first = gdl_vector_get (S, 0)/gdl_pca_workspace_tot_var (pca);
   		//fprintf (c->logger, "%s %s %s %d %g\n", c->name, gene->name, meta_probe->name, meta_probe->size, prop_first);
   		// Get only the first axis
   		Y[i] = GDL_MALLOC (double, pop_sizes[i]);
   		for(j = 0; j < pop_sizes[i]; j++)
  	   	{
  	   		Y[i][j] = gdl_matrix_get (U, j, 0);
  	   	}

  	   	gdl_matrix_free (x);
   		gdl_pca_workspace_free (pca);
	}

	return Y;
}

double **
gdl_expr_summarize_qnorm (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k, * n;
	double ** Y, * x;

	Y = GDL_MALLOC (double *, npop);
	// we do the median polish within each population
	for(i = 0; i < npop; i++)
	{
		Y[i] = GDL_CALLOC (double, pop_sizes[i]);
		n    = GDL_CALLOC (size_t, pop_sizes[i]);
		for(k = 0; k < K; k++)
		{
			x = gdl_stats_qqnorm (X[k][i], pop_sizes[i]);
			for(j = 0; j < pop_sizes[i]; j++)
			{
				if (!gdl_isnan (X[k][i][j]))
				{
					Y[i][j] += x[j];
					(n[j])++;
				}
			}
			GDL_FREE (x);
		}
		for(j = 0; j < pop_sizes[i]; j++)
		{
			if (n[j])
			{
				Y[i][j] /= n[j];
			}
			else
			{
				Y[i][j] = GDL_NAN;
			}
		}
		GDL_FREE (n);
	}

	return Y;
}

double **
gdl_expr_summarize (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[], const gdl_expr_feature_parameter * p)
{
	gdl_string * method;

	if (!p)
	{
		// use default summarization = median polish
		method = "medpol";
	}
	else
	{
		method = gdl_hashtable_lookup (p->values, "SummarizationMethod");
		if (!method)
		{
			// use default
			method = "medpol";
		}
	}

	if (!strcmp(method, "medpol"))
	{
		return gdl_expr_summarize_median_polish (X, K, npop, pop_sizes);
	}
	else if (!strcmp(method, "pca"))
	{
		return gdl_expr_summarize_pca (X, K, npop, pop_sizes);
	}
	else if (!strcmp(method, "mean"))
	{
		return gdl_expr_summarize_mean (X, K, npop, pop_sizes);
	}
	else if (!strcmp(method, "median"))
	{
		return gdl_expr_summarize_median (X, K, npop, pop_sizes);
	}
	else if (!strcmp(method, "qnorm"))
	{
		return gdl_expr_summarize_qnorm (X, K, npop, pop_sizes);
	}
	else
	{
		GDL_ERROR_VAL (gdl_string_sprintf ("Unknown summarization method %s", method), GDL_EINVAL, 0);
	}

	return 0;
}

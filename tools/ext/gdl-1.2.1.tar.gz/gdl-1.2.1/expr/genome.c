/*
 *  expr/gene.c
 *
 *  $Author: tflutre $, $Date: 2011/07/11 16:00:04 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_genome.h>

static gdl_string *
gdl_expr_genome_chromfile (const gdl_expr_genome * g, size_t i)
{
	return gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
}

static gdl_hashtable *
gdl_expr_genome_read_config (FILE * stream)
{
	size_t i, j, n;
	gdl_string * line = 0, * tok;
	gdl_hashtable * chroms;
	gdl_list * pops;

	chroms = gdl_hashtable_alloc (gdl_hash_default, 0);

	while (gdl_getline (&line, &n, stream) != -1)
	{
		i=j=0;
		// first the chromosome name
		tok  = gdl_string_next_token (line, n, &i, &j);
		pops = gdl_list_alloc (gdl_string_interface);
		gdl_hashtable_add (chroms, tok, pops, 0);
		gdl_string_free (tok);
		// then the population names
		while ((tok = gdl_string_next_token (line, n, &i, &j))!=0)
		{
			gdl_list_push_back (pops, tok, 1);
		}
		GDL_FREE (line);
		line=0;
	}

	return chroms;
}

static int
gdl_expr_genome_process_config (gdl_expr_genome * g,
                                const gdl_string * config_file,
                                const gdl_string * probe_dir,
                                const gdl_string * txtable_dir,
                                const gdl_string * na_token,
                                FILE * progress,
                                FILE * logger)
{
	size_t i, j, k, n;
	gdl_string * line = 0, * tok;
	gdl_hashtable * chroms;
	gdl_hashtable_itr * chroms_itr;
	gdl_list * pops;
	gdl_list_itr * pops_itr;
	FILE * stream;

	stream = gdl_fileopen (config_file, "r");
	chroms = gdl_expr_genome_read_config (stream);
	gdl_fileclose (config_file, stream);

	g->nchrom  = gdl_hashtable_size (chroms);
	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the expression data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Configuration File       = %s\n", config_file);
		fprintf (progress, " Probe Annotation Dir     = %s\n", probe_dir);
		fprintf (progress, " Transcript Table Dir     = %s\n", txtable_dir);
		fprintf (progress, " Missing Expression Value = %s\n", na_token);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	chroms_itr = gdl_hashtable_iterator (chroms);
	j = 0;
	do
	{
		size_t npop;
		gdl_string * pop_dir, * file;
		const gdl_string * name;
		gdl_expr_chromosome * chrom=0;

		name = gdl_hashtable_iterator_key (chroms_itr);
		pops = (gdl_list *) gdl_hashtable_iterator_value (chroms_itr);

		// copy the population names to an array
		npop = gdl_list_size (pops);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s (npop = %ld)\n", name, npop);
			fflush (progress);
		}

		// 1 - Go into probe_dir and load the chromosome
		if (probe_dir)
		{
			chrom  = gdl_expr_chromosome_alloc (gdl_string_clone (name), npop);

			file   = gdl_string_sprintf ("%s/%s.prb", probe_dir, name);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", probe_dir);
					fflush (progress);
				}
				stream = gdl_fileopen (probe_dir, "r");
				gdl_expr_chromosome_fscanf_annotation2 (stream, chrom);
				gdl_fileclose (probe_dir, stream);
			}
			else
			{

				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_annotation (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}
			// 2 - Go into the pop dirs and load the expression data
			for (i = 0; i < npop; i++)
			{
				pop_dir = (gdl_string *) gdl_list_get (pops, i);
				file   = gdl_string_sprintf ("%s/%s.exp", pop_dir, name);
				if (!gdl_isfile (file))
				{
					// try a single file with the name of the population
					// directory
					file = gdl_string_sprintf ("%s.exp", pop_dir);
					if (!gdl_isfile (file))
					{
						if (logger)
						{
							fprintf (logger, "No expression data for chromosome %s for population %s\n", name, pop_dir);
							fflush (logger);
						}
						continue;
					}
				}
				if (progress)
				{
					fprintf (progress, ">>Read the population expression matrix from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_expression (stream, i, chrom, na_token);
				gdl_fileclose (file, stream);
				gdl_string_free (file);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}
		// 3 - Read txtable info if exists
		if (txtable_dir)
		{
			if (!chrom)
			{
				chrom = gdl_expr_chromosome_alloc (gdl_string_clone (name), npop);
			}

			file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, name);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
					fflush (progress);
				}

				stream = gdl_fileopen (txtable_dir, "r");
				gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
				gdl_fileclose (txtable_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", file);
					fflush (progress);
				}

				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_txtable (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}

			if (probe_dir)
			{
				if (progress)
				{
					fprintf (progress, ">>Map the probe to the transcript: wait...");
					fflush (progress);
				}
				gdl_expr_chromosome_map_probe (chrom, logger);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}
		else if (probe_dir && !txtable_dir)
		{
			// as many genes as the number of probes
			// A probe = a gene x exon x transcript
			// TODO
		}
		g->_nsample = 0;
		for(k = 0; k < chrom->npop; k++)
		{
			g->_nsample += chrom->pop_sizes[k];
		}
		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, name);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}


		g->chroms[j++] = gdl_string_clone (name);

		gdl_expr_chromosome_free (chrom);
		gdl_list_free (pops);
	}
	while (gdl_hashtable_iterator_next (chroms_itr));

	gdl_hashtable_iterator_free (chroms_itr);

	gdl_hashtable_free (chroms);
}

gdl_expr_genome *
gdl_expr_genome_alloc (const gdl_string * config_file,
                        const gdl_string * probe_dir,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        const gdl_string * na_token,
                        FILE * progress,
                        FILE * logger)
{
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	gdl_expr_genome_process_config (g, config_file, probe_dir, txtable_dir, na_token, progress, logger);

	return g;
}

/** \brief Create the expression database when 
 *         expression data are at the probe level.
 */
gdl_expr_genome *
gdl_expr_genome_alloc2 (const gdl_string * dir,
                        gdl_string ** pops,
                        const size_t npop,
                        gdl_string ** chroms,
                        const size_t nchrom,
                        const gdl_string * probe_dir,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        const gdl_string * na_token,
                        FILE * progress,
                        FILE * logger)
{
	size_t i, j, k, n;
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	g->nchrom  = nchrom;

	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the expression data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Probe Annotation Dir     = %s\n", probe_dir);
		fprintf (progress, " Transcript Table Dir     = %s\n", txtable_dir);
		fprintf (progress, " Missing Expression Value = %s\n", na_token);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	for(i = 0; i < nchrom; i++)
	{
		gdl_string * pop_dir, * file;
		FILE * stream;
		gdl_expr_chromosome * chrom = 0;

		g->chroms[i] = gdl_string_clone (chroms[i]);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s (npop = %ld)\n", g->chroms[i], npop);
			fflush (progress);
		}

		// 1 - Go into probe_dir and load the chromosome
		if (probe_dir)
		{
			chrom  = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);

			file   = gdl_string_sprintf ("%s/%s.prb", probe_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", probe_dir);
					fflush (progress);
				}
				stream = gdl_fileopen (probe_dir, "r");
				gdl_expr_chromosome_fscanf_annotation2 (stream, chrom);
				gdl_fileclose (probe_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_annotation (stream, chrom);
				gdl_fileclose (file, stream);
			}
			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b%i probes [ OK ]\n", chrom->nprobe);
				fflush (progress);
			}
			// 2 - Go into the pop dirs and load the expression data
			for (j = 0; j < npop; j++)
			{
				file = gdl_string_sprintf ("%s/%s/%s.exp", dir, pops[j], g->chroms[i]);
				if (!gdl_isfile (file))
				{
					file = gdl_string_sprintf ("%s/%s.exp", dir, pops[j]);
					if (!gdl_isfile (file))
					{
						if (logger)
						{
							fprintf (logger, "No expression data for chromosome %s for population %s\n", g->chroms[i], pops[j]);
							fflush (logger);
						}
						continue;
					}
				}
				if (progress)
				{
					fprintf (progress, ">>Read the population expression matrix from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_expression (stream, j, chrom, na_token);
				gdl_fileclose (file, stream);
				gdl_string_free (file);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}
		// 3 - Read txtable info if exists
		if (txtable_dir)
		{
			if (!chrom)
			{
				chrom = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);
			}

			file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
					fflush (progress);
				}

				stream = gdl_fileopen (txtable_dir, "r");
				gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
				gdl_fileclose (txtable_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", file);
					fflush (progress);
				}

				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_txtable (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b%i genes [ OK ]\n", chrom->ngene);
				fflush (progress);
			}

			if (probe_dir)
			{
				if (progress)
				{
					fprintf (progress, ">>Map the probes to the transcripts: wait...");
					fflush (progress);
				}
				gdl_expr_chromosome_map_probe (chrom, logger);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}
		else if (probe_dir && !txtable_dir)
		{
			// as many genes as the number of probes
			// A probe = a gene x exon x transcript
			// TODO
		}
		g->_nsample = 0;
		for(k = 0; k < chrom->npop; k++)
		{
			g->_nsample += chrom->pop_sizes[k];
		}
		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b%i genes with at least one probe [ OK ]\n", 
				 gdl_exp_chromosome_ngenes_with_probe(chrom));
			fflush (progress);
		}

		gdl_expr_chromosome_free (chrom);
	}

	return g;
}

/** \brief Create the expression database when 
 *         expression data are at the gene level.
 */
gdl_expr_genome *
gdl_expr_genome_alloc3 (const gdl_string * dir,
                        gdl_string ** pops,
                        const size_t npop,
                        gdl_string ** chroms,
                        const size_t nchrom,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        const gdl_string * na_token,
                        FILE * progress,
                        FILE * logger)
{
	size_t i, j, k, n;
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	g->nchrom  = nchrom;

	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the expression data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Transcript Table Dir     = %s\n", txtable_dir);
		fprintf (progress, " Missing Expression Value = %s\n", na_token);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	for(i = 0; i < nchrom; i++)
	{
		gdl_string * pop_dir, * file;
		FILE * stream;
		gdl_expr_chromosome * chrom = 0;

		g->chroms[i] = gdl_string_clone (chroms[i]);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s (npop = %ld)\n", g->chroms[i], npop);
			fflush (progress);
		}

		chrom = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);

		file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, g->chroms[i]);

		if (!gdl_isfile (file))
		{
			if (progress)
			{
				fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
				fflush (progress);
			}

			stream = gdl_fileopen (txtable_dir, "r");
			gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
			gdl_fileclose (txtable_dir, stream);
		}
		else
		{
			if (progress)
			{
				fprintf (progress, ">>Read the transcript table from %s: wait...", file);
				fflush (progress);
			}

			stream = gdl_fileopen (file, "r");
			gdl_expr_chromosome_fscanf_txtable (stream, chrom);
			gdl_fileclose (file, stream);
		}
		gdl_string_free (file);

		if (progress)
		{
		  fprintf (progress, "\b\b\b\b\b\b\b%i genes [ OK ]\n", chrom->ngene);
			fflush (progress);
		}
		// Now, create as many probes as the number of genes
		gdl_expr_chromosome_init_global_gene_measurment (chrom);

		// 2 - Go into the pop dirs and load the expression data
		for (j = 0; j < npop; j++)
		{
			file = gdl_string_sprintf ("%s/%s/%s.exp", dir, pops[j], g->chroms[i]);
			if (!gdl_isfile (file))
			{
				file = gdl_string_sprintf ("%s/%s.exp", dir, pops[j]);
				if (!gdl_isfile (file))
				{
					if (logger)
					{
						fprintf (logger, "No expression data for chromosome %s for population %s\n", g->chroms[i], pops[j]);
						fflush (logger);
					}
					continue;
				}
			}
			if (progress)
			{
				fprintf (progress, ">>Read the population expression matrix from %s: wait...", file);
				fflush (progress);
			}
			stream = gdl_fileopen (file, "r");
			gdl_expr_chromosome_fscanf_expression (stream, j, chrom, na_token);
			gdl_fileclose (file, stream);
			gdl_string_free (file);
			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}
		}
		g->_nsample = 0;
		for(k = 0; k < chrom->npop; k++)
		{
			g->_nsample += chrom->pop_sizes[k];
		}
		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}

		gdl_expr_chromosome_free (chrom);
	}

	return g;
}

/**
 *  Methylation Probes
 */
gdl_expr_genome *
gdl_expr_genome_alloc4 (const gdl_string * dir,
                        gdl_string ** pops,
                        const size_t npop,
                        gdl_string ** chroms,
                        const size_t nchrom,
                        const gdl_string * probe_dir,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        const gdl_string * na_token,
                        const long window,
                        FILE * progress,
                        FILE * logger)
{
	size_t i, j, k, n;
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	g->nchrom  = nchrom;

	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the expression data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Probe Annotation Dir     = %s\n", probe_dir);
		fprintf (progress, " Transcript Table Dir     = %s\n", txtable_dir);
		fprintf (progress, " Window                   = %ld\n", window);
		fprintf (progress, " Missing Expression Value = %s\n", na_token);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	for(i = 0; i < nchrom; i++)
	{
		gdl_string * pop_dir, * file;
		FILE * stream;
		gdl_expr_chromosome * chrom = 0;

		g->chroms[i] = gdl_string_clone (chroms[i]);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s (npop = %ld)\n", g->chroms[i], npop);
			fflush (progress);
		}

		// 1 - Go into probe_dir and load the chromosome
		if (probe_dir)
		{
			chrom  = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);

			file   = gdl_string_sprintf ("%s/%s.prb", probe_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", probe_dir);
					fflush (progress);
				}
				stream = gdl_fileopen (probe_dir, "r");
				gdl_expr_chromosome_fscanf_annotation2 (stream, chrom);
				gdl_fileclose (probe_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_annotation (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}
			// 2 - Go into the pop dirs and load the expression data
			for (j = 0; j < npop; j++)
			{
				file = gdl_string_sprintf ("%s/%s/%s.exp", dir, pops[j], g->chroms[i]);
				if (!gdl_isfile (file))
				{
					file = gdl_string_sprintf ("%s/%s.exp", dir, pops[j]);
					if (!gdl_isfile (file))
					{
						if (logger)
						{
							fprintf (logger, "No expression data for chromosome %s for population %s\n", g->chroms[i], pops[j]);
							fflush (logger);
						}
						continue;
					}
				}
				if (progress)
				{
					fprintf (progress, ">>Read the population expression matrix from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_expression (stream, j, chrom, na_token);
				gdl_fileclose (file, stream);
				gdl_string_free (file);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}
		// 3 - Read txtable info if exists
		if (txtable_dir)
		{
			if (!chrom)
			{
				chrom = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);
			}

			file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
					fflush (progress);
				}

				stream = gdl_fileopen (txtable_dir, "r");
				gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
				gdl_fileclose (txtable_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", file);
					fflush (progress);
				}

				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_txtable (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}

			if (probe_dir)
			{
				if (progress)
				{
					fprintf (progress, ">>Map the probe to the transcript: wait...\n");
					fflush (progress);
				}
				gdl_expr_chromosome_create_prbwindow (chrom, window, logger);
				if (progress)
				{
					fprintf (progress, ">>Map the probe to the transcript: [ OK ]\n");
					fflush (progress);
				}
			}
		}
		else if (probe_dir && !txtable_dir)
		{
			// as many genes as the number of probes
			// A probe = a gene x exon x transcript
			// TODO
		}
		g->_nsample = 0;
		for(k = 0; k < chrom->npop; k++)
		{
			g->_nsample += chrom->pop_sizes[k];
		}
		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}

		gdl_expr_chromosome_free (chrom);
	}

	return g;
}

/**
 *  Probe mapping
 */
gdl_expr_genome *
gdl_expr_genome_alloc5 (gdl_string ** chroms,
                        const size_t nchrom,
                        const gdl_string * probe_dir,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        FILE * progress,
                        FILE * logger)
{
	size_t i, j, k, n;
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	g->nchrom  = nchrom;

	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the probe x transcript data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Probe Annotation Dir     = %s\n", probe_dir);
		fprintf (progress, " Transcript Table Dir     = %s\n", txtable_dir);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	for(i = 0; i < nchrom; i++)
	{
		gdl_string * pop_dir, * file;
		FILE * stream;
		gdl_expr_chromosome * chrom = 0;

		g->chroms[i] = gdl_string_clone (chroms[i]);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s\n", g->chroms[i]);
			fflush (progress);
		}

		// 1 - Go into probe_dir and load the chromosome
		if (probe_dir)
		{
			chrom  = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), 1);

			file   = gdl_string_sprintf ("%s/%s.prb", probe_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", probe_dir);
					fflush (progress);
				}
				stream = gdl_fileopen (probe_dir, "r");
				gdl_expr_chromosome_fscanf_annotation2 (stream, chrom);
				gdl_fileclose (file, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the probe annotation file from %s: wait...", file);
					fflush (progress);
				}
				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_annotation (stream, chrom);
				gdl_fileclose (file, stream);
			}
			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}
		}
		// 3 - Read txtable info
		if (txtable_dir)
		{
			if (!chrom)
			{
				chrom = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), 1);
			}

			file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, g->chroms[i]);

			if (!gdl_isfile (file))
			{

				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
					fflush (progress);
				}

				stream = gdl_fileopen (txtable_dir, "r");
				gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
				gdl_fileclose (txtable_dir, stream);
			}
			else
			{
				if (progress)
				{
					fprintf (progress, ">>Read the transcript table from %s: wait...", file);
					fflush (progress);
				}

				stream = gdl_fileopen (file, "r");
				gdl_expr_chromosome_fscanf_txtable (stream, chrom);
				gdl_fileclose (file, stream);
			}

			gdl_string_free (file);

			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}

			if (probe_dir)
			{
				if (progress)
				{
					fprintf (progress, ">>Map the probe to the transcript: wait...");
					fflush (progress);
				}
				gdl_expr_chromosome_map_probe (chrom, logger);
				if (progress)
				{
					fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
					fflush (progress);
				}
			}
		}

		g->_nsample = 0;

		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}

		gdl_expr_chromosome_free (chrom);
	}

	return g;
}

/**
 *  Exon expression level
 */
gdl_expr_genome *
gdl_expr_genome_alloc6 (const gdl_string * dir,
                        gdl_string ** pops,
                        const size_t npop,
                        gdl_string ** chroms,
                        const size_t nchrom,
                        const gdl_string * txtable_dir,
                        const gdl_string * dbdir,
                        const gdl_string * na_token,
                        FILE * progress,
                        FILE * logger)
{
	size_t i, j, k, n;
	gdl_expr_genome * g;

	g = GDL_MALLOC (gdl_expr_genome, 1);

	g->dbdir = gdl_string_clone (dbdir);

	g->nchrom  = nchrom;

	g->chroms  = GDL_MALLOC (gdl_string *, g->nchrom);

	if (progress)
	{
		fprintf (progress, "--\nCreate the expression data base\n");
		fprintf (progress, "--\n");
		fprintf (progress, " Exon Expression Level    = yes\n");
		fprintf (progress, " Transcript Table         = %s\n", txtable_dir);
		fprintf (progress, " Missing Expression Value = %s\n", na_token);
		fprintf (progress, " #Chromosomes             = %ld\n", g->nchrom);
		fprintf (progress, "--\n");
		fflush (progress);
	}

	for(i = 0; i < nchrom; i++)
	{
		gdl_string * pop_dir, * file;
		FILE * stream;
		gdl_expr_chromosome * chrom = 0;

		g->chroms[i] = gdl_string_clone (chroms[i]);

		if (progress)
		{
			fprintf (progress, ">Chromosome %s (npop = %ld)\n", g->chroms[i], npop);
			fflush (progress);
		}

		chrom = gdl_expr_chromosome_alloc (gdl_string_clone (g->chroms[i]), npop);

		file = gdl_string_sprintf ("%s/%s.txtb", txtable_dir, g->chroms[i]);

		if (!gdl_isfile (file))
		{
			if (progress)
			{
				fprintf (progress, ">>Read the transcript table from %s: wait...", txtable_dir);
				fflush (progress);
			}

			stream = gdl_fileopen (txtable_dir, "r");
			gdl_expr_chromosome_fscanf_txtable2 (stream, chrom);
			gdl_fileclose (txtable_dir, stream);
		}
		else
		{
			if (progress)
			{
				fprintf (progress, ">>Read the transcript table from %s: wait...", file);
				fflush (progress);
			}

			stream = gdl_fileopen (file, "r");
			gdl_expr_chromosome_fscanf_txtable (stream, chrom);
			gdl_fileclose (file, stream);
		}
		gdl_string_free (file);

		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}
		// Now, create as many probes as the number of genes
		gdl_expr_chromosome_init_global_exon_measurment (chrom);

		// 2 - Go into the pop dirs and load the expression data
		for (j = 0; j < npop; j++)
		{
			file = gdl_string_sprintf ("%s/%s/%s.exp", dir, pops[j], g->chroms[i]);
			if (!gdl_isfile (file))
			{
				file = gdl_string_sprintf ("%s/%s.exp", dir, pops[j]);
				if (!gdl_isfile (file))
				{
					if (logger)
					{
						fprintf (logger, "No expression data for chromosome %s for population %s\n", g->chroms[i], pops[j]);
						fflush (logger);
					}
					continue;
				}
			}
			if (progress)
			{
				fprintf (progress, ">>Read the population expression matrix from %s: wait...", file);
				fflush (progress);
			}
			stream = gdl_fileopen (file, "r");
			gdl_expr_chromosome_fscanf_exon_expression (stream, j, chrom, na_token);
			gdl_fileclose (file, stream);
			gdl_string_free (file);
			if (progress)
			{
				fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
				fflush (progress);
			}
		}
		g->_nsample = 0;
		for(k = 0; k < chrom->npop; k++)
		{
			g->_nsample += chrom->pop_sizes[k];
		}
		// 4 - save it
		file = gdl_string_sprintf ("%s/%s_exp.db", g->dbdir, g->chroms[i]);
		if (progress)
		{
			fprintf (progress, ">>Save chromosome data to %s: wait...", file);
			fflush (progress);
		}
		stream = gdl_fileopen (file, "w");
		gdl_expr_chromosome_fwrite (stream, chrom);
		gdl_fileclose (file, stream);
		gdl_string_free (file);
		if (progress)
		{
			fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
			fflush (progress);
		}

		gdl_expr_chromosome_free (chrom);
	}

	return g;
}

size_t
gdl_expr_genome_size (const gdl_expr_genome * g)
{
	return g->nchrom;
}

gdl_expr_chromosome *
gdl_expr_genome_get (const gdl_expr_genome * g, size_t i)
{
	gdl_string * file;
	FILE * stream;
	gdl_expr_chromosome * c;

	file = gdl_expr_genome_chromfile (g, i);

	stream = gdl_fileopen (file, "r");

	c = gdl_expr_chromosome_fread (stream);

	gdl_fileclose (file, stream);

	gdl_string_free (file);

	return c;
}

int
gdl_expr_genome_set (const gdl_expr_genome * g, size_t i, gdl_expr_chromosome * c)
{
	int status;
	gdl_string * file;
	FILE * stream;

	file = gdl_expr_genome_chromfile (g, i);

	stream = gdl_fileopen (file, "w");

	status = gdl_expr_chromosome_fwrite (stream, c);

	gdl_fileclose (file, stream);

	gdl_string_free (file);

	return status;
}

void
gdl_expr_genome_free (gdl_expr_genome * v)
{
	if (v)
	{
		size_t i;
		for (i = 0; i < v->nchrom; i++)
		{
			gdl_string_free (v->chroms[i]);
		}
		GDL_FREE (v->chroms);
		gdl_string_free (v->dbdir);
		GDL_FREE (v);
	}
}

void
gdl_expr_genome_rm (gdl_expr_genome * v)
{
	size_t i;

	for (i = 0; i < v->nchrom; i++)
	{
		gdl_string * file = gdl_expr_genome_chromfile (v, i);
		remove (file);
		gdl_string_free (file);
	}
}

gdl_expr_genome *
gdl_expr_genome_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		size_t i;
		gdl_expr_genome * v;

		v = GDL_MALLOC (gdl_expr_genome, 1);

		v->dbdir = gdl_string_fread (stream);
		GDL_FREAD_STATUS (v->dbdir!=0, 1, NULL);
		status = fread (&v->nchrom, sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		v->chroms = GDL_MALLOC (gdl_string *, v->nchrom);
		for (i = 0; i < v->nchrom; i++)
		{
			v->chroms[i] = gdl_string_fread (stream);
			GDL_FREAD_STATUS (v->chroms[i]!=0, 1, NULL);
		}

		return v;
	}
	return 0;
}

int
gdl_expr_genome_fwrite (FILE * stream, const gdl_expr_genome * v)
{
	if (stream && v)
	{
		int status;
		size_t i;

		status = gdl_string_fwrite (stream, v->dbdir);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		status = fwrite (&v->nchrom, sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		for (i = 0; i < v->nchrom; i++)
		{
			status = gdl_string_fwrite (stream, v->chroms[i]);
			GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		}

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

int
gdl_expr_genome_summarize (FILE * stream, const gdl_expr_genome * v)
{
	size_t i, j;

	fprintf (stream, "#chromosome\tname\tn_pop\tn_sample\tn_probe\tn_gene\n");
	for(i = 0; i < v->nchrom; i++)
	{
		gdl_expr_chromosome * chrom = gdl_expr_genome_get (v, i);
		fprintf (stream, "chromosome\tname\t%s\t%ld\t%ld\t%ld\t%ld\n", chrom->name, chrom->npop, chrom->nsample, chrom->nprobe, chrom->ngene);
		fflush (stream);
		if (chrom->ngene)
		{
			fprintf (stream, "#gene\tname\tstrand\tmin_txstart\tmax_txend\tn_tx\tn_exon\tn_probe\tn_probe_x_tx\n");
			for(j = 0; j < chrom->ngene; j++)
			{
				gdl_expr_gene * gene = chrom->genes[j];
				fprintf (stream, "gene\t%s\t%c\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\n", gene->name, gene->strand, gene->txStartMin, gene->txEndMax, gene->ntx, gene->nexon, gene->nprobe, gene->nprbtxset);
				fflush (stream);
			}
		}
		gdl_expr_chromosome_free (chrom);
	}
	return GDL_SUCCESS;
}

gdl_expr_genome *
gdl_expr_genome_subset (gdl_expr_genome * g, gdl_string ** sample_names, gdl_string ** sub_sample_names, const size_t nsub_sample, const gdl_string * output)
{
	size_t c, i, j, k;
	gdl_sub_sample_mapping_t * m;
	gdl_expr_genome * sub_g;
	DIR * dir;

	// Create the new genome
	sub_g = GDL_CALLOC (gdl_expr_genome, 1);
	sub_g->nchrom = g->nchrom;
	sub_g->dbdir  = gdl_string_clone (output);
	sub_g->chroms = GDL_MALLOC (gdl_string *, g->nchrom);
	for(c = 0; c < g->nchrom; c++)
	{
		sub_g->chroms[c] = gdl_string_clone (g->chroms[c]);
	}
	// First, make sure that the directory exists
	if ((dir=opendir(output))==0)
	{
		mkdir (output, S_IRWXU);
	}
	// Update the chromosomes
	for(c = 0; c < g->nchrom; c++)
	{
		gdl_expr_chromosome * chrom = gdl_expr_genome_get (g, c);
		if (!c)
		{
			m = gdl_sub_sample_mapping_by_pop (sample_names, chrom->pop_sizes, chrom->npop, sub_sample_names, nsub_sample);
		}
		// Update probe->data
		for(i = 0; i < chrom->nprobe; i++)
		{
			gdl_expr_probe * probe = chrom->probes[i];
			if (probe->data)
			{
				double ** sub_data = GDL_MALLOC (double *, m->npop);
				for(j = 0; j < m->npop; j++)
				{
					sub_data[j] = GDL_MALLOC (double, m->pop_sizes[j]);
					for(k = 0; k < m->pop_sizes[j]; k++)
					{
						sub_data[j][k] = probe->data[m->popx[j][k]][m->pidx[j][k]];
					}
				}
				GDL_MATRIX_FREE (probe->data, chrom->npop);
				probe->data = sub_data;
			}
		}
		// Update chrom->sample
		for(i = 0; i < m->npop; chrom->nsample += m->pop_sizes[i], i++);
		// Update chrom->npop;
		chrom->npop = m->npop;
		// Update chrom->pop_sizes
		memcpy(chrom->pop_sizes, m->pop_sizes, sizeof(size_t)*m->npop);
		// Save the chromosome to this new location
		gdl_expr_genome_set (sub_g, c, chrom);
		// Clean it
		gdl_expr_chromosome_free (chrom);
	}

	gdl_sub_sample_mapping_t_free (m);

	return sub_g;
}

int
gdl_expr_genome_fprintf (const gdl_expr_genome * g, gdl_string ** pop_names, const gdl_string * output)
{
	size_t c, p;
	gdl_string * file;
	DIR * dir;

	for(c = 0; c < g->nchrom; c++)
	{
		gdl_expr_chromosome * chrom = gdl_expr_genome_get (g, c);
		if (!c)
		{
			// First, make sure that the directory exists
			if ((dir=opendir(output))==0)
			{
				mkdir (output, S_IRWXU);
			}
			for(p = 0; p < chrom->npop; p++)
			{
				if (pop_names)
				{
					file = gdl_string_sprintf ("%s/%s", output, pop_names[p]);
				}
				else
				{
					file = gdl_string_sprintf ("%s/Pop_%d", output, p+1);
				}
				if ((dir=opendir(file))==0)
				{
					mkdir (file, S_IRWXU);
				}
				gdl_string_free (file);
			}
			// Create extra directory
			file = gdl_string_sprintf ("%s/Extra", output);
			if ((dir=opendir(file))==0)
			{
				mkdir (file, S_IRWXU);
			}
			gdl_string_free (file);
		}
		gdl_expr_chromosome_fprintf (chrom, pop_names, output);
		gdl_expr_chromosome_free (chrom);
	}
}

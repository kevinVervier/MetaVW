/*
 *  expr/gdl_expr_genome.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_GENOME_H__
#define __GDL_EXPR_GENOME_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_expr_chromosome.h>

__BEGIN_DECLS

typedef struct
{
	size_t nchrom;
	gdl_string      * dbdir;
	gdl_string    ** chroms;
	size_t _nsample;
} gdl_expr_genome;

gdl_expr_genome * gdl_expr_genome_alloc (const gdl_string * config_file, const gdl_string * probe_dir, const gdl_string * txtable_dir, const gdl_string * dbdir, const gdl_string * na_token, FILE * progress, FILE * logger);
gdl_expr_genome * gdl_expr_genome_alloc2 (const gdl_string * dir, gdl_string ** pops, const size_t npop, gdl_string ** chroms, const size_t nchrom, const gdl_string * probe_dir, const gdl_string * txtable_dir, const gdl_string * dbdir, const gdl_string * na_token, FILE * progress, FILE * logger);
gdl_expr_genome * gdl_expr_genome_alloc3 (const gdl_string * dir, gdl_string ** pops, const size_t npop, gdl_string ** chroms, const size_t nchrom, const gdl_string * txtable_dir, const gdl_string * dbdir, const gdl_string * na_token, FILE * progress, FILE * logger);
gdl_expr_genome * gdl_expr_genome_alloc4 (const gdl_string * dir, gdl_string ** pops, const size_t npop, gdl_string ** chroms, const size_t nchrom, const gdl_string * probe_dir, const gdl_string * txtable_dir, const gdl_string * dbdir, const gdl_string * na_token, const long window, FILE * progress, FILE * logger);
gdl_expr_genome * gdl_expr_genome_alloc5 (gdl_string ** chroms, const size_t nchrom, const gdl_string * probe_dir, const gdl_string * txtable_dir, const gdl_string * dbdir, FILE * progress, FILE * logger);
gdl_expr_genome * gdl_expr_genome_alloc6 (const gdl_string * dir, gdl_string ** pops, const size_t npop, gdl_string ** chroms, const size_t nchrom, const gdl_string * txtable_dir, const gdl_string * dbdir, const gdl_string * na_token, FILE * progress, FILE * logger);

void gdl_expr_genome_free (gdl_expr_genome * v);
void gdl_expr_genome_rm (gdl_expr_genome * v);
size_t gdl_expr_genome_size (const gdl_expr_genome * g);
gdl_expr_chromosome * gdl_expr_genome_get (const gdl_expr_genome * g, size_t i);
int gdl_expr_genome_set (const gdl_expr_genome * g, size_t i, gdl_expr_chromosome * c);
gdl_expr_genome * gdl_expr_genome_fread (FILE * stream);
int gdl_expr_genome_fwrite (FILE * stream, const gdl_expr_genome * v);

gdl_expr_genome * gdl_expr_genome_subset (gdl_expr_genome * g, gdl_string ** sample_names, gdl_string ** sub_sample_names, const size_t nsub_sample, const gdl_string * output);
int gdl_expr_genome_summarize (FILE * stream, const gdl_expr_genome * v);
int gdl_expr_genome_fprintf (const gdl_expr_genome * v, gdl_string ** pop_names, const gdl_string * output);

__END_DECLS

#endif

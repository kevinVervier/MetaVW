/*
 *  expr/anchor.c
 *
 *  $Author: baptiste78 $, $Date: 2011/05/31 20:46:32 $, $Version$
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <stdio.h>
#include <stdlib.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_version.h>
#include <gdl/gdl_machine.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_expr_feature.h>
#include <gdl/gdl_expr_feature_anchor.h>

static long
gdl_expr_feature_type_anchor_FSS_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, im, n;
	const long * starts;
	double d, dmin = GDL_POSINF;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d < dmin)
				{
					dmin = d;
					im = i;
				}
			}
			return position - starts[im];
		case '-':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d < dmin)
				{
					dmin = d;
					im   = i;
				}
			}
			return starts[im] - position;
	}
}

static long
gdl_expr_feature_type_anchor_FSS_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, im, n;
	const long  * starts;
	double d, dmax = 0;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d > dmax)
				{
					dmax = d;
					im = i;
				}
			}
			return position - starts[im];
		case '-':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d > dmax)
				{
					dmax = d;
					im   = i;
				}
			}
			return starts[im] - position;
	}
}

static long
gdl_expr_feature_type_anchor_FSS_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, n;
	long d = 0;
	const long * starts;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d += position - starts[i];
			}
			return d / n;
		case '-':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d += starts[i] - position;
			}
			return d / n;
	}
}

static long *
gdl_expr_feature_type_anchor_FSS_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position, size_t * n)
{
	size_t i;
	const long * starts;
	unsigned char strand = (T->get_strand)(chrom, idx);
	long * d;

	switch(strand)
	{
		case '+':
			starts = (T->get_starts)(chrom, idx, n);
			d = GDL_MALLOC (long, *n);
			for(i = 0; i < *n; i++)
			{
				d[i] = position - starts[i];
			}
			return d;
		case '-':
			starts = (T->get_ends)(chrom, idx, n);
			d = GDL_MALLOC (long, *n);
			for(i = 0; i < *n; i++)
			{
				d[i] = starts[i] - position;
			}
			return d;
	}
}

static long
gdl_expr_feature_type_anchor_FSS_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const size_t unit_idx, const long position)
{
	size_t i;
	const unsigned char strand = (T->get_strand)(chrom, idx);
	const size_t nunit         = (T->get_unit_size)(chrom, idx);
	long * starts              = GDL_MALLOC (long, nunit);
	long d;

	switch(strand)
	{
		case '+':
			(T->get_unit_starts)(chrom, idx, starts);
			d = position - starts[unit_idx];
			GDL_FREE (starts);
			return d;
		case '-':
			(T->get_unit_ends)(chrom, idx, starts);
			d = starts[unit_idx] - position;
			GDL_FREE (starts);
			return d;
	}
}

static long
gdl_expr_feature_anchor_FSS_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FSS_d_min (chrom, feature->T, feature->idx, position);
}

static long
gdl_expr_feature_anchor_FSS_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FSS_d_max (chrom, feature->T, feature->idx, position);
}

static long
gdl_expr_feature_anchor_FSS_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FSS_d_avg (chrom, feature->T, feature->idx, position);
}

static long *
gdl_expr_feature_anchor_FSS_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	return gdl_expr_feature_type_anchor_FSS_d (chrom, feature->T, feature->idx, position, n);
}

static long
gdl_expr_feature_anchor_FSS_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	return gdl_expr_feature_type_anchor_FSS_d0 (chrom, feature->T, feature->idx, unit_idx, position);
}

const static gdl_expr_feature_anchor _FSS =
{
	"gdl_expr_feature_anchor_FSS",
	"FSS",
	&gdl_expr_feature_anchor_FSS_d_min,
	&gdl_expr_feature_anchor_FSS_d_max,
	&gdl_expr_feature_anchor_FSS_d_avg,
	&gdl_expr_feature_anchor_FSS_d,
	&gdl_expr_feature_anchor_FSS_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FSS = &_FSS;


static long
gdl_expr_feature_anchor_TSS_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FSS_d_min (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FSS_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FSS_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FSS_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long
gdl_expr_feature_anchor_TSS_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FSS_d_max (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FSS_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FSS_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FSS_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long
gdl_expr_feature_anchor_TSS_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FSS_d_avg (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FSS_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FSS_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FSS_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long *
gdl_expr_feature_anchor_TSS_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FSS_d (chrom, feature, position, n);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FSS_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FSS_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FSS_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
}

static long
gdl_expr_feature_anchor_TSS_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FSS_d0 (chrom, feature, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FSS_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FSS_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FSS_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
}

const static gdl_expr_feature_anchor _TSS =
{
	"gdl_expr_feature_anchor_TSS",
	"TSS",
	&gdl_expr_feature_anchor_TSS_d_min,
	&gdl_expr_feature_anchor_TSS_d_max,
	&gdl_expr_feature_anchor_TSS_d_avg,
	&gdl_expr_feature_anchor_TSS_d,
	&gdl_expr_feature_anchor_TSS_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_TSS = &_TSS;


static long
gdl_expr_feature_type_anchor_FES_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, im, n;
	const long  * starts;
	double d, dmin = GDL_POSINF;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d < dmin)
				{
					dmin = d;
					im = i;
				}
			}
			return position - starts[im];
		case '-':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d < dmin)
				{
					dmin = d;
					im   = i;
				}
			}
			return starts[im] - position;
	}
}

static long
gdl_expr_feature_type_anchor_FES_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, im, n;
	const long  * starts;
	double d, dmax = 0;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d > dmax)
				{
					dmax = d;
					im = i;
				}
			}
			return position - starts[im];
		case '-':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d > dmax)
				{
					dmax = d;
					im   = i;
				}
			}
			return starts[im] - position;
	}
}

static long
gdl_expr_feature_type_anchor_FES_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position)
{
	size_t i, n;
	long d = 0;
	const long * starts;
	unsigned char strand = (T->get_strand)(chrom, idx);

	switch(strand)
	{
		case '+':
			starts = (T->get_ends)(chrom, idx, &n);
			if (n == 1)
			{
				return position - starts[0];
			}
			for(i = 0; i < n; i++)
			{
				d += position - starts[i];
			}
			return d / n;
		case '-':
			starts = (T->get_starts)(chrom, idx, &n);
			if (n == 1)
			{
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d += starts[i] - position;
			}
			return d / n;
	}
}

static long *
gdl_expr_feature_type_anchor_FES_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const long position, size_t * n)
{
	size_t i;
	const long * starts;
	unsigned char strand = (T->get_strand)(chrom, idx);
	long * d;

	switch(strand)
	{
		case '+':
			starts = (T->get_ends)(chrom, idx, n);
			d = GDL_MALLOC (long, *n);
			for(i = 0; i < *n; i++)
			{
				d[i] = position - starts[i];
			}
			return d;
		case '-':
			starts = (T->get_starts)(chrom, idx, n);
			d = GDL_MALLOC (long, *n);
			for(i = 0; i < *n; i++)
			{
				d[i] = starts[i] - position;
			}
			return d;
	}
}

static long
gdl_expr_feature_type_anchor_FES_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature_type * T, const size_t idx[], const size_t unit_idx, const long position)
{
	size_t i;
	const unsigned char strand = (T->get_strand)(chrom, idx);
	const size_t nunit         = (T->get_unit_size)(chrom, idx);
	long * starts              = GDL_MALLOC (long, nunit);
	long d;

	switch(strand)
	{
		case '+':
			(T->get_unit_ends)(chrom, idx, starts);
			d = position - starts[unit_idx];
			GDL_FREE (starts);
			return d;
		case '-':
			(T->get_unit_starts)(chrom, idx, starts);
			d = starts[unit_idx] - position;
			GDL_FREE (starts);
			return d;
	}
}

static long
gdl_expr_feature_anchor_FES_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FES_d_min (chrom, feature->T, feature->idx, position);
}

static long
gdl_expr_feature_anchor_FES_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FES_d_max (chrom, feature->T, feature->idx, position);
}

static long
gdl_expr_feature_anchor_FES_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return gdl_expr_feature_type_anchor_FES_d_avg (chrom, feature->T, feature->idx, position);
}

static long *
gdl_expr_feature_anchor_FES_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	return gdl_expr_feature_type_anchor_FES_d (chrom, feature->T, feature->idx, position, n);
}

static long
gdl_expr_feature_anchor_FES_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	return gdl_expr_feature_type_anchor_FES_d0 (chrom, feature->T, feature->idx, unit_idx, position);
}

const static gdl_expr_feature_anchor _FES =
{
	"gdl_expr_feature_anchor_FES",
	"FES",
	&gdl_expr_feature_anchor_FES_d_min,
	&gdl_expr_feature_anchor_FES_d_max,
	&gdl_expr_feature_anchor_FES_d_avg,
	&gdl_expr_feature_anchor_FES_d,
	&gdl_expr_feature_anchor_FES_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FES = &_FES;

static long
gdl_expr_feature_anchor_TES_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FES_d_min (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FES_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FES_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FES_d_min (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long
gdl_expr_feature_anchor_TES_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FES_d_max (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FES_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FES_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FES_d_max (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long
gdl_expr_feature_anchor_TES_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FES_d_avg (chrom, feature, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FES_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FES_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FES_d_avg (chrom, gdl_expr_feature_gene, feature->idx, position);
	}
}

static long *
gdl_expr_feature_anchor_TES_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FES_d (chrom, feature, position, n);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FES_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FES_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FES_d (chrom, gdl_expr_feature_gene, feature->idx, position, n);
	}
}

static long
gdl_expr_feature_anchor_TES_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	if (feature->T == gdl_expr_feature_probe)
	{
		// not available, because a probe can have multiple parents ??
		return gdl_expr_feature_anchor_FES_d0 (chrom, feature, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_exon)
	{
		return gdl_expr_feature_type_anchor_FES_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_transcript)
	{
		return gdl_expr_feature_type_anchor_FES_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
	if (feature->T == gdl_expr_feature_gene)
	{
		return gdl_expr_feature_type_anchor_FES_d0 (chrom, gdl_expr_feature_gene, feature->idx, unit_idx, position);
	}
}

const static gdl_expr_feature_anchor _TES =
{
	"gdl_expr_feature_anchor_TES",
	"TES",
	&gdl_expr_feature_anchor_TES_d_min,
	&gdl_expr_feature_anchor_TES_d_max,
	&gdl_expr_feature_anchor_TES_d_avg,
	&gdl_expr_feature_anchor_TES_d,
	&gdl_expr_feature_anchor_TES_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_TES = &_TES;


/*
 *  expr/gdl_expr_feature_anchor.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_FEATURE_ANCHOR_H__
#define __GDL_EXPR_FEATURE_ANCHOR_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_expr_feature.h>

__BEGIN_DECLS

typedef struct
{
	gdl_string * name;
	gdl_string * acronym;
	long (*distance_min)(const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position);
	long (*distance_max)(const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position);
	long (*distance_avg)(const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position);
	long * (*distances)(const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * npos);
	long (*distance)(const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position);
} gdl_expr_feature_anchor;

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_lookup_acronym (const gdl_string * acronym);
const gdl_expr_feature_anchor * gdl_expr_feature_anchor_lookup_name (const gdl_string * name);
gdl_expr_feature_anchor * gdl_expr_feature_anchor_alloc (const gdl_expr_feature_anchor * T);
void gdl_expr_feature_anchor_free (gdl_expr_feature_anchor * T);
gdl_expr_feature_anchor * gdl_expr_feature_anchor_fread (FILE * stream);
int gdl_expr_feature_anchor_fwrite (FILE * stream, const gdl_expr_feature_anchor * T);

// Distance w.r.t to the start site(s) of the feature
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FSS;
// Distance w.r.t to the end site(s) of the feature
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FES;
// Distance w.r.t to the start site(s) of the parent feature (if any)
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_TSS;
// Distance w.r.t to the end site(s) of the parent feature (if any)
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_TES;
// Distance w.r.t to the mid point(s) of the feature
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FMID;
// Distance w.r.t to the probe site(s) of the feature
GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FPRB;
// Downstream distance w.r.t to the FSS limited to the feature size
//GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_DFSS;
//// Upstream distance w.r.t to the FES limited to the feature size
//GDL_VAR const gdl_expr_feature_anchor * gdl_expr_feature_anchor_DFES;

__END_DECLS

#endif

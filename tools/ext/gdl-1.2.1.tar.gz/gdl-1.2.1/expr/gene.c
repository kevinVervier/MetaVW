/*
 *  expr/gene.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_expr_gene.h>

gdl_expr_gene *
gdl_expr_gene_alloc (const gdl_string * name, const unsigned char strand)
{
	gdl_expr_gene * g;

	g = GDL_CALLOC (gdl_expr_gene, 1);

	g->name   = gdl_string_clone (name);
	g->strand = strand;
	g->ignore = 'n';

	return g;
}

void
gdl_expr_gene_free (gdl_expr_gene * g)
{
	if (g)
	{
		size_t i;
		gdl_string_free (g->name);
		GDL_FREE (g->txStarts);
		GDL_FREE (g->txEnds);
		for(i = 0; i < g->nexon; i++)
		{
			gdl_expr_exon_free (g->exons[i]);
		}
		GDL_FREE (g->exons);
		for(i = 0; i < g->ntx; i++)
		{
			gdl_expr_transcript_free (g->transcripts[i]);
		}
		GDL_FREE (g->transcripts);
		for(i = 0; i < g->nprbtxset; i++)
		{
			gdl_expr_prbtxset_free (g->prbtxsets[i]);
		}
		GDL_FREE (g->prbtxsets);
		for(i = 0; i < g->nprbexset; i++)
		{
			gdl_expr_prbexset_free (g->prbexsets[i]);
		}
		GDL_FREE (g->prbexsets);
		GDL_FREE (g->probe_idx);
		GDL_FREE (g);
	}
}

gdl_expr_gene *
gdl_expr_gene_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		size_t i;
		gdl_expr_gene * g;

		g = GDL_CALLOC (gdl_expr_gene, 1);

		g->name = gdl_string_fread (stream);
		GDL_FREAD_STATUS (g->name != 0, 1, NULL);
		status = fread (&(g->strand), sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->ignore), sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->iscoding), sizeof(unsigned char), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		status = fread (&(g->nexon), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->ntx), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->nprobe), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->nprbtxset), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->nprbexset), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->ntxStart), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&(g->ntxEnd), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		if (g->ntxStart)
		{
			g->txStarts = GDL_MALLOC (size_t, g->ntxStart);
			status = fread (g->txStarts, sizeof (size_t), g->ntxStart, stream);
			GDL_FREAD_STATUS (status, g->ntxStart, NULL);
			g->txStartMin = g->txStarts[0];
		}
		if (g->ntxEnd)
		{
			g->txEnds = GDL_MALLOC (size_t, g->ntxEnd);
			status = fread (g->txEnds, sizeof (size_t), g->ntxEnd, stream);
			GDL_FREAD_STATUS (status, g->ntxEnd, NULL);
			g->txEndMax = g->txEnds[g->ntxEnd - 1];
		}
		if (g->nexon)
		{
			g->exons = GDL_MALLOC (gdl_expr_exon *, g->nexon);
			for (i = 0; i < g->nexon; i++)
			{
				g->exons[i] = gdl_expr_exon_fread (stream);
				GDL_FREAD_STATUS (g->exons[i] != 0, 1, NULL);
			}
		}
		if (g->nprobe)
		{
			g->probe_idx = GDL_MALLOC (size_t, g->nprobe);
			status = fread (g->probe_idx, sizeof (size_t), g->nprobe, stream);
			GDL_FREAD_STATUS (status, g->nprobe, NULL);
		}
		if (g->ntx)
		{
			g->transcripts = GDL_MALLOC (gdl_expr_transcript *, g->ntx);
			for (i = 0; i < g->ntx; i++)
			{
				g->transcripts[i] = gdl_expr_transcript_fread (stream);
				GDL_FREAD_STATUS (g->transcripts[i] != 0, 1, NULL);
			}
		}
		if (g->nprbtxset)
		{
			g->prbtxsets = GDL_MALLOC (gdl_expr_prbtxset *, g->nprbtxset);
			for (i = 0; i < g->nprbtxset; i++)
			{
				g->prbtxsets[i] = gdl_expr_prbtxset_fread (stream);
				GDL_FREAD_STATUS (g->prbtxsets[i] != 0, 1, NULL);
			}
		}
		if (g->nprbexset)
		{
			g->prbexsets = GDL_MALLOC (gdl_expr_prbexset *, g->nprbexset);
			for (i = 0; i < g->nprbexset; i++)
			{
				g->prbexsets[i] = gdl_expr_prbexset_fread (stream);
				GDL_FREAD_STATUS (g->prbexsets[i] != 0, 1, NULL);
			}
		}

		return g;
	}
	return 0;
}

int
gdl_expr_gene_fwrite (FILE * stream, const gdl_expr_gene * g)
{
	if (stream && g)
	{
		int status;
		size_t i;

		status = gdl_string_fwrite (stream, g->name);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		status = fwrite (&(g->strand), sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->ignore), sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->iscoding), sizeof(unsigned char), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->nexon), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->ntx), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->nprobe), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->nprbtxset), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->nprbexset), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->ntxStart), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&(g->ntxEnd), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		if (g->ntxStart)
		{
			status = fwrite (g->txStarts, sizeof (size_t), g->ntxStart, stream);
			GDL_FWRITE_STATUS (status, g->ntxStart, 1);
		}
		if (g->ntxEnd)
		{
			status = fwrite (g->txEnds, sizeof (size_t), g->ntxEnd, stream);
			GDL_FWRITE_STATUS (status, g->ntxEnd, 1);
		}
		if (g->nexon)
		{
			for (i = 0; i < g->nexon; i++)
			{
				status = gdl_expr_exon_fwrite (stream, g->exons[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}
		if (g->nprobe)
		{
			status = fwrite (g->probe_idx, sizeof (size_t), g->nprobe, stream);
			GDL_FWRITE_STATUS (status, g->nprobe, 1);
		}
		if (g->ntx)
		{
			for (i = 0; i < g->ntx; i++)
			{
				status = gdl_expr_transcript_fwrite (stream, g->transcripts[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}
		if (g->nprbtxset)
		{
			for (i = 0; i < g->nprbtxset; i++)
			{
				status = gdl_expr_prbtxset_fwrite (stream, g->prbtxsets[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}
		if (g->nprbexset)
		{
			for (i = 0; i < g->nprbexset; i++)
			{
				status = gdl_expr_prbexset_fwrite (stream, g->prbexsets[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

size_t *
gdl_expr_gene_add_exons(gdl_expr_gene * g, const size_t tx, const size_t exonStarts[], const size_t exonEnds[], const size_t nexon)
{
	size_t i, j, k = 0, * idx;

	idx = GDL_CALLOC (size_t, nexon);

	if (g->nexon)
	{
		for(i = 0; i < nexon; i++)
		{
			for(j = 0; j < g->nexon; j++)
			{
				if (exonStarts[i]==g->exons[j]->start && exonEnds[i]==g->exons[j]->end)
				{
					idx[i] = j;
					break;
				}
			}
			if (j == g->nexon)
			{
				gdl_expr_exon ** tmp = GDL_MALLOC (gdl_expr_exon *, (g->nexon + k + 1));
				memcpy(tmp, g->exons, sizeof(gdl_expr_exon *)*(g->nexon + k));
				GDL_FREE (g->exons);
				g->exons        = tmp;
				g->exons[j + k] = gdl_expr_exon_alloc (exonStarts[i], exonEnds[i]);
				idx[i] = j + k;
				k++;
			}
			gdl_expr_exon_add_tx (g->exons[idx[i]], tx);
		}
		g->nexon += k;
	}
	else
	{
		g->exons = GDL_MALLOC (gdl_expr_exon *, nexon);
		for(i = 0; i < nexon; i++)
		{
			g->exons[i] = gdl_expr_exon_alloc (exonStarts[i], exonEnds[i]);
			gdl_expr_exon_add_tx (g->exons[i], tx);
			idx[i] = i;
		}
		g->nexon = nexon;
	}

	return idx;

}

void
gdl_expr_gene_set_boundaries (gdl_expr_gene * g)
{
	size_t i;
	gdl_string * tok;
	gdl_hashtable_itr * itr;
	gdl_hashtable * txStartsTab, * txEndsTab;

	txStartsTab = gdl_hashtable_alloc (gdl_string_interface, 0);
	txEndsTab   = gdl_hashtable_alloc (gdl_string_interface, 0);

	for(i = 0; i < g->ntx; i++)
	{
		size_t f_exon = g->transcripts[i]->exon_idx[0];
		size_t l_exon = g->transcripts[i]->exon_idx[g->transcripts[i]->nexon - 1];

		tok = gdl_string_sprintf ("%d", g->exons[f_exon]->start);
		gdl_hashtable_add (txStartsTab, tok, tok, 1);
		tok = gdl_string_sprintf ("%d", g->exons[l_exon]->end);
		gdl_hashtable_add (txEndsTab, tok, tok, 1);
	}

	if (gdl_hashtable_size (txStartsTab))
	{
		g->ntxStart = gdl_hashtable_size (txStartsTab);
		g->txStarts = GDL_MALLOC (size_t, g->ntxStart);

		itr = gdl_hashtable_iterator (txStartsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			g->txStarts[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (g->txStarts, 1, g->ntxStart);
		g->txStartMin = g->txStarts[0];
	}
	if (gdl_hashtable_size (txEndsTab))
	{
		g->ntxEnd = gdl_hashtable_size (txEndsTab);
		g->txEnds = GDL_MALLOC (size_t, g->ntxEnd);

		itr = gdl_hashtable_iterator (txEndsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			g->txEnds[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (g->txEnds, 1, g->ntxEnd);
		g->txEndMax = g->txEnds[g->ntxEnd-1];
	}

	gdl_hashtable_free (txStartsTab);
	gdl_hashtable_free (txEndsTab);
}

size_t
gdl_expr_gene_add_probe (gdl_expr_gene * p, const size_t e)
{
	if (p->nprobe)
	{
		size_t * tmp = GDL_MALLOC (size_t, p->nprobe + 1);
		memcpy(tmp, p->probe_idx, sizeof(size_t)*p->nprobe);
		GDL_FREE (p->probe_idx);
		p->probe_idx = tmp;
	}
	else
	{
		p->probe_idx = GDL_MALLOC (size_t, 1);
	}
	p->probe_idx[p->nprobe] = e;

	return ++(p->nprobe);
}

void
gdl_expr_prbtxset_set_boundaries (const gdl_expr_gene * g, gdl_expr_prbtxset * p)
{
	size_t i;
	gdl_string * tok;
	gdl_hashtable_itr * itr;
	gdl_hashtable * txStartsTab, * txEndsTab;


	txStartsTab = gdl_hashtable_alloc (gdl_string_interface, 0);
	txEndsTab   = gdl_hashtable_alloc (gdl_string_interface, 0);

	for(i = 0; i < p->ntx; i++)
	{
		size_t f_exon = g->transcripts[p->tx_idx[i]]->exon_idx[0];
		size_t l_exon = g->transcripts[p->tx_idx[i]]->exon_idx[g->transcripts[p->tx_idx[i]]->nexon - 1];

		tok = gdl_string_sprintf ("%d", g->exons[f_exon]->start);
		gdl_hashtable_add (txStartsTab, tok, tok, 1);
		tok = gdl_string_sprintf ("%d", g->exons[l_exon]->end);
		gdl_hashtable_add (txEndsTab, tok, tok, 1);
	}

	if (gdl_hashtable_size (txStartsTab))
	{
		p->ntxStart = gdl_hashtable_size (txStartsTab);
		p->txStarts = GDL_MALLOC (size_t, p->ntxStart);

		itr = gdl_hashtable_iterator (txStartsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			p->txStarts[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (p->txStarts, 1, p->ntxStart);
		//p->txStartMin = p->txStarts[0];
	}
	if (gdl_hashtable_size (txEndsTab))
	{
		p->ntxEnd = gdl_hashtable_size (txEndsTab);
		p->txEnds = GDL_MALLOC (size_t, p->ntxEnd);

		itr = gdl_hashtable_iterator (txEndsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			p->txEnds[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (p->txEnds, 1, p->ntxEnd);
		//p->txEndMax = p->txEnds[g->ntxEnd-1];
	}

	gdl_hashtable_free (txStartsTab);
	gdl_hashtable_free (txEndsTab);
}

void
gdl_expr_prbexset_set_boundaries (const gdl_expr_gene * g, gdl_expr_prbexset * p)
{
	size_t i;
	gdl_string * tok;
	gdl_hashtable_itr * itr;
	gdl_hashtable * txStartsTab, * txEndsTab;


	txStartsTab = gdl_hashtable_alloc (gdl_string_interface, 0);
	txEndsTab   = gdl_hashtable_alloc (gdl_string_interface, 0);

	for(i = 0; i < p->nex; i++)
	{
		tok = gdl_string_sprintf ("%d",  g->exons[p->ex_idx[i]]->start);
		gdl_hashtable_add (txStartsTab, tok, tok, 1);
		tok = gdl_string_sprintf ("%d",  g->exons[p->ex_idx[i]]->end);
		gdl_hashtable_add (txEndsTab, tok, tok, 1);
	}
	if (gdl_hashtable_size (txStartsTab))
	{
		p->nexStart = gdl_hashtable_size (txStartsTab);
		p->exStarts = GDL_MALLOC (size_t, p->nexStart);

		itr = gdl_hashtable_iterator (txStartsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			p->exStarts[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (p->exStarts, 1, p->nexStart);
		//p->txStartMin = p->txStarts[0];
	}
	if (gdl_hashtable_size (txEndsTab))
	{
		p->nexEnd = gdl_hashtable_size (txEndsTab);
		p->exEnds = GDL_MALLOC (size_t, p->nexEnd);

		itr = gdl_hashtable_iterator (txEndsTab);
		i = 0;
		do
		{
			tok = gdl_hashtable_iterator_value (itr);
			p->exEnds[i++] = (size_t) atol(tok);
		}
		while(gdl_hashtable_iterator_next (itr));
		gdl_hashtable_iterator_free (itr);

		gdl_sort_ulong (p->exEnds, 1, p->nexEnd);
		//p->txEndMax = p->txEnds[g->ntxEnd-1];
	}

	gdl_hashtable_free (txStartsTab);
	gdl_hashtable_free (txEndsTab);
}

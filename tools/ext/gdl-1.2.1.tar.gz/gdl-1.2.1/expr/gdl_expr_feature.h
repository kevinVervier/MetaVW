/*
 *  expr/gdl_expr_feature.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_FEATURE_H__
#define __GDL_EXPR_FEATURE_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>

__BEGIN_DECLS

typedef struct
{
	gdl_string * feature_type;
	gdl_hashtable * values;
} gdl_expr_feature_parameter;

gdl_expr_feature_parameter * gdl_expr_feature_parameter_alloc (const gdl_string * feature_type);
void gdl_expr_feature_parameter_free (gdl_expr_feature_parameter * p);

double ** gdl_expr_summarize_qnorm (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[]);
double ** gdl_expr_summarize (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[], const gdl_expr_feature_parameter * p);

typedef struct gdl_expr_feature_chromosome gdl_expr_feature_chromosome;

typedef struct
{
	gdl_expr_gene       * gene;
	gdl_expr_exon       * exon;
	gdl_expr_transcript * transcript;
	gdl_expr_prbtxset   * prbtxset;
	gdl_expr_prbexset   * prbexset;
	gdl_expr_probe      * probe;
} gdl_expr_feature_entities;

typedef struct
{
	gdl_string * name;
	gdl_string * acronym;
	size_t nidx;
	int (*chrom_alloc)(gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger);
	void * (*get_feature)(const gdl_expr_chromosome * c, const size_t ids[]);
	const long * (*get_starts)(const gdl_expr_chromosome * c, const size_t ids[], size_t * n);
	const long * (*get_ends)(const gdl_expr_chromosome * c, const size_t ids[], size_t * n);
	unsigned char (*get_strand)(const gdl_expr_chromosome * c, const size_t ids[]);
	double ** (*get_data)(const gdl_expr_chromosome * c, size_t ids[], const gdl_expr_feature_parameter * p);
	size_t (*get_unit_size)(const gdl_expr_chromosome * c, const size_t ids[]);
	void (*get_unit_starts)(const gdl_expr_chromosome * c, const size_t ids[], long starts[]);
	void (*get_unit_ends)(const gdl_expr_chromosome * c, const size_t ids[], long ends[]);
	long (*get_unit_start)(const gdl_expr_chromosome * c, const size_t ids[], const size_t unit_idx);
	long (*get_unit_end)(const gdl_expr_chromosome * c, const size_t ids[], const size_t unit_idx);
	gdl_expr_feature_entities * (*get_unit_entities)(const gdl_expr_chromosome * c, const size_t ids[], const size_t unit_idx);
} gdl_expr_feature_type;

const gdl_expr_feature_type * gdl_expr_feature_type_lookup (const gdl_string * tok, const gdl_string * which);

typedef struct
{
	const gdl_expr_feature_type * T; /*< The type of the feature                                */
	gdl_string * name;			 /*< The name of the feature                                */
	size_t * idx;			     /*< The index of the corresponding feature in the database */
	double ** data;		         /*< The expr data for that feature                         */
	size_t nprobe;				 /*< The probe for that feature                             */
	size_t * probe_idx;  		 /*< The index of the probe for that feature                */
	size_t nprobe_pos;			 /*< Number of probe positions                              */
	size_t * probe_starts;       /*< 5' starting position of the probes                     */
	size_t * probe_ends;		 /*< 3' starting position of the probes                     */
} gdl_expr_feature;

gdl_expr_feature * gdl_expr_feature_alloc (const gdl_expr_feature_type * T, const size_t * idx);
void gdl_expr_feature_free (gdl_expr_feature * f, const gdl_expr_chromosome * c);
gdl_expr_feature * gdl_expr_feature_fread (FILE * stream, const gdl_expr_feature_type * T, const gdl_expr_chromosome * c);
int gdl_expr_feature_fwrite (FILE * stream, const gdl_expr_feature * f, const gdl_expr_feature_type * T, const gdl_expr_chromosome * c);
void gdl_expr_feature_set_probe_positions (const gdl_expr_chromosome * c, gdl_expr_feature * f);
long gdl_expr_feature_get_min_start (const gdl_expr_feature * f, const gdl_expr_chromosome * c);
long gdl_expr_feature_get_max_end (const gdl_expr_feature * f, const gdl_expr_chromosome * c);
long gdl_expr_feature_get_unit_start (const gdl_expr_feature * f, const gdl_expr_chromosome * c, const size_t unit_idx);
long gdl_expr_feature_get_unit_end (const gdl_expr_feature * f, const gdl_expr_chromosome * c, const size_t unit_idx);
gdl_boolean gdl_expr_feature_is_within_probe (const gdl_expr_feature * f, const long position);
void gdl_expr_feature_create_name (const gdl_expr_chromosome * c, gdl_expr_feature * feature, const gdl_string * prefix);

struct gdl_expr_feature_chromosome
{
	const gdl_expr_feature_type * T;
	gdl_string * name;
	size_t nfeature;
	gdl_expr_feature ** features;
};

gdl_expr_feature_chromosome * gdl_expr_feature_chromosome_alloc (const gdl_expr_feature_type * T, const gdl_expr_chromosome * e_chrom, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger);
void gdl_expr_feature_chromosome_free (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c);
gdl_expr_feature_chromosome * gdl_expr_feature_chromosome_fread (FILE * stream, const gdl_expr_chromosome * c);
int gdl_expr_feature_chromosome_fwrite (FILE * stream, const gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c);
int gdl_expr_feature_chromosome_fprintf (const gdl_expr_chromosome * c, const gdl_expr_feature_chromosome * f_c, gdl_string ** pop_names, const gdl_string * output);
void gdl_expr_feature_get_unit_entities (const gdl_expr_chromosome * c, const gdl_expr_feature * feature, gdl_expr_gene ** gene, gdl_expr_prbtxset ** prbtx, gdl_expr_transcript ** transcript, const size_t u);

typedef struct
{
	const gdl_expr_feature_type * T;
	size_t nchrom;
	gdl_string      * dbdir;
	gdl_string    ** chroms;
} gdl_expr_feature_genome;

gdl_expr_feature_genome * gdl_expr_feature_genome_alloc (const gdl_expr_genome * expr_data, const gdl_expr_feature_parameter * p, const gdl_string * db_dir, FILE * progress, FILE * logger);
void gdl_expr_feature_genome_free (gdl_expr_feature_genome * v);
void gdl_expr_feature_genome_rm (gdl_expr_feature_genome * v);
gdl_expr_feature_chromosome * gdl_expr_feature_genome_get (const gdl_expr_feature_genome * g, size_t i, const gdl_expr_chromosome * c);
int gdl_expr_feature_genome_set (const gdl_expr_feature_genome * g, size_t i, gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c);
gdl_expr_feature_genome * gdl_expr_feature_genome_fread (FILE * stream);
int gdl_expr_feature_genome_fwrite (FILE * stream, const gdl_expr_feature_genome * v);
int gdl_expr_feature_genome_fprintf (const gdl_expr_genome * g, const gdl_expr_feature_genome * gf, gdl_string ** pop_names, const gdl_string * output);



gdl_expr_feature_genome * gdl_expr_feature_genome_subset (gdl_expr_genome * expr_data, gdl_expr_feature_genome * g, gdl_string ** sample_names, gdl_string ** sub_sample_names, const size_t nsub_sample, const gdl_string * output);

GDL_VAR const gdl_expr_feature_type * gdl_expr_feature_probe;
GDL_VAR const gdl_expr_feature_type * gdl_expr_feature_exon;
GDL_VAR const gdl_expr_feature_type * gdl_expr_feature_metaexon;
GDL_VAR const gdl_expr_feature_type * gdl_expr_feature_transcript;
GDL_VAR const gdl_expr_feature_type * gdl_expr_feature_gene;

// utilities to get the size of the different gene structure compartments
long gdl_expr_feature_size_of_5utr(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_3utr(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_exon(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_intron(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_cds_intron(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_non_cds_intron(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_first_intron(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_last_intron(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_cds_exon(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_non_cds_exon(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_first_exon(const gdl_expr_feature * g, const gdl_expr_chromosome * c);
long gdl_expr_feature_size_of_last_exon(const gdl_expr_feature * g, const gdl_expr_chromosome * c);

double ** gdl_expr_feature_exon_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p);
double ** gdl_expr_feature_gene_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p);

typedef struct
{
	gdl_hashtable * table;
	FILE * _logger;
} gdl_expr_transcript_weights;

gdl_expr_transcript_weights * gdl_expr_transcript_weights_alloc (const gdl_string * filename);
void gdl_expr_transcript_weights_free (gdl_expr_transcript_weights * tw);
gdl_boolean gdl_expr_transcript_weights_is_inside (const gdl_expr_transcript_weights * table, const gdl_string * chrom, const gdl_string * gene, const gdl_string * tx);
double gdl_expr_transcript_weights_get (const gdl_expr_transcript_weights * tw, const gdl_string * chrom, const gdl_string * gene, const gdl_string * tx);
double * gdl_expr_feature_get_unit_weights (const gdl_expr_chromosome * c, const gdl_expr_feature * f, const gdl_expr_transcript_weights * w);


__END_DECLS

#endif

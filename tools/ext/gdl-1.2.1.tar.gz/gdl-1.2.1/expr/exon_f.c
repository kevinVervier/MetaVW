/*
 *  expr/exon_f.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_sort.h>
#include <gdl/gdl_statistics.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

static void
_gdl_expr_feature_exon_set_probe (gdl_expr_feature * f, const gdl_expr_chromosome * c, const size_t idx[])
{
	// how many probes
	size_t i, j, k, e, np = 0;
 	for(i = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
//		if (probe->nexon == 1 && probe->exon_idx[0] == idx[1])
//		{
//			np++;
//		}
		for(e = 0; e < probe->nexon; e++)
		{
			if (probe->gx_idx[e] == idx[0] && probe->ex_idx[e] == idx[1])
			{
				np++;
				break;
			}
		}
	}
	if (np)
	{
		f->nprobe    = np;
		f->probe_idx = GDL_MALLOC (size_t, f->nprobe);
		for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
		{
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
//			if (probe->nexon == 1 && probe->exon_idx[0] == idx[1])
//			{
//				f->probe_idx[j] = c->genes[idx[0]]->probe_idx[i];
//				j++;
//			}
			for(e = 0; e < probe->nexon; e++)
			{
				if (probe->gx_idx[e] == idx[0] && probe->ex_idx[e] == idx[1])
				{
					f->probe_idx[j] = c->genes[idx[0]]->probe_idx[i];
					j++;
					break;
				}
			}
		}
	}
}

//
// TODO - UIPDATE TO DEAL WITH PROBE WITH MULTIPLE EXON INCLUSIONS
//

double **
gdl_expr_feature_exon_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p)
{
	// how many probes
	size_t i, j, k, e, np = 0;
 	for(i = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
//		if (probe->nexon == 1 && probe->exon_idx[0] == idx[1])
//		{
//			np++;
//		}
		for(e = 0; e < probe->nexon; e++)
		{
			if (probe->gx_idx[e] == idx[0] && probe->ex_idx[e] == idx[1])
			{
				np++;
				break;
			}
		}
	}
	if (np > 1)
	{
		double *** X = GDL_MALLOC (double **, np);
	    double ** Y = 0;
	    for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
//			if (probe->nexon == 1 && probe->exon_idx[0] == idx[1])
//			{
//				X[j] = probe->data;
//				j++;
//			}
			for(e = 0; e < probe->nexon; e++)
			{
				if (probe->gx_idx[e] == idx[0] && probe->ex_idx[e] == idx[1])
				{
					X[j] = probe->data;
					j++;
					break;
				}
			}
		}

		Y = gdl_expr_summarize (X, np, c->npop, c->pop_sizes, p);

		GDL_FREE (X);

		return Y;
	}
	else if (np == 1)
	{
		for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
//			if (probe->nexon == 1 && probe->exon_idx[0] == idx[1])
//			{
//				 double ** Y = GDL_MALLOC(double *, c->npop);
//				 for(k = 0; k < c->npop; k++)
//				 {
//				    Y[k] = GDL_MALLOC (double, c->pop_sizes[k]);
//				    memcpy(Y[k], probe->data[k], sizeof(double)*c->pop_sizes[k]);
//				 }
//				 return Y;
//			}
			for(e = 0; e < probe->nexon; e++)
			{
				if (probe->gx_idx[e] == idx[0] && probe->ex_idx[e] == idx[1])
				{
					double ** Y = GDL_MALLOC(double *, c->npop);
					 for(k = 0; k < c->npop; k++)
					 {
						Y[k] = GDL_MALLOC (double, c->pop_sizes[k]);
						memcpy(Y[k], probe->data[k], sizeof(double)*c->pop_sizes[k]);
					 }
					 return Y;
				}
			}
		}
	}
	else
	{
		// UNEXPECTED ERROR
		return 0;
	}
}

static double ***
gdl_expr_firma_run (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[])
{
	size_t i, j, k;
	double *** Y, t, ** x, * r, * c, * z, * zo, s;

	Y = GDL_MALLOC (double **, K);
	for(j = 0; j < K; j++)
	{
		Y[j] = GDL_MALLOC (double *, npop);
		for(i = 0; i < npop; i++)
		{
			Y[j][i] = GDL_MALLOC (double, pop_sizes[i]);
		}
	}
	// we do the median polish within each population
	for(i = 0; i < npop; i++)
	{
		// workspace
		r  = GDL_CALLOC (double, pop_sizes[i]);
		x  = GDL_MATRIX_ALLOC (double, K, pop_sizes[i]);
		c  = GDL_CALLOC (double, K);
		z  = GDL_CALLOC (double, pop_sizes[i]*K);
		zo = GDL_CALLOC (double, pop_sizes[i]*K);
		for(j = 0; j < K; j++)
		{
			memcpy(x[j], X[j][i], sizeof(double)*pop_sizes[i]);
		}
		gdl_stats_medpolish (x, K, pop_sizes[i], 1.e-3, 25, &t, c, r, z);
		for(j = k = 0; j < pop_sizes[i]*K; j++)
		{
			if (!gdl_isnan(z[j])) // missing data
			{
				zo[k++] = z[j];
			}
		}
		if (k)
		{
			gdl_sort(zo, 1, k);
			s = gdl_stats_median_from_sorted_data (zo, 1, k);
		}
		else
		{
			s = 0.0;
		}
		for(j = 0; j < K; j++)
		{
			for(k = 0; k < pop_sizes[i]; k++)
			{
				if (!gdl_isnan(X[j][i][k]))
				{
					Y[j][i][k] = z[j*pop_sizes[i]+k];
					if (s != 0.)
					{
						Y[j][i][k] /= s;
					}
				}
				else
				{
					Y[j][i][k] = GDL_NAN;
				}
			}
		}
		GDL_MATRIX_FREE (x, K);
		GDL_FREE (c);
		GDL_FREE (r);
		GDL_FREE (z);
		GDL_FREE (zo);
	}

	return Y;
}

static double ***
gdl_expr_firma_data (const gdl_expr_chromosome * c, const size_t idx[], size_t ** firma_idx, size_t * firma_n)
{
	size_t i, j, k, np = 0;
	double *** X  = 0;

	for(np = i = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		k=i;
		np++;
	}

	*firma_n   = np;
	*firma_idx = GDL_MALLOC (size_t, np);

	X = GDL_MALLOC (double **, np);

    for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		(*firma_idx)[j] = c->genes[idx[0]]->probe_idx[i];
		X[j++]          = probe->data;
	}

    double *** Y = gdl_expr_firma_run (X, j, c->npop, c->pop_sizes);

    GDL_FREE (X);

	return Y;
}

//
// TODO - UPDATE TO DEAL WITH PROBE WITH MULTIPLE EXON INCLUSIONS
//
static int
_gdl_expr_feature_exon_alloc (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
	size_t i, j, k, l, n, e, * idx, nexon = 0;

	if (progress)
	{
		fprintf (progress, ">>Create Exon Features for Chromosome %s\n", c->name);
		fflush (progress);
	}
	if (!c->ngene)
	{
		GDL_WARNING ("No gene defined for that chromosome\n", GDL_EINVAL);
		f->nfeature = 0;
		f->features = 0;
		return GDL_EINVAL;
	}
	// how many exon with at least one probe
	size_t ** nex = GDL_CALLOC (size_t *, c->ngene);
	for(i = 0; i < c->ngene; i++)
	{
		nex[i] = GDL_CALLOC (size_t, c->genes[i]->nexon);
		for(k = j = 0; j < c->genes[i]->nprobe; j++)
		{
			gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[j]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
//			if (probe->nexon == 1)
//			{
//				// is that probe fully included into a single exon (we ignore here probe in exon-exon boundaries)
//				nex[i][probe->exon_idx[0]] = 1;
//				k = 1;
//			}
			for(e = 0; e < probe->nexon; e++)
			{
				if (probe->gx_idx[e] == i)
				{
					nex[i][probe->ex_idx[e]] = 1;
					k=1;
				}
			}
		}
		if (k)
		{
			for(j = 0; j < c->genes[i]->nexon; j++)
			{
				nexon += nex[i][j];
			}
		}
		else
		{
			GDL_FREE (nex[i]);
			nex[i] = 0;
		}
	}
	if (progress)
	{
		fprintf (progress, " #Exon(with at least one probe) = %ld\n", nexon);
		fflush (progress);
	}

	f->nfeature = nexon;
	f->features = GDL_MALLOC (gdl_expr_feature *, nexon);

	idx = GDL_MALLOC (size_t, 2);

	for(i = k = 0; i < c->ngene; i++)
	{
		if (nex[i])
		{
			gdl_string * exon_index   = gdl_hashtable_lookup (p->values, "ExonIndex");
			double     **  eg_data    = 0;
			double     *** firma_data = 0;
			size_t     * firma_prbidx = 0;
			size_t       firma_nprb   = 0;

			if (exon_index && !strcmp(exon_index, "firma"))
			{
				firma_data = gdl_expr_firma_data (c, &i, &firma_prbidx, &firma_nprb);
			}
			else if (exon_index && !strcmp(exon_index, "e/g"))
			{
				eg_data = gdl_expr_feature_gene_data (c, &i, p);
			}
			idx[0] = i;
			for(j = 0; j < c->genes[i]->nexon; j++)
			{
				if (nex[i][j])
				{
					idx[1] = j;
					f->features[k]  = gdl_expr_feature_alloc (gdl_expr_feature_exon, idx);
					_gdl_expr_feature_exon_set_probe(f->features[k], c, idx);
					gdl_expr_feature_set_probe_positions (c, f->features[k]);
					gdl_expr_feature_create_name (c, f->features[k], c->genes[i]->name);
					if (firma_data && firma_nprb > 1)
					{
						double *** X = GDL_MALLOC (double **, f->features[k]->nprobe);
						for(l = 0; l < f->features[k]->nprobe; l++)
						{
							for(n = 0; n < firma_nprb; n++)
							{
								if (f->features[k]->probe_idx[l]==firma_prbidx[n])
								{
									break;
								}
							}
							if (n == firma_nprb)
							{
								GDL_ERROR_VAL("Internal error", GDL_FAILURE, GDL_FAILURE);
							}
							X[l] = firma_data[n];
						}
						f->features[k]->data = gdl_expr_summarize (X, f->features[k]->nprobe, c->npop, c->pop_sizes, p);
						GDL_FREE (X);
					}
					else
					{
						f->features[k]->data = gdl_expr_feature_exon_data (c, idx, p);
						if (eg_data)
						{
							for(l = 0; l < c->npop; l++)
							{
								for(n = 0; n < c->pop_sizes[l]; n++)
								{
									if (!gdl_isnan (f->features[k]->data[l][n]))
									{
										f->features[k]->data[l][n] -= eg_data[l][n];
									}
								}
							}
						}
					}
					k++;
				}
			}
			if (firma_data)
			{
				for(j = 0; j < firma_nprb; j++)
				{
					GDL_MATRIX_FREE (firma_data[j], c->npop);
				}
				GDL_FREE (firma_data);
				GDL_FREE (firma_prbidx);
			}
			else if (eg_data)
			{
				GDL_MATRIX_FREE (eg_data, c->npop);
			}
		}
	}

	GDL_FREE (idx);

	return GDL_SUCCESS;
}

static void *
_gdl_expr_feature_exon_get (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->exons[idx[1]];
}

static const long *
_gdl_expr_feature_exon_starts (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = 1;
	return &(c->genes[idx[0]]->exons[idx[1]]->start);
}

static const long *
_gdl_expr_feature_exon_ends (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = 1;
	return &(c->genes[idx[0]]->exons[idx[1]]->end);
}

static unsigned char
_gdl_expr_feature_exon_strand (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->strand;
}

static size_t
_gdl_expr_feature_exon_unit_size (const gdl_expr_chromosome * c, const size_t idx[])
{
	return 1;
	//return c->genes[idx[0]]->exons[idx[1]]->ntx;
}

static void
_gdl_expr_feature_exon_unit_starts(const gdl_expr_chromosome * c, const size_t idx[], long starts[])
{
//	size_t i;
//
//	for(i = 0; i < c->genes[idx[0]]->exons[idx[1]]->ntx; i++)
//	{
//		starts[i] = c->genes[idx[0]]->transcripts[c->genes[idx[0]]->exons[idx[1]]->tx_idx[i]]->txStart;
//	}
	starts[0] = c->genes[idx[0]]->exons[idx[1]]->start;
}

static void
_gdl_expr_feature_exon_unit_ends(const gdl_expr_chromosome * c, const size_t idx[], long ends[])
{
//	size_t i;
//
//	for(i = 0; i < c->genes[idx[0]]->exons[idx[1]]->ntx; i++)
//	{
//		ends[i] = c->genes[idx[0]]->transcripts[c->genes[idx[0]]->exons[idx[1]]->tx_idx[i]]->txEnd;
//	}
	ends[0] = c->genes[idx[0]]->exons[idx[1]]->end;
}

static long
_gdl_expr_feature_exon_unit_start (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->exons[idx[1]]->start;
	//return c->genes[idx[0]]->transcripts[c->genes[idx[0]]->exons[idx[1]]->tx_idx[unit_idx]]->txStart;
}

static long
_gdl_expr_feature_exon_unit_end (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->exons[idx[1]]->end;
	//return c->genes[idx[0]]->transcripts[c->genes[idx[0]]->exons[idx[1]]->tx_idx[unit_idx]]->txEnd;
}

static gdl_expr_feature_entities *
_gdl_expr_feature_exon_unit_entities (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	gdl_expr_feature_entities * e = GDL_CALLOC (gdl_expr_feature_entities, 1);

	e->gene       = c->genes[idx[0]];
	e->exon       = e->gene->exons[idx[1]];
	e->transcript = e->gene->transcripts[e->exon->tx_idx[unit_idx]];

	return e;
}

static const gdl_expr_feature_type _gdl_expr_feature_exon =
{
	"gdl_expr_feature_exon",
	"exon",
	2,
	&_gdl_expr_feature_exon_alloc,
	&_gdl_expr_feature_exon_get,
	&_gdl_expr_feature_exon_starts,
	&_gdl_expr_feature_exon_ends,
	&_gdl_expr_feature_exon_strand,
	&gdl_expr_feature_exon_data,
	&_gdl_expr_feature_exon_unit_size,
	&_gdl_expr_feature_exon_unit_starts,
	&_gdl_expr_feature_exon_unit_ends,
	&_gdl_expr_feature_exon_unit_start,
	&_gdl_expr_feature_exon_unit_end,
	&_gdl_expr_feature_exon_unit_entities
};

const gdl_expr_feature_type * gdl_expr_feature_exon       = &_gdl_expr_feature_exon;


/*
 *  expr/prbtxset.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *  
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_sort.h>
#include <gdl/gdl_statistics.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_specfunc.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_expr_prbtxset.h>

gdl_expr_prbtxset *
gdl_expr_prbtxset_alloc (const size_t ntx, const size_t nprobe)
{
	gdl_expr_prbtxset * p;
	
	p = GDL_CALLOC (gdl_expr_prbtxset, 1);
	
	p->ntx    = ntx;
	p->nprobe = nprobe;
	
	if (ntx)
	{
		p->tx_idx = GDL_CALLOC (size_t, ntx);
	}
	if (nprobe)
	{
		p->probe_idx = GDL_CALLOC (size_t, nprobe);
	}
	
	return p;
}

void
gdl_expr_prbtxset_free (gdl_expr_prbtxset * p)
{
	if (p)
	{
		GDL_FREE (p->tx_idx);
		GDL_FREE (p->probe_idx);
		GDL_FREE (p->txStarts);
		GDL_FREE (p->txEnds);
		GDL_FREE (p);
	}
}


gdl_expr_prbtxset *
gdl_expr_prbtxset_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		gdl_expr_prbtxset * p;

		p = GDL_CALLOC (gdl_expr_prbtxset, 1);
		
		status = fread(&(p->ntx), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->nprobe), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->ntxStart), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->ntxEnd), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		
		if (p->ntx)
		{
			p->tx_idx = GDL_MALLOC (size_t, p->ntx);
			status = fread(p->tx_idx, sizeof(size_t), p->ntx, stream);
			GDL_FREAD_STATUS (status, p->ntx, NULL);
		}
		if (p->nprobe)
		{
			p->probe_idx = GDL_MALLOC (size_t, p->nprobe);
			status = fread(p->probe_idx, sizeof(size_t), p->nprobe, stream);
			GDL_FREAD_STATUS (status, p->nprobe, NULL);
		}
		if (p->ntxStart)
		{
			p->txStarts = GDL_MALLOC (size_t, p->ntxStart);
			status = fread(p->txStarts, sizeof(size_t), p->ntxStart, stream);
			GDL_FREAD_STATUS (status, p->ntxStart, NULL);
		}		
		if (p->ntxEnd)
		{
			p->txEnds = GDL_MALLOC (size_t, p->ntxEnd);
			status = fread(p->txEnds, sizeof(size_t), p->ntxEnd, stream);
			GDL_FREAD_STATUS (status, p->ntxEnd, NULL);
		}
		
		return p;
	}
	return 0;	
}

int
gdl_expr_prbtxset_fwrite (FILE * stream, const gdl_expr_prbtxset * p)
{
	if (stream && p)
	{
		int status;

		status = fwrite(&(p->ntx), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->nprobe), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->ntxStart), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->ntxEnd), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		
		if (p->ntx)
		{
			status = fwrite(p->tx_idx, sizeof(size_t), p->ntx, stream);
			GDL_FWRITE_STATUS (status, p->ntx, 1);
		}
		if (p->nprobe)
		{
			status = fwrite(p->probe_idx, sizeof(size_t), p->nprobe, stream);
			GDL_FWRITE_STATUS (status, p->nprobe, 1);
		}
		if (p->ntxStart)
		{
			status = fwrite(p->txStarts, sizeof(size_t), p->ntxStart, stream);
			GDL_FWRITE_STATUS (status, p->ntxStart, 1);
		}		
		if (p->ntxEnd)
		{
			status = fwrite(p->txEnds, sizeof(size_t), p->ntxEnd, stream);
			GDL_FWRITE_STATUS (status, p->ntxEnd, 1);
		}
			
		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

/*
 *  expr/txweight.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_expr_feature.h>

static gdl_expr_transcript_weights *
gdl_expr_transcript_weights_fscanf (FILE * stream)
{
	size_t i,j,n;
	gdl_string * tok, * tok2, * line=0;
	gdl_expr_transcript_weights * table;
	gdl_hashtable * chrom_table;
	gdl_hashtable * feature_table;
	gdl_string * snp;

	table = GDL_CALLOC (gdl_expr_transcript_weights, 1);

	table->table = gdl_hashtable_alloc (gdl_hash_default, 0);

	// ignore header
	gdl_getline (&line, &n, stream);
	gdl_string_free (line);line=0;
	while(gdl_getline (&line, &n, stream)!=-1)
	{
		i=j=0;
		// chrom name
		tok=gdl_string_next_token (line, n, &i, &j);
		chrom_table = gdl_hashtable_lookup (table->table, tok);
		if (!chrom_table)
		{
			chrom_table = gdl_hashtable_alloc (gdl_hash_default, 0);
			gdl_hashtable_add (table->table, tok, chrom_table, 0);
		}
		gdl_string_free (tok);
		// gene
		tok=gdl_string_next_token (line, n, &i, &j);
		feature_table = gdl_hashtable_lookup (chrom_table, tok);
		if (!feature_table)
		{
			feature_table = gdl_hashtable_alloc (gdl_interface_double, 0);
			gdl_hashtable_add (chrom_table, tok, feature_table, 0);
		}
		gdl_string_free (tok);
		// transcript
		tok=gdl_string_next_token (line, n, &i, &j);
		// score (optional)
		tok2=gdl_string_next_token (line, n, &i, &j);
		double * x = GDL_MALLOC (double, 1);
		*x = (double)atof (tok2);
		gdl_hashtable_add (feature_table, tok, x, 1);
		gdl_string_free (tok2);
		gdl_string_free (tok);
		gdl_string_free (line);line=0;
	}

	return table;
}

gdl_expr_transcript_weights *
gdl_expr_transcript_weights_alloc (const gdl_string * filename)
{
	gdl_expr_transcript_weights * w = 0;

	FILE * stream = gdl_fileopen (filename, "r");
	w = gdl_expr_transcript_weights_fscanf (stream);
	gdl_fileclose (filename, stream);

	return w;
}

gdl_boolean
gdl_expr_transcript_weights_is_inside (const gdl_expr_transcript_weights * table, const gdl_string * chrom, const gdl_string * gene, const gdl_string * transcript)
{
	if (!table->table) return gdl_false;
	gdl_hashtable * chrom_table = gdl_hashtable_lookup (table->table, chrom);
	if (!chrom_table) return gdl_false;
	gdl_hashtable * feature_table = gdl_hashtable_lookup (chrom_table, gene);
	if (!feature_table) return gdl_false;
	double * z = gdl_hashtable_lookup (feature_table, transcript);
	if (!z) return gdl_false;
	return gdl_true;
}

double
gdl_expr_transcript_weights_get (const gdl_expr_transcript_weights * table, const gdl_string * chrom, const gdl_string * gene, const gdl_string * tx)
{
	if (!table->table) return GDL_NAN;
	gdl_hashtable * chrom_table = gdl_hashtable_lookup (table->table, chrom);
	if (!chrom_table) return GDL_NAN;
	gdl_hashtable * feature_table = gdl_hashtable_lookup (chrom_table, gene);
	if (!feature_table) return GDL_NAN;
	double * z = gdl_hashtable_lookup (feature_table, tx);
	if (!z) return GDL_NAN;
	return *z;
}

void
gdl_expr_transcript_weights_free (gdl_expr_transcript_weights * table)
{
	if (table)
	{
		if (gdl_hashtable_size (table->table))
		{
			gdl_hashtable_itr * citr = gdl_hashtable_iterator (table->table);
			do
			{
				gdl_hashtable * chrom_table = (gdl_hashtable *) gdl_hashtable_iterator_value (citr);
				gdl_hashtable_itr * fitr    = gdl_hashtable_iterator (chrom_table);
				do
				{
					gdl_hashtable * feature_table = (gdl_hashtable *) gdl_hashtable_iterator_value (fitr);
					gdl_hashtable_free (feature_table);
				}
				while(gdl_hashtable_iterator_next (fitr));
				gdl_hashtable_iterator_free (fitr);
				gdl_hashtable_free (chrom_table);
			}
			while(gdl_hashtable_iterator_next (citr));
			gdl_hashtable_iterator_free (citr);
		}
		gdl_hashtable_free (table->table);
		GDL_FREE (table);
	}
}

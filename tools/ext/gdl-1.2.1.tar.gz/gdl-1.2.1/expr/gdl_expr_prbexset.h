/*
 *  expr/gdl_expr_prbexset.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2010  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_PRBEXSET_H__
#define __GDL_EXPR_PRBEXSET_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_vector_uint.h>
#include <gdl/gdl_expr_exon.h>

__BEGIN_DECLS

/*! \struct gdl_expr_prbexset
 *  \brief A PRoBed Exon(E) SET
 *
 *  A probed exon set is a set of exons which
 *  are interrogated by the same set of probes so that the summarized
 *  measurements from all the probes provide a measurement for the
 *  whole set of exons (in other words this measurement is a mixture
 *  of the expression levels of each individual exon which is part
 *  of this set).
 */
struct gdl_expr_prbexset
{
	size_t nex;				/**< The number of exons in the set            */
	size_t nprobe;		    /**< The number of probes for that set         */
	size_t * ex_idx;        /**< The exon indexes                          */
	size_t * probe_idx;     /**< The probes indexes                        */
	size_t nexStart;		/**< The number of exon starts 				   */
	size_t nexEnd;          /**< The number of exon ends  				   */
	size_t * exStarts; 		/**< The exon starts 				           */
	size_t * exEnds; 		/**< The exon ends 				               */
};

/*! \typedef gdl_expr_prbexset
 *  \brief A probe
 */
typedef struct gdl_expr_prbexset gdl_expr_prbexset;

gdl_expr_prbexset * gdl_expr_prbexset_alloc (const size_t nex, const size_t nprobe);
void gdl_expr_prbexset_free (gdl_expr_prbexset * b);

gdl_expr_prbexset * gdl_expr_prbexset_fread (FILE * stream);
int gdl_expr_prbexset_fwrite (FILE * stream, const gdl_expr_prbexset * p);

__END_DECLS

#endif

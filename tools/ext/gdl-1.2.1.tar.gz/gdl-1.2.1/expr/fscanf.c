/*
 *  expr/fscanf.c
 *
 *  $Author: tflutre $, $Date: 2011/09/25 17:28:49 $, $Revision: 1.2 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, University of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_expr_gene.h>
#include <gdl/gdl_expr_transcript.h>
#include <gdl/gdl_expr_exon.h>
#include <gdl/gdl_expr_probe.h>
#include <gdl/gdl_expr_chromosome.h>

static long *
_gdl_expr_get_probe_positions (const gdl_string * tok, size_t * npos)
{
  size_t i;
  gdl_string ** tmp = 0;
  long * pos;

  tmp = gdl_string_split (tok, ",", npos);

  if (*npos)
  {
    pos = GDL_MALLOC (long, *npos);
    for(i = 0; i < *npos; i++)
    {
      pos[i] = atol (tmp[i]);
      GDL_FREE (tmp[i]);
    }
  }
  GDL_FREE (tmp);

  return pos;
}

static gdl_expr_probe *
gdl_expr_probe_parse (const gdl_string * line, const size_t n)
{
  size_t i, j, size;
  gdl_string * name, * tok;
  unsigned char strand;
  long * starts, * ends;
  gdl_expr_probe * prb;

  i = j = 0;
  // first the probe name
  name = gdl_string_next_token (line, n, &i, &j);
  // strand
  tok    = gdl_string_next_token (line, n, &i, &j);
  strand = (unsigned char) tok[0];
  gdl_string_free (tok);
  // starts
  tok    = gdl_string_next_token (line, n, &i, &j);
  starts = _gdl_expr_get_probe_positions (tok, &size);
  gdl_string_free (tok);
  // ends
  tok  = gdl_string_next_token (line, n, &i, &j);
  ends = _gdl_expr_get_probe_positions (tok, &size);
  gdl_string_free (tok);

  prb = gdl_expr_probe_alloc (name, strand, starts, ends, size);

  gdl_string_free (name);

  return prb;
}


int
gdl_expr_chromosome_fscanf_annotation (FILE * stream, gdl_expr_chromosome * chrom)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, nprobe = 0;
    int c;
    long offset;
    gdl_string * line=0;

    // first count the number of probes
    offset = ftell (stream);
    while((c=fgetc(stream))!=EOF)
    {
      nprobe += (c=='\n');
    }

    chrom->nprobe = nprobe;
    chrom->probes = GDL_MALLOC (gdl_expr_probe *, nprobe);

    fseek (stream, offset, SEEK_SET);
    k=0;
    while (gdl_getline (&line, &n, stream) != -1)
    {
      chrom->probes[k]      = gdl_expr_probe_parse (line, n);
      gdl_hashtable_add (chrom->_probe_dico, chrom->probes[k]->name, chrom->probes[k], 0);
      chrom->probes[k]->idx = k++;
      GDL_FREE (line);
      line=0;
    }

    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

int
gdl_expr_chromosome_fscanf_annotation2 (FILE * stream, gdl_expr_chromosome * chrom)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, nprobe = 0;
    int c;
    long offset;
    gdl_string * line=0, * tok;

    // first count the number of probes
    offset = ftell (stream);
    while(gdl_getline (&line, &n, stream) != -1)
    {
      i=j=0;
      // first token is the chromosome
      tok = gdl_string_next_token (line, n, &i, &j);
      if (!strcmp(tok, chrom->name))
      {
	(nprobe)++;
      }
      gdl_string_free (tok);
      GDL_FREE (line);
      line=0;
    }
    chrom->nprobe = nprobe;
    chrom->probes = GDL_MALLOC (gdl_expr_probe *, nprobe);
    fseek (stream, offset, SEEK_SET);
    k=0;
    while (gdl_getline (&line, &n, stream) != -1)
    {
      i=j=0;
      // first token is the chromosome
      tok = gdl_string_next_token (line, n, &i, &j);
      if (!strcmp(tok, chrom->name))
      {
	chrom->probes[k]      = gdl_expr_probe_parse (line+j+1, n-j-1);
	gdl_hashtable_add (chrom->_probe_dico, chrom->probes[k]->name, chrom->probes[k], 0);
	chrom->probes[k]->idx = k++;
      }
      gdl_string_free (tok);
      GDL_FREE (line);
      line=0;
    }

    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

int
gdl_expr_chromosome_fscanf_expression (FILE * stream, const size_t pop, gdl_expr_chromosome * chrom, const gdl_string * na_token)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, m;
    gdl_string * name, * tok, * line=0;
    gdl_expr_probe * probe;
    long offset;

    offset=ftell (stream);
    // count the number of indiv using the first line
    gdl_getline (&line, &n, stream);
    for(i=j=m=0;j<n;m++)
    {
      tok = gdl_string_next_token (line, n, &i, &j);
      gdl_string_free (tok);
      if (j == n-1)
      {
	break;
      }
    }
    gdl_string_free (line);line=0;
    m--;

    // set the population size
    chrom->pop_sizes[pop] = m;

    fseek (stream, offset, SEEK_SET);
    while (gdl_getline (&line, &n, stream) != -1)
    {
      for(i=j=k=0;k <= chrom->pop_sizes[pop] && j < n;k++)
      {
	tok = gdl_string_next_token (line, n, &i, &j);
	if (k==0)
	{
	  probe = gdl_hashtable_lookup (chrom->_probe_dico, tok);
	  if (!probe)
	  {
	    gdl_string_free (tok);
	    break;
	  }
	  if (!probe->data)
	  {
	    probe->data = GDL_CALLOC (double *, chrom->npop);
	  }
	  probe->data[pop] = GDL_CALLOC (double, m);
	}
	else if (!strcmp(na_token, tok))
	{
	  probe->data[pop][k-1] = GDL_NAN;
	}
	else
	{
	  probe->data[pop][k-1] = (double)atof(tok);
	}
	gdl_string_free (tok);
      }
      GDL_FREE (line);
      line=0;
    }
    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

int
gdl_expr_chromosome_fscanf_exon_expression (FILE * stream, const size_t pop, gdl_expr_chromosome * chrom, const gdl_string * na_token)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, m;
    gdl_string * name, * tok, * line=0;
    gdl_string * chrom_name, * gene_name, * probe_name;
    gdl_expr_probe * probe;
    unsigned char strand;
    long offset, start, end;

    offset=ftell (stream);
    // count the number of indiv using the first line
    gdl_getline (&line, &n, stream);
    for(i=j=m=0;j<n;m++)
    {
      tok = gdl_string_next_token (line, n, &i, &j);
      gdl_string_free (tok);
      if (j == n-1)
      {
	break;
      }
    }
    gdl_string_free (line);
    line=0;
    // remove the first 5 tokens (chr gene strand start end)
    if (m <= 5)
    {
      GDL_ERROR_VAL ("The exon expression file must contain more than 5 columns (since the 5 first ones provide the unique ID of the exon)", GDL_EINVAL, GDL_EINVAL);
    }
    m -= 5;

    // set the population size
    chrom->pop_sizes[pop] = m;
    fseek (stream, offset, SEEK_SET);
    while (gdl_getline (&line, &n, stream) != -1)
    {
      i=j=0;
      // Get the exon key
      chrom_name = gdl_string_next_token (line, n, &i, &j);
      gene_name  = gdl_string_next_token (line, n, &i, &j);
      tok        = gdl_string_next_token (line, n, &i, &j);
      strand     = tok[0];
      gdl_string_free (tok);
      tok        = gdl_string_next_token (line, n, &i, &j);
      start      = atol(tok);
      gdl_string_free (tok);
      tok        = gdl_string_next_token (line, n, &i, &j);
      end        = atol(tok);
      gdl_string_free (tok);

      probe_name = gdl_string_sprintf("%s_%s_%c_%ld_%ld", chrom_name, gene_name, strand, start, end);

      probe = gdl_hashtable_lookup (chrom->_probe_dico, probe_name);

      if (probe)
      {
	if (!probe->data)
	{
	  probe->data = GDL_CALLOC (double *, chrom->npop);
	}
	probe->data[pop] = GDL_CALLOC (double, m);

	for(k = 0;k <= chrom->pop_sizes[pop] && j < n;k++)
	{
	  tok = gdl_string_next_token (line, n, &i, &j);
	  if (!strcmp(na_token, tok))
	  {
	    probe->data[pop][k] = GDL_NAN;
	  }
	  else
	  {
	    probe->data[pop][k] = (double)atof(tok);
	  }
	  gdl_string_free (tok);
	}
      }
      else
      {
	if (!strcmp(chrom->name, chrom_name))
	{
	  fprintf(stderr, "[ WARNING ] Exon %s not found in the database\n", probe_name);
	  fflush (stderr);
	}
      }
      gdl_string_free (probe_name);
      gdl_string_free (chrom_name);
      gdl_string_free (gene_name);
      gdl_string_free (line);
      line=0;
    }
    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

static long *
_gdl_expr_exon_split (const gdl_string * token, const size_t exonCount)
{
  size_t i,j,n,l;
  long * pos;
  gdl_string * tmp;

  l=strlen(token);
  pos=GDL_MALLOC(long,exonCount);

  for(n=j=i=0;n<exonCount && i<l;i++)
  {
    if (token[i]==',')
    {
      tmp=gdl_string_alloc (i-j);
      strncpy (tmp,&token[j],i-j);
      pos[n]=atol(tmp);
      gdl_string_free (tmp);
      n++;
      j=i+1;
    }
  }
  if (n == exonCount - 1) // configuration without a , at the end
  {
    tmp=gdl_string_alloc (i-j);
    strncpy (tmp,&token[j],i-j);
    pos[n]=atol(tmp);
    gdl_string_free (tmp);
  }

  return pos;
}


/**
 * Gene name
 * Tx name
 * Tx/gene strand
 * Tx start
 * Tx end
 * Tx nexon
 * Tx exonStarts
 * Tx exonEnds
 */
int
gdl_expr_chromosome_fscanf_txtable (FILE * stream, gdl_expr_chromosome * chrom)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, m;
    size_t txStart, txEnd, cdsStart, cdsEnd, nexon, * exonStarts, * exonEnds;
    unsigned char gene_strand;
    long offset;
    gdl_string * gene_name, * tx_name, * tok, * line=0;
    gdl_expr_gene * gene;
    gdl_expr_exon * exon;
    gdl_expr_transcript * transcript;
    gdl_hashtable * buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
    gdl_hashtable * gene_buffer;

    // First get the total number of genes
    // + the number of transcripts per genes
    offset=ftell (stream);
    while (gdl_getline (&line, &n, stream) != -1)
    {
      i=j=0;
      gene_name = gdl_string_next_token (line, n, &i, &j);
      tx_name   = gdl_string_next_token (line, n, &i, &j);
      if ((gene_buffer = gdl_hashtable_lookup (buffer, gene_name)) == 0)
      {
	gene_buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
	gdl_hashtable_add (buffer, gene_name, gene_buffer, 0);
      }
      gdl_hashtable_add (gene_buffer, tx_name, gene_buffer, 0);
      gdl_string_free (gene_name);
      gdl_string_free (tx_name);
    }
    if (gdl_hashtable_size (buffer))
    {
      gdl_hashtable_itr * itr;

      chrom->ngene = gdl_hashtable_size (buffer);
      chrom->genes = GDL_MALLOC (gdl_expr_gene *, chrom->ngene);

      itr = gdl_hashtable_iterator (buffer);
      i   = 0;
      do
      {
	gene_name   = gdl_hashtable_iterator_key (itr);
	gene_buffer = gdl_hashtable_iterator_value (itr);
	chrom->genes[i] = gdl_expr_gene_alloc (gene_name, '?');
	chrom->genes[i]->ntx         = gdl_hashtable_size (gene_buffer);
	chrom->genes[i]->transcripts = GDL_MALLOC (gdl_expr_transcript *, chrom->genes[i]->ntx);
	chrom->genes[i]->ntx = 0;
	gdl_hashtable_add (chrom->_gene_dico, gene_name, chrom->genes[i], 0);
	gdl_hashtable_free (gene_buffer);
	i++;
      }
      while (gdl_hashtable_iterator_next (itr));
      gdl_hashtable_iterator_free (itr);
      gdl_hashtable_free (buffer);

      fseek (stream, offset, SEEK_SET);
      while (gdl_getline (&line, &n, stream) != -1)
      {
	i=j=0;
	tok = gdl_string_next_token (line, n, &i, &j);
	gene = gdl_hashtable_lookup (chrom->_gene_dico, tok);
	gdl_string_free (tok);
	// tx_name
	tx_name = gdl_string_next_token (line, n, &i, &j);
	// strand
	tok = gdl_string_next_token (line, n, &i, &j);
	if (gene->strand == '?')
	{
	  gene->strand = (unsigned char) tok[0];
	}
	else if (gene->strand != (unsigned char) tok[0])
	{
	  GDL_ERROR_VAL (gdl_string_sprintf ("Transcript %s for gene %s is provided with a different strand\n", tx_name, gene->name), GDL_EINVAL, GDL_EINVAL);
	}
	gdl_string_free (tok);
	// txStart
	tok = gdl_string_next_token (line, n, &i, &j);
	txStart = atol(tok);
	gdl_string_free (tok);
	// txEnd
	tok = gdl_string_next_token (line, n, &i, &j);
	txEnd = atol(tok);
	gdl_string_free (tok);
	// cdsStart
	tok = gdl_string_next_token (line, n, &i, &j);
	cdsStart = atol(tok);
	gdl_string_free (tok);
	// cdsEnd
	tok = gdl_string_next_token (line, n, &i, &j);
	cdsEnd = atol(tok);
	gdl_string_free (tok);
	// exonCount
	tok = gdl_string_next_token (line, n, &i, &j);
	nexon = atoi(tok);
	gdl_string_free (tok);

	transcript = gdl_expr_transcript_alloc (tx_name, nexon);
	gene->transcripts[gene->ntx] = transcript;
	gdl_string_free (tx_name);

	transcript->txStart  = txStart;
	transcript->txEnd    = txEnd;
	transcript->cdsStart = cdsStart;
	transcript->cdsEnd   = cdsEnd;

	// exonStarts
	tok = gdl_string_next_token (line, n, &i, &j);
	exonStarts = _gdl_expr_exon_split (tok, nexon);
	gdl_string_free (tok);
	// exonEnds
	tok = gdl_string_next_token (line, n, &i, &j);
	exonEnds = _gdl_expr_exon_split (tok, nexon);
	gdl_string_free (tok);

	transcript->exon_idx = gdl_expr_gene_add_exons (gene, gene->ntx, exonStarts, exonEnds, nexon);

	// Increment the transcript index
	(gene->ntx)++;

	GDL_FREE (exonStarts);
	GDL_FREE (exonEnds);
	GDL_FREE (line);
	line=0;
      }
      // set the boundaries of all the genes
      // sort the genes using the txStartMin coordinates
      size_t * tmp = GDL_MALLOC (size_t, chrom->ngene);
      size_t * idx = GDL_MALLOC (size_t, chrom->ngene);
      gdl_expr_gene ** gtmp = GDL_MALLOC (gdl_expr_gene *, chrom->ngene);
      for(i = 0; i < chrom->ngene; i++)
      {
	gdl_expr_gene_set_boundaries (chrom->genes[i]);
	tmp[i]  = chrom->genes[i]->txStartMin;
	gtmp[i] = chrom->genes[i];
      }
      gdl_sort_ulong_index (idx, tmp, 1, chrom->ngene);
      for(i = 0; i < chrom->ngene; i++)
      {
	chrom->genes[i] = gtmp[idx[i]];
      }
      GDL_FREE (gtmp);
      GDL_FREE (tmp);
      GDL_FREE (idx);
    }


    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

/**
 * ignore
 * Tx name
 * Tx chromosome
 * Tx/strand
 * Tx start
 * Tx end
 * Tx cds  start
 * Tx cds  end
 * Tx nexon
 * Tx exonStarts
 * Tx exonEnds
 * ignore
 * Tx gene
 */
int
gdl_expr_chromosome_fscanf_txtable2 (FILE * stream, gdl_expr_chromosome * chrom)
{
  if (stream && chrom)
  {
    size_t i, j, k, n, m;
    size_t txStart, txEnd, cdsStart, cdsEnd, nexon, * exonStarts, * exonEnds;
    unsigned char gene_strand;
    long offset;
    gdl_string * gene_name, * tx_name, * tok, * line=0;
    gdl_expr_gene * gene;
    gdl_expr_exon * exon;
    gdl_expr_transcript * transcript;
    gdl_hashtable * buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
    gdl_hashtable * gene_buffer;

    // First get the total number of genes
    // + the number of transcripts per genes
    offset=ftell (stream);
    while (gdl_getline (&line, &n, stream) != -1)
    {
      i=j=0;
      // skip first column
      tok = gdl_string_next_token (line, n, &i, &j);
      gdl_string_free (tok);
      // tx name
      tx_name = gdl_string_next_token (line, n, &i, &j);
      // chrom name
      tok = gdl_string_next_token (line, n, &i, &j);
      if (!strcmp(tok, chrom->name))
      {
	gdl_string_free (tok);
	// skip the next columns
	for(k = 0; k < 9; k++)
	{
	  tok = gdl_string_next_token (line, n, &i, &j);
	  gdl_string_free (tok);
	}
	gene_name = gdl_string_next_token (line, n, &i, &j);
	if ((gene_buffer = gdl_hashtable_lookup (buffer, gene_name)) == 0)
	{
	  gene_buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
	  gdl_hashtable_add (buffer, gene_name, gene_buffer, 0);
	}
	gdl_hashtable_add (gene_buffer, tx_name, gene_buffer, 0);
	gdl_string_free (gene_name);
      }
      else
      {
	gdl_string_free (tok);
      }
      gdl_string_free (tx_name);
    }
    if (gdl_hashtable_size (buffer))
    {
      gdl_hashtable_itr * itr;

      chrom->ngene = gdl_hashtable_size (buffer);
      chrom->genes = GDL_MALLOC (gdl_expr_gene *, chrom->ngene);

      itr = gdl_hashtable_iterator (buffer);
      i   = 0;
      do
      {
	gene_name   = gdl_hashtable_iterator_key (itr);
	gene_buffer = gdl_hashtable_iterator_value (itr);
	chrom->genes[i] = gdl_expr_gene_alloc (gene_name, '?');
	chrom->genes[i]->ntx         = gdl_hashtable_size (gene_buffer);
	chrom->genes[i]->transcripts = GDL_MALLOC (gdl_expr_transcript *, chrom->genes[i]->ntx);
	chrom->genes[i]->ntx = 0;
	gdl_hashtable_add (chrom->_gene_dico, gene_name, chrom->genes[i], 0);
	gdl_hashtable_free (gene_buffer);
	i++;
      }
      while (gdl_hashtable_iterator_next (itr));
      gdl_hashtable_iterator_free (itr);
      gdl_hashtable_free (buffer);

      fseek (stream, offset, SEEK_SET);
      while (gdl_getline (&line, &n, stream) != -1)
      {
	i=j=0;
	// skip first column
	tok = gdl_string_next_token (line, n, &i, &j);
	gdl_string_free (tok);
	// tx_name
	tx_name = gdl_string_next_token (line, n, &i, &j);
	// chrom name
	tok = gdl_string_next_token (line, n, &i, &j);
	if (!strcmp(tok, chrom->name))
	{
	  gdl_string_free (tok);
	  // skip the next columns
	  for(k = 0; k < 9; k++)
	  {
	    tok = gdl_string_next_token (line, n, &i, &j);
	    gdl_string_free (tok);
	  }
	  tok = gdl_string_next_token (line, n, &i, &j);
	  gene = gdl_hashtable_lookup (chrom->_gene_dico, tok);
	  gdl_string_free (tok);
	  // come back to the beginning of the column
	  // (but skip the three first columns)
	  i=j=0;
	  for(k = 0; k < 3; k++)
	  {
	    tok = gdl_string_next_token (line, n, &i, &j);
	    gdl_string_free (tok);
	  }
	  // strand
	  tok = gdl_string_next_token (line, n, &i, &j);
	  gene->strand = tok[0];
	  if (gene->strand == '?')
	  {
	    gene->strand = (unsigned char) tok[0];
	  }
	  else if (gene->strand != (unsigned char) tok[0])
	  {
	    GDL_ERROR_VAL (gdl_string_sprintf ("Transcript %s for gene %s is provided with a different strand\n", tx_name, gene->name), GDL_EINVAL, GDL_EINVAL);
	  }
	  gdl_string_free (tok);
	  // txStart
	  tok = gdl_string_next_token (line, n, &i, &j);
	  txStart = atol(tok);
	  gdl_string_free (tok);
	  // txEnd
	  tok = gdl_string_next_token (line, n, &i, &j);
	  txEnd = atol(tok);
	  gdl_string_free (tok);
	  // cdsStart
	  tok = gdl_string_next_token (line, n, &i, &j);
	  cdsStart = atol(tok);
	  gdl_string_free (tok);
	  // cdsEnd
	  tok = gdl_string_next_token (line, n, &i, &j);
	  cdsEnd = atol(tok);
	  gdl_string_free (tok);
	  // exonCount
	  tok = gdl_string_next_token (line, n, &i, &j);
	  nexon = atoi(tok);
	  gdl_string_free (tok);

	  transcript = gdl_expr_transcript_alloc (tx_name, nexon);
	  gene->transcripts[gene->ntx] = transcript;

	  transcript->txStart  = txStart;
	  transcript->txEnd    = txEnd;
	  transcript->cdsStart = cdsStart;
	  transcript->cdsEnd   = cdsEnd;

	  // exonStarts
	  tok = gdl_string_next_token (line, n, &i, &j);
	  exonStarts = _gdl_expr_exon_split (tok, nexon);
	  gdl_string_free (tok);
	  // exonEnds
	  tok = gdl_string_next_token (line, n, &i, &j);
	  exonEnds = _gdl_expr_exon_split (tok, nexon);
	  gdl_string_free (tok);

	  transcript->exon_idx = gdl_expr_gene_add_exons (gene, gene->ntx, exonStarts, exonEnds, nexon);

	  // Increment the transcript index
	  (gene->ntx)++;

	  GDL_FREE (exonStarts);
	  GDL_FREE (exonEnds);
	}
	else
	{
	  gdl_string_free (tok);
	}
	gdl_string_free (tx_name);
	GDL_FREE (line);
	line=0;
      }
      // set the boundaries of all the genes
      // sort the genes using the txStartMin coordinates
      size_t * tmp = GDL_MALLOC (size_t, chrom->ngene);
      size_t * idx = GDL_MALLOC (size_t, chrom->ngene);
      gdl_expr_gene ** gtmp = GDL_MALLOC (gdl_expr_gene *, chrom->ngene);
      for(i = 0; i < chrom->ngene; i++)
      {
	gdl_expr_gene_set_boundaries (chrom->genes[i]);
	tmp[i]  = chrom->genes[i]->txStartMin;
	gtmp[i] = chrom->genes[i];
      }
      gdl_sort_ulong_index (idx, tmp, 1, chrom->ngene);
      for(i = 0; i < chrom->ngene; i++)
      {
	chrom->genes[i] = gtmp[idx[i]];
      }
      GDL_FREE (gtmp);
      GDL_FREE (tmp);
      GDL_FREE (idx);
    }
    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

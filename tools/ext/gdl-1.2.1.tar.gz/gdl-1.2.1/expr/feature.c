/*
 *  expr/feature.c
 *
 *  $Author: tflutre $, $Date: 2011/10/09 22:17:15 $, $Revision: 1.3 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include "sys/stat.h"
#include "dirent.h"

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_util.h>
#include <gdl/gdl_sort_long.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

gdl_expr_feature *
gdl_expr_feature_alloc (const gdl_expr_feature_type * T, const size_t * idx)
{
  gdl_expr_feature * f = GDL_CALLOC (gdl_expr_feature, 1);

  f->T = T;

  f->idx = GDL_CALLOC (size_t, T->nidx);

  memcpy (f->idx, idx, sizeof(size_t)*T->nidx);

  return f;
}

void
gdl_expr_feature_free (gdl_expr_feature * f, const gdl_expr_chromosome * c)
{
  if (f)
  {
    size_t i;
    GDL_FREE (f->idx);
    if (f->data)// && f->T != gdl_expr_feature_probe)
    {
      for(i = 0; i < c->npop; i++)
      {
	GDL_FREE (f->data[i]);
      }
      GDL_FREE (f->data);
    }
    gdl_string_free (f->name);
    GDL_FREE (f->probe_idx);
    GDL_FREE (f->probe_starts);
    GDL_FREE (f->probe_ends);
    GDL_FREE (f);
  }
}

gdl_expr_feature *
gdl_expr_feature_fread (FILE * stream, const gdl_expr_feature_type * T, const gdl_expr_chromosome * c)
{
  if (stream)
  {
    int status;
    size_t * idx = GDL_MALLOC (size_t, T->nidx);
    gdl_expr_feature * f;

    status = fread (idx, sizeof(size_t), T->nidx, stream);
    GDL_FREAD_STATUS (status, T->nidx, NULL);

    f = gdl_expr_feature_alloc (T, idx);

    if (c)
    {
      size_t i;

      f->data = GDL_MALLOC (double *, c->npop);
      for(i = 0; i < c->npop; i++)
      {
	f->data[i] = GDL_MALLOC (double, c->pop_sizes[i]);
	status = fread(f->data[i], sizeof(double), c->pop_sizes[i], stream);
	GDL_FREAD_STATUS (status, c->pop_sizes[i], NULL);
      }
    }

    f->name = gdl_string_fread (stream);
    GDL_FREAD_STATUS (f->name != 0, 1, NULL);

    status = fread (&(f->nprobe), sizeof(size_t), 1, stream);
    GDL_FREAD_STATUS (status, 1, NULL);

    if (f->nprobe)
    {
      f->probe_idx = GDL_MALLOC (size_t, f->nprobe);
      status = fread (f->probe_idx, sizeof(size_t), f->nprobe, stream);
      GDL_FREAD_STATUS (status, f->nprobe, NULL);
      status = fread (&(f->nprobe_pos), sizeof(size_t), 1, stream);
      GDL_FREAD_STATUS (status, 1, NULL);
      f->probe_starts = GDL_MALLOC (size_t, f->nprobe_pos);
      f->probe_ends   = GDL_MALLOC (size_t, f->nprobe_pos);
      status = fread (f->probe_starts, sizeof(size_t), f->nprobe_pos, stream);
      GDL_FREAD_STATUS (status, f->nprobe_pos, NULL);
      status = fread (f->probe_ends, sizeof(size_t), f->nprobe_pos, stream);
      GDL_FREAD_STATUS (status, f->nprobe_pos, NULL);
    }

    GDL_FREE (idx);

    return f;
  }

  return 0;
}

int
gdl_expr_feature_fwrite (FILE * stream, const gdl_expr_feature * f, const gdl_expr_feature_type * T, const gdl_expr_chromosome * c)
{
  if (stream && f)
  {
    int status;
    size_t i;

    status = fwrite (f->idx, sizeof(size_t), T->nidx, stream);
    GDL_FWRITE_STATUS (status, T->nidx, 1);

    if (c)
    {
      for(i = 0; i < c->npop; i++)
      {
	status = fwrite(f->data[i], sizeof(double), c->pop_sizes[i], stream);
	GDL_FWRITE_STATUS (status, c->pop_sizes[i], 1);
      }
    }

    status = gdl_string_fwrite (stream, f->name);
    GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);

    status = fwrite (&(f->nprobe), sizeof(size_t), 1, stream);
    GDL_FWRITE_STATUS (status, 1, 1);

    if (f->nprobe)
    {
      status = fwrite (f->probe_idx, sizeof(size_t), f->nprobe, stream);
      GDL_FWRITE_STATUS (status, f->nprobe, 1);
      status = fwrite (&(f->nprobe_pos), sizeof(size_t), 1, stream);
      GDL_FWRITE_STATUS (status, 1, 1);
      status = fwrite (f->probe_starts, sizeof(size_t), f->nprobe_pos, stream);
      GDL_FWRITE_STATUS (status, f->nprobe_pos, 1);
      status = fwrite (f->probe_ends, sizeof(size_t), f->nprobe_pos, stream);
      GDL_FWRITE_STATUS (status, f->nprobe_pos, 1);
    }

    return GDL_SUCCESS;
  }

  return GDL_EINVAL;
}

void
gdl_expr_feature_set_probe_positions (const gdl_expr_chromosome * c, gdl_expr_feature * f)
{
  if (!f->nprobe)
  {
    return;
  }

  size_t i, j, k;

  for(i = k = 0; i < f->nprobe; i++)
  {
    k += c->probes[f->probe_idx[i]]->npos;
  }

  f->nprobe_pos = k;

  long * s = GDL_MALLOC (long, f->nprobe_pos);
  long * e = GDL_MALLOC (long, f->nprobe_pos);

  for(i = k = 0; i < f->nprobe; i++)
  {
    for(j = 0; j < c->probes[f->probe_idx[i]]->npos; j++)
    {
      s[k] = c->probes[f->probe_idx[i]]->starts[j];
      e[k++] = c->probes[f->probe_idx[i]]->ends[j];
    }
  }

  f->probe_starts = s;
  f->probe_ends   = e;
}

gdl_boolean
gdl_expr_feature_is_within_probe (const gdl_expr_feature * f, const long position)
{
  size_t i;

  for(i = 0; i < f->nprobe_pos; i++)
  {
    if (position >= f->probe_starts[i] && position <= f->probe_ends[i])
    {
      return gdl_true;
    }
  }

  return gdl_false;
}

long
gdl_expr_feature_get_min_start (const gdl_expr_feature * f, const gdl_expr_chromosome * c)
{
  size_t n;
  const long * starts = (f->T->get_starts)(c, f->idx, &n);
  return starts[0];
}

long
gdl_expr_feature_get_max_end (const gdl_expr_feature * f, const gdl_expr_chromosome * c)
{
  size_t n;
  const long * starts = (f->T->get_ends)(c, f->idx, &n);
  return starts[n-1];
}

/*=============================================================================================
 *
 * CHROMOSOME
 *
 * ============================================================================================*/

gdl_expr_feature_chromosome *
gdl_expr_feature_chromosome_alloc (const gdl_expr_feature_type * T, const gdl_expr_chromosome * e_chrom, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
  gdl_expr_feature_chromosome * c;

  c = GDL_CALLOC (gdl_expr_feature_chromosome, 1);

  c->T = T;

  c->name = gdl_string_clone (e_chrom->name);

  (T->chrom_alloc)(c, e_chrom, p, progress, logger);

  //===================================================
  // order features by increasing starting position
  //===================================================
  size_t i;
  long   * start_features             = GDL_MALLOC (long, c->nfeature);
  size_t * idx_features               = GDL_MALLOC (size_t, c->nfeature);
  gdl_expr_feature ** sorted_features = GDL_MALLOC (gdl_expr_feature *, c->nfeature);
  for(i = 0; i < c->nfeature; i++)
  {
    start_features[i] = gdl_expr_feature_get_min_start (c->features[i], e_chrom);
  }
  gdl_sort_long_index (idx_features, start_features, 1, c->nfeature);
  for(i = 0; i < c->nfeature; i++)
  {
    sorted_features[i] = c->features[idx_features[i]];
  }
  GDL_FREE (start_features);
  GDL_FREE (idx_features);
  GDL_FREE (c->features);

  c->features = sorted_features;

  return c;
}

void
gdl_expr_feature_chromosome_free (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c)
{
  if (c)
  {
    size_t i;
    gdl_string_free (f->name);
    for(i = 0; i < f->nfeature; i++)
    {
      gdl_expr_feature_free (f->features[i], c);
    }
    GDL_FREE (f->features);
    GDL_FREE (f);
  }
}

gdl_expr_feature_chromosome *
gdl_expr_feature_chromosome_fread (FILE * stream, const gdl_expr_chromosome * e)
{
  gdl_expr_feature_chromosome * c = NULL;
  
  if (stream)
  {
    int status;
    gdl_string * type;

    c = GDL_CALLOC (gdl_expr_feature_chromosome, 1);

    type = gdl_string_fread (stream);
    GDL_FREAD_STATUS (type != 0, 1, NULL);

    c->T = gdl_expr_feature_type_lookup (type, "name");

    c->name = gdl_string_fread (stream);
    GDL_FREAD_STATUS (c->name != 0, 1, NULL);

    status = fread (&(c->nfeature), sizeof(size_t), 1, stream);
    GDL_FREAD_STATUS (status, 1, NULL);

    if (c->nfeature)
    {
      size_t i;

      c->features = GDL_MALLOC (gdl_expr_feature *, c->nfeature);
      for(i = 0; i < c->nfeature; i++)
      {
	c->features[i] = gdl_expr_feature_fread (stream, c->T, e);
	GDL_FREAD_STATUS (c->features[i] != 0, 1, NULL);
	c->features[i]->T = c->T;
      }
    }
    
    gdl_string_free (type);
  }

  return c;
}

int
gdl_expr_feature_chromosome_fwrite (FILE * stream, const gdl_expr_feature_chromosome * c, const gdl_expr_chromosome * e)
{
  if (stream && c)
  {
    int status;

    status = gdl_string_fwrite (stream, c->T->name);
    GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);

    status = gdl_string_fwrite (stream, c->name);
    GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);

    status = fwrite (&(c->nfeature), sizeof(size_t), 1, stream);
    GDL_FWRITE_STATUS (status, 1, 1);

    if (c->nfeature)
    {
      size_t i;

      for(i = 0; i < c->nfeature; i++)
      {
	status = gdl_expr_feature_fwrite (stream, c->features[i], c->T, e);
	GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
      }
    }

    return GDL_SUCCESS;
  }

  return GDL_EINVAL;
}

/*=============================================================================================
 *
 * PARAMETERS
 *
 * ============================================================================================*/

gdl_expr_feature_parameter *
gdl_expr_feature_parameter_alloc (const gdl_string * feature_type)
{
  gdl_expr_feature_parameter * p;

  p = GDL_CALLOC (gdl_expr_feature_parameter, 1);

  p->feature_type = gdl_string_clone (feature_type);

  p->values = gdl_hashtable_alloc (gdl_hash_default, 0);

  return p;
}

void
gdl_expr_feature_parameter_free (gdl_expr_feature_parameter * p)
{
  if (p)
  {
    gdl_string_free (p->feature_type);
    gdl_hashtable_free (p->values);
    GDL_FREE (p);
  }
}

/*=============================================================================================
 *
 * GENOME
 *
 * ============================================================================================*/

static gdl_string *
gdl_expr_feature_genome_chromfile (const gdl_expr_feature_genome * g, size_t i)
{
  return gdl_string_sprintf ("%s/%s.fdb", g->dbdir, g->chroms[i], g->T->acronym);
}

gdl_expr_feature_genome *
gdl_expr_feature_genome_alloc (const gdl_expr_genome * expr_data,
                               const gdl_expr_feature_parameter * p,
                               const gdl_string * dbdir,
                               FILE * progress, FILE * logger)
{
  size_t c;
  gdl_string * file;
  FILE * stream;
  gdl_expr_feature_genome * g;

  g = GDL_MALLOC (gdl_expr_feature_genome, 1);

  g->T = gdl_expr_feature_type_lookup (p->feature_type, "acronym");
  if (!g->T)
  {
    GDL_ERROR_VAL (gdl_string_sprintf ("Unknown Feature Type %s", p->feature_type), 0, 0);
  }
  g->dbdir  = gdl_string_clone (dbdir);
  g->nchrom = expr_data->nchrom;
  g->chroms = GDL_MALLOC (gdl_string *, g->nchrom);

  for(c = 0; c < expr_data->nchrom; c++)
  {
    gdl_expr_feature_chromosome * f_chrom;
    gdl_expr_chromosome * e_chrom = gdl_expr_genome_get (expr_data, c);

    if (progress)
    {
      fprintf (progress, ">>Create feature chromosome: wait...", file);
      fflush (progress);
    }

    f_chrom = gdl_expr_feature_chromosome_alloc (g->T, e_chrom, p, progress, logger);

    if (progress)
    {
      fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
      fflush (progress);
    }

    g->chroms[c] = gdl_string_clone (e_chrom->name);
    file = gdl_expr_feature_genome_chromfile (g, c);

    if (progress)
    {
      fprintf (progress, ">>Save chromosome data to %s: wait...", file);
      fflush (progress);
    }

    stream = gdl_fileopen (file, "w");
    gdl_expr_feature_chromosome_fwrite (stream, f_chrom, e_chrom);
    gdl_fileclose (file, stream);
    gdl_string_free (file);

    if (progress)
    {
      fprintf (progress, "\b\b\b\b\b\b\b[ OK ]\n");
      fflush (progress);
    }

    gdl_expr_chromosome_free (e_chrom);
  }

  return g;
}

void
gdl_expr_feature_genome_free (gdl_expr_feature_genome * v)
{
  if (v)
  {
    size_t i;
    for (i = 0; i < v->nchrom; i++)
    {
      gdl_string_free (v->chroms[i]);
    }
    GDL_FREE (v->chroms);
    gdl_string_free (v->dbdir);
    GDL_FREE (v);
  }
}

void
gdl_expr_feature_genome_rm (gdl_expr_feature_genome * v)
{
  size_t i;

  for (i = 0; i < v->nchrom; i++)
  {
    gdl_string * file = gdl_expr_feature_genome_chromfile (v, i);
    remove (file);
    gdl_string_free (file);
  }
}

gdl_expr_feature_chromosome *
gdl_expr_feature_genome_get (const gdl_expr_feature_genome * g, size_t i, const gdl_expr_chromosome * c)
{
  gdl_string * file;
  FILE * stream;
  gdl_expr_feature_chromosome * f;

  file = gdl_expr_feature_genome_chromfile (g, i);

  stream = gdl_fileopen (file, "r");

  f = gdl_expr_feature_chromosome_fread (stream, c);

  gdl_fileclose (file, stream);

  gdl_string_free (file);

  return f;
}

int
gdl_expr_feature_genome_set (const gdl_expr_feature_genome * g, size_t i, gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c)
{
  int status;
  gdl_string * file;
  FILE * stream;

  file = gdl_expr_feature_genome_chromfile (g, i);

  stream = gdl_fileopen (file, "w");

  status = gdl_expr_feature_chromosome_fwrite (stream, f, c);

  gdl_fileclose (file, stream);

  gdl_string_free (file);

  return status;
}

gdl_expr_feature_genome *
gdl_expr_feature_genome_fread (FILE * stream)
{
  if (stream)
  {
    int status;
    size_t i;
    gdl_string * type;
    gdl_expr_feature_genome * v;

    v = GDL_MALLOC (gdl_expr_feature_genome, 1);

    type = gdl_string_fread (stream);
    GDL_FREAD_STATUS (type!=0, 1, NULL);

    v->T = gdl_expr_feature_type_lookup (type, "name");

    gdl_string_free (type);

    v->dbdir = gdl_string_fread (stream);
    GDL_FREAD_STATUS (v->dbdir!=0, 1, NULL);
    status = fread (&v->nchrom, sizeof(size_t), 1, stream);
    GDL_FREAD_STATUS (status, 1, NULL);
    v->chroms = GDL_MALLOC (gdl_string *, v->nchrom);
    for (i = 0; i < v->nchrom; i++)
    {
      v->chroms[i] = gdl_string_fread (stream);
      GDL_FREAD_STATUS (v->chroms[i]!=0, 1, NULL);
    }


    return v;
  }
  return 0;
}

int
gdl_expr_feature_genome_fwrite (FILE * stream, const gdl_expr_feature_genome * v)
{
  if (stream && v)
  {
    int status;
    size_t i;

    status = gdl_string_fwrite (stream, v->T->name);
    GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
    status = gdl_string_fwrite (stream, v->dbdir);
    GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
    status = fwrite (&v->nchrom, sizeof(size_t), 1, stream);
    GDL_FWRITE_STATUS (status, 1, 1);
    for (i = 0; i < v->nchrom; i++)
    {
      status = gdl_string_fwrite (stream, v->chroms[i]);
      GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
    }

    return GDL_SUCCESS;
  }
  return GDL_EINVAL;
}

const gdl_expr_feature_type *
gdl_expr_feature_type_lookup (const gdl_string * tok, const gdl_string * which)
{
  if (!strcmp(which, "name"))
  {
    if (!strcmp(tok, gdl_expr_feature_probe->name))
    {
      return gdl_expr_feature_probe;
    }
    if (!strcmp(tok, gdl_expr_feature_exon->name))
    {
      return gdl_expr_feature_exon;
    }
    if (!strcmp(tok, gdl_expr_feature_transcript->name))
    {
      return gdl_expr_feature_transcript;
    }
    if (!strcmp(tok, gdl_expr_feature_gene->name))
    {
      return gdl_expr_feature_gene;
    }
    if (!strcmp(tok, gdl_expr_feature_metaexon->name))
    {
      return gdl_expr_feature_metaexon;
    }
  }
  else if (!strcmp(which, "acronym"))
  {
    if (!strcmp(tok, gdl_expr_feature_probe->acronym))
    {
      return gdl_expr_feature_probe;
    }
    if (!strcmp(tok, gdl_expr_feature_exon->acronym))
    {
      return gdl_expr_feature_exon;
    }
    if (!strcmp(tok, gdl_expr_feature_transcript->acronym))
    {
      return gdl_expr_feature_transcript;
    }
    if (!strcmp(tok, gdl_expr_feature_gene->acronym))
    {
      return gdl_expr_feature_gene;
    }
    if (!strcmp(tok, gdl_expr_feature_metaexon->acronym))
    {
      return gdl_expr_feature_metaexon;
    }
  }

  return 0;
}

void
gdl_expr_feature_create_name (const gdl_expr_chromosome * c, gdl_expr_feature * feature, const gdl_string * prefix)
{
  size_t i,l = 0;
  gdl_string * tmp;

  gdl_string_free (feature->name);

  if (prefix)
  {
    l = strlen(prefix);
  }

  for(i = 0; i < feature->nprobe; i++)
  {
    l += strlen(c->probes[feature->probe_idx[i]]->name);
  }

  feature->name = tmp = gdl_string_alloc (l + feature->nprobe);

  if (prefix)
  {
    l = strlen(prefix);
    strncpy(feature->name, prefix, l);
  }
  feature->name += l;
  *(feature->name) = '|';
  feature->name += 1;
  for(i = 0; i < feature->nprobe; i++)
  {
    l = strlen(c->probes[feature->probe_idx[i]]->name);
    strncpy(feature->name, c->probes[feature->probe_idx[i]]->name, l);
    if (i < feature->nprobe - 1)
    {
      feature->name += l;
      *(feature->name) = '|';
      feature->name += 1;
    }
  }

  feature->name = tmp;
}

gdl_expr_feature_genome *
gdl_expr_feature_genome_subset (gdl_expr_genome * expr_data, gdl_expr_feature_genome * g, gdl_string ** sample_names, gdl_string ** sub_sample_names, const size_t nsub_sample, const gdl_string * output)
{
  size_t c, i, j, k;
  gdl_sub_sample_mapping_t * m;
  gdl_expr_feature_genome * sub_g;
  DIR * dir;

  // Create the new genome
  sub_g = GDL_CALLOC (gdl_expr_feature_genome, 1);
  sub_g->T = g->T;
  sub_g->nchrom = g->nchrom;
  sub_g->dbdir  = gdl_string_clone (output);
  sub_g->chroms = GDL_MALLOC (gdl_string *, g->nchrom);
  for(c = 0; c < g->nchrom; c++)
  {
    sub_g->chroms[c] = gdl_string_clone (g->chroms[c]);
  }
  // First, make sure that the directory exists
  if ((dir=opendir(output))==0)
  {
    mkdir (output, S_IRWXU);
  }
  // Update the chromosomes
  for(c = 0; c < g->nchrom; c++)
  {
    gdl_expr_chromosome * expr_chrom = gdl_expr_genome_get (expr_data, c);
    gdl_expr_feature_chromosome * chrom = gdl_expr_feature_genome_get (g, c, expr_chrom);
    if (!c)
    {
      m = gdl_sub_sample_mapping_by_pop (sample_names, expr_chrom->pop_sizes, expr_chrom->npop, sub_sample_names, nsub_sample);
    }
    // Update probe->data
    for(i = 0; i < chrom->nfeature; i++)
    {
      double ** sub_data = GDL_MALLOC (double *, m->npop);
      gdl_expr_feature * feature = chrom->features[i];
      for(j = 0; j < m->npop; j++)
      {
	sub_data[j] = GDL_MALLOC (double, m->pop_sizes[j]);
	for(k = 0; k < m->pop_sizes[j]; k++)
	{
	  sub_data[j][k] = feature->data[m->popx[j][k]][m->pidx[j][k]];
	}
      }
      GDL_MATRIX_FREE (feature->data, expr_chrom->npop);
      feature->data = sub_data;
    }
    // Update expr_chrom->sample
    for(i = 0; i < m->npop; expr_chrom->nsample += m->pop_sizes[i], i++);
    // Update expr_chrom->npop;
    expr_chrom->npop = m->npop;
    // Update expr_chrom->pop_sizes
    memcpy(expr_chrom->pop_sizes, m->pop_sizes, sizeof(size_t)*m->npop);
    gdl_expr_feature_genome_set (sub_g, c, chrom, expr_chrom);
    // Clean it
    gdl_expr_feature_chromosome_free (chrom, expr_chrom);
    gdl_expr_chromosome_free (expr_chrom);
  }

  gdl_sub_sample_mapping_t_free (m);

  return sub_g;
}

int
gdl_expr_feature_genome_fprintf (const gdl_expr_genome * g, const gdl_expr_feature_genome * gf, gdl_string ** pop_names, const gdl_string * output)
{
  size_t c, p;
  gdl_string * file;
  DIR * dir;

  for(c = 0; c < g->nchrom; c++)
  {
    gdl_expr_chromosome         * chrom   = gdl_expr_genome_get (g, c);
    gdl_expr_feature_chromosome * f_chrom = gdl_expr_feature_genome_get (gf, c, chrom);
    if (!c)
    {
      // First, make sure that the directory exists
      if ((dir=opendir(output))==0)
      {
	mkdir (output, S_IRWXU);
      }
      for(p = 0; p < chrom->npop; p++)
      {
	if (pop_names)
	{
	  file = gdl_string_sprintf ("%s/%s", output, pop_names[p]);
	}
	else
	{
	  file = gdl_string_sprintf ("%s/Pop_%d", output, p+1);
	}
	if ((dir=opendir(file))==0)
	{
	  mkdir (file, S_IRWXU);
	}
	gdl_string_free (file);
      }
    }
    gdl_expr_feature_chromosome_fprintf (chrom, f_chrom, pop_names, output);
    gdl_expr_feature_chromosome_free (f_chrom, chrom);
    gdl_expr_chromosome_free (chrom);
  }
}

int
gdl_expr_feature_chromosome_fprintf (const gdl_expr_chromosome * c, const gdl_expr_feature_chromosome * f_c, gdl_string ** pop_names, const gdl_string * output)
{
  size_t i,j,k;
  gdl_string * file;
  FILE * stream;

  // Expression Measurement
  for(i = 0; i < c->npop; i++)
  {
    if (pop_names)
    {
      file   = gdl_string_sprintf ("%s/%s/%s.%s", output, pop_names[i], c->name, f_c->T->acronym);
    }
    else
    {
      file   = gdl_string_sprintf ("%s/Pop_%d/%s.%s", output, i+1, c->name, f_c->T->acronym);
    }
    stream = gdl_fileopen (file, "w");
    for(j = 0; j < f_c->nfeature; j++)
    {
      gdl_expr_feature * feature = f_c->features[j];
      if (feature->data)
      {
	fprintf (stream, "%s", feature->name);
	for(k = 0; k < c->pop_sizes[i]; k++)
	{
	  if (!gdl_isnan (feature->data[i][k]))
	  {
	    fprintf (stream, " %g", feature->data[i][k]);
	  }
	  else
	  {
	    fprintf (stream, " NA");
	  }
	}
	fprintf (stream, "\n");
	fflush (stream);
      }
    }
    gdl_fileclose (file, stream);
    gdl_string_free (file);
  }
}

double *
gdl_expr_feature_get_unit_weights (const gdl_expr_chromosome * c, const gdl_expr_feature * f, const gdl_expr_transcript_weights * tx_weights)
{
  size_t i, nu;
  double * w = 0, wt = 0;

  nu = (f->T->get_unit_size)(c, f->idx);

  w  = GDL_CALLOC (double, nu);

  if (tx_weights)
  {
    for(i = 0; i < nu; i++)
    {
      gdl_expr_feature_entities * fentities = (f->T->get_unit_entities)(c, f->idx, i);
      double z = gdl_expr_transcript_weights_get (tx_weights, c->name, fentities->gene->name, fentities->transcript->name);
      if (!gdl_isnan(z))
      {
	w[i] = z;
	wt  += z;
      }
      else if (tx_weights->_logger)
      {
	fprintf (tx_weights->_logger, "[ WARNING ] No weight found in the table for gene %s transcript %s", fentities->gene->name, fentities->transcript->name);
	fflush (tx_weights->_logger);
      }
      GDL_FREE (fentities);
    }
    if (wt > 0.)
    {
      for(i = 0; i < nu; i++)
      {
	w[i] /= wt;
      }
    }
    else
    {
      if (tx_weights->_logger)
      {
	fprintf (tx_weights->_logger, "[ WARNING ] No weights found in the table for feature %s: ASSUME SAME WEIGHTS FOR ALL TRANSCRIPTS", f->name);
	fflush (tx_weights->_logger);
      }
      for(i = 0; i < nu; i++)
      {
	w[i] = 1.0/nu;
      }
    }
  }
  else
  {
    for(i = 0; i < nu; i++)
    {
      w[i] = 1.0/nu;
    }
  }

  return w;
}

//void
//gdl_expr_feature_get_unit_entities (const gdl_expr_chromosome * exp_data, const gdl_expr_feature * feature, gdl_expr_gene ** gene, gdl_expr_prbtxset ** prbtx, gdl_expr_transcript ** transcript, const size_t u)
//{
//	if (feature->T == gdl_expr_feature_transcript)
//	{
//		*gene       = exp_data->genes[feature->idx[0]];
//		*prbtx      = (*gene)->prbtxsets[feature->idx[1]];
//		*transcript = (*gene)->transcripts[(*prbtx)->tx_idx[u]];
//	}
//	else
//	{
//		*gene       = exp_data->genes[feature->idx[0]];
//		*prbtx      = 0;
//		*transcript = (*gene)->transcripts[u];
//	}
//}

//long
//gdl_expr_feature_get_unit_start (const gdl_expr_feature * feature, const gdl_expr_chromosome * exp_data, const size_t u)
//{
//	if (feature->T == gdl_expr_feature_transcript)
//	{
//		gdl_expr_gene * gene = exp_data->genes[feature->idx[0]];
//		return gene->transcripts[gene->prbtxsets[feature->idx[1]]->tx_idx[u]]->txStart;
//	}
//	else
//	{
//		return exp_data->genes[feature->idx[0]]->transcripts[u]->txStart;
//	}
//}
//
//long
//gdl_expr_feature_get_unit_end (const gdl_expr_feature * feature, const gdl_expr_chromosome * exp_data, const size_t u)
//{
//	if (feature->T == gdl_expr_feature_transcript)
//	{
//		gdl_expr_gene * gene = exp_data->genes[feature->idx[0]];
//		return gene->transcripts[gene->prbtxsets[feature->idx[1]]->tx_idx[u]]->txEnd;
//	}
//	else
//	{
//		return exp_data->genes[feature->idx[0]]->transcripts[u]->txEnd;
//	}
//}

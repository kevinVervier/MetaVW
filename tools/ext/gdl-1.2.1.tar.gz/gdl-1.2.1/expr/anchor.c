/*
 *  expr/anchor.c
 *
 *  $Author: baptiste78 $, $Date: 2011/05/15 17:57:43 $, $Version$
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <stdio.h>
#include <stdlib.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_version.h>
#include <gdl/gdl_machine.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_expr_feature.h>
#include <gdl/gdl_expr_feature_anchor.h>

gdl_expr_feature_anchor *
gdl_expr_feature_anchor_alloc (const gdl_expr_feature_anchor * T)
{
	gdl_expr_feature_anchor * t;

	t = GDL_CALLOC (gdl_expr_feature_anchor, 1);
	t->acronym   = gdl_string_clone (T->acronym);
	t->name      = gdl_string_clone (T->name);
	t->distance_min  = T->distance_min;
	t->distance_max  = T->distance_max;
	t->distance_avg  = T->distance_avg;
	t->distances     = T->distances;
	t->distance      = T->distance;

	return t;
}

void
gdl_expr_feature_anchor_free (gdl_expr_feature_anchor * T)
{
	if (T)
	{
		gdl_string_free (T->name);
		gdl_string_free (T->acronym);
		GDL_FREE (T);
	}
}

const gdl_expr_feature_anchor *
gdl_expr_feature_anchor_lookup_acronym (const gdl_string * acronym)
{
	if (!strcmp(acronym, gdl_expr_feature_anchor_FSS->acronym))
		return gdl_expr_feature_anchor_FSS;
	else if (!strcmp(acronym, gdl_expr_feature_anchor_FES->acronym))
		return gdl_expr_feature_anchor_FES;
	else if (!strcmp(acronym, gdl_expr_feature_anchor_FMID->acronym))
		return gdl_expr_feature_anchor_FMID;
	else if (!strcmp(acronym, gdl_expr_feature_anchor_FPRB->acronym))
		return gdl_expr_feature_anchor_FPRB;
	else if (!strcmp(acronym, gdl_expr_feature_anchor_TSS->acronym))
		return gdl_expr_feature_anchor_TSS;
	else if (!strcmp(acronym, gdl_expr_feature_anchor_TES->acronym))
		return gdl_expr_feature_anchor_TES;
	else
		return 0;
}

const gdl_expr_feature_anchor *
gdl_expr_feature_anchor_lookup_name (const gdl_string * name)
{
	if (!strcmp(name, gdl_expr_feature_anchor_FSS->name))
		return gdl_expr_feature_anchor_FSS;
	else if (!strcmp(name, gdl_expr_feature_anchor_FES->name))
		return gdl_expr_feature_anchor_FES;
	else if (!strcmp(name, gdl_expr_feature_anchor_FMID->name))
		return gdl_expr_feature_anchor_FMID;
	else if (!strcmp(name, gdl_expr_feature_anchor_FPRB->name))
		return gdl_expr_feature_anchor_FPRB;
	else if (!strcmp(name, gdl_expr_feature_anchor_TSS->name))
		return gdl_expr_feature_anchor_TSS;
	else if (!strcmp(name, gdl_expr_feature_anchor_TES->name))
		return gdl_expr_feature_anchor_TES;
	else
		return 0;
}

gdl_expr_feature_anchor *
gdl_expr_feature_anchor_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		gdl_string * name;
		const gdl_expr_feature_anchor * T;

		name = gdl_string_fread (stream);
		GDL_FREAD_STATUS (name!=0, 1, NULL);

		T = gdl_expr_feature_anchor_lookup_name (name);
		GDL_FREAD_STATUS (T!=0, 1, NULL);

		gdl_string_free (name);

		return gdl_expr_feature_anchor_alloc (T);;
	}
	return 0;
}

int
gdl_expr_feature_anchor_fwrite (FILE * stream, const gdl_expr_feature_anchor * T)
{
	if (stream && T)
	{
		int status = gdl_string_fwrite (stream, T->name);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

// MID

static long
_gdl_expr_feature_anchor_FMID_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	size_t i, n;
	long s, e, m;
	const long * starts, * ends;
	unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);

	starts = (feature->T->get_starts)(chrom, feature->idx, &n);
	ends   = (feature->T->get_ends)(chrom, feature->idx, &n);

	if (n == 1)
	{
		switch(strand)
		{
			case '+':
				return position - (starts[0] + ends[0]) / 2;
			case '-':
				return (starts[0] + ends[0]) / 2 - position;
		}
	}
	else
	{
		for(s = 0, i = 0; i < n; i++)
		{
			s += starts[i];
		}
		for(e = 0, i = 0; i < n; i++)
		{
			e += ends[i];
		}
		m = (s + e) / (2*n);

		switch(strand)
		{
			case '+':
				return position - m;
			case '-':
				return m - position;
		}
	}
}

static long
gdl_expr_feature_anchor_FMID_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return _gdl_expr_feature_anchor_FMID_d (chrom, feature, position);
}

static long
gdl_expr_feature_anchor_FMID_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return _gdl_expr_feature_anchor_FMID_d (chrom, feature, position);
}

static long
gdl_expr_feature_anchor_FMID_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	return _gdl_expr_feature_anchor_FMID_d (chrom, feature, position);
}

static long *
gdl_expr_feature_anchor_FMID_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	long * d = GDL_MALLOC (long, 1);
	*n=1;
	d[0] = _gdl_expr_feature_anchor_FMID_d (chrom, feature, position);
	return d;
}

static long
gdl_expr_feature_anchor_FMID_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	size_t i;
	const unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);
	const size_t nunit         = (feature->T->get_unit_size)(chrom, feature->idx);
	long * starts              = GDL_MALLOC (long, nunit);
	long * ends                = GDL_MALLOC (long, nunit);
	long d;

	(feature->T->get_unit_starts)(chrom, feature->idx, starts);
	(feature->T->get_unit_ends)(chrom, feature->idx, ends);

	d = (starts[unit_idx]+ends[unit_idx])/2;

	GDL_FREE (starts);
	GDL_FREE (ends);

	switch (strand)
	{
		case '+':
			return position - d;
		case '-':
			return d - position;
	}
}

// PRB

static long
gdl_expr_feature_anchor_FPRB_d_min (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	size_t i, im, n = feature->nprobe_pos;
	long  tmp, * starts;
	double d, dmin = GDL_POSINF;
	unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);

	starts = GDL_MALLOC (long, n);
	for(i = 0; i < n; i++)
	{
		starts[i] = (feature->probe_starts[i]+feature->probe_ends[i])/2;
	}

	switch(strand)
	{
		case '+':
			if (n == 1)
			{
				tmp = position - starts[0];
				GDL_FREE (starts);
				return tmp;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d < dmin)
				{
					dmin = d;
					im = i;
				}
			}
			tmp = position - starts[im];
			GDL_FREE (starts);
			return tmp;
		case '-':
			if (n == 1)
			{
				tmp = starts[0] - position;
				GDL_FREE (starts);
				return tmp;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d < dmin)
				{
					dmin = d;
					im   = i;
				}
			}
			tmp = starts[im] - position;
			GDL_FREE (starts);
			return tmp;
	}
}

static long
gdl_expr_feature_anchor_FPRB_d_max (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	size_t i, im, n = feature->nprobe_pos;
	long  tmp, * starts;
	double d, dmax = 0;
	unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);

	starts = GDL_MALLOC (long, n);
	for(i = 0; i < n; i++)
	{
		starts[i] = (feature->probe_starts[i]+feature->probe_ends[i])/2;
	}

	switch(strand)
	{
		case '+':
			if (n == 1)
			{
				tmp = position - starts[0];
				GDL_FREE (starts);
				return tmp;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(position - starts[i]);
				if (d > dmax)
				{
					dmax = d;
					im = i;
				}
			}
			tmp = position - starts[im];
			GDL_FREE (starts);
			return tmp;
		case '-':
			if (n == 1)
			{
				tmp = starts[0] - position;
				GDL_FREE (starts);
				return tmp;
			}
			for(i = 0; i < n; i++)
			{
				d = fabs(starts[i] - position);
				if (d > dmax)
				{
					dmax = d;
					im   = i;
				}
			}
			tmp = starts[im] - position;
			GDL_FREE (starts);
			return tmp;
	}
}

static long
gdl_expr_feature_anchor_FPRB_d_avg (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position)
{
	size_t i, n = feature->nprobe_pos;
	long tmp, d = 0, * starts;
	unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);

	starts = GDL_MALLOC (long, n);
	for(i = 0; i < n; i++)
	{
		starts[i] = (feature->probe_starts[i]+feature->probe_ends[i])/2;
	}

	switch(strand)
	{
		case '+':
			if (n == 1)
			{
				tmp = position - starts[0];
				GDL_FREE (starts);
				return tmp;
			}
			for(i = 0; i < n; i++)
			{
				d += position - starts[i];
			}
			GDL_FREE (starts);
			return d / n;
		case '-':
			if (n == 1)
			{
				GDL_FREE (starts);
				return starts[0] - position;
			}
			for(i = 0; i < n; i++)
			{
				d += starts[i] - position;
			}
			GDL_FREE (starts);
			return d / n;
	}
}

static long *
gdl_expr_feature_anchor_FPRB_d (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const long position, size_t * n)
{
	size_t i;
	unsigned char strand = (feature->T->get_strand)(chrom, feature->idx);
	long * d;

	*n = feature->nprobe_pos;

	d = GDL_MALLOC (long, *n);
	for(i = 0; i < *n; i++)
	{
		d[i] = (feature->probe_starts[i]+feature->probe_ends[i])/2;
	}

	switch(strand)
	{
		case '+':
			for(i = 0; i < *n; i++)
			{
				d[i] = position - d[i];
			}
			return d;
		case '-':
			for(i = 0; i < *n; i++)
			{
				d[i] = d[i] - position;
			}
			return d;
	}
}

static long
gdl_expr_feature_anchor_FPRB_d0 (const gdl_expr_chromosome * chrom, const gdl_expr_feature * feature, const size_t unit_idx, const long position)
{
	size_t i, n;
	long d0, * d = gdl_expr_feature_anchor_FPRB_d (chrom, feature, position, &n);

	for(d0 = 0, i = 0; i < n; i++)
	{
		d0 += d[i];
	}

	return (n>0) ? d0/n : 0;
}

const static gdl_expr_feature_anchor _FMID =
{
	"gdl_expr_feature_anchor_FMID",
	"FMID",
	&gdl_expr_feature_anchor_FMID_d_min,
	&gdl_expr_feature_anchor_FMID_d_max,
	&gdl_expr_feature_anchor_FMID_d_avg,
	&gdl_expr_feature_anchor_FMID_d,
	&gdl_expr_feature_anchor_FMID_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FMID = &_FMID;

const static gdl_expr_feature_anchor _FPRB =
{
	"gdl_expr_feature_anchor_FPRB",
	"FPRB",
	&gdl_expr_feature_anchor_FPRB_d_min,
	&gdl_expr_feature_anchor_FPRB_d_max,
	&gdl_expr_feature_anchor_FPRB_d_avg,
	&gdl_expr_feature_anchor_FPRB_d,
	&gdl_expr_feature_anchor_FPRB_d0
};

const gdl_expr_feature_anchor * gdl_expr_feature_anchor_FPRB = &_FPRB;

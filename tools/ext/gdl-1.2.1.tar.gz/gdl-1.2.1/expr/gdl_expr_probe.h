/*
 *  expr/gdl_expr_probe.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_PROBE_H__
#define __GDL_EXPR_PROBE_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>

__BEGIN_DECLS

/*! \struct gdl_expr_probe
 *  \brief A probe
 *
 *  A probe is the measurement unit. A probe can span multiple exons.
 */
struct gdl_expr_probe
{
	size_t idx;				/**< The index of the probe                */
	gdl_string * name;      /**< The name of the probe                 */
	size_t npos;			/**< The number of start/end positions     */
	long * starts;          /**< The 5' start positions                */
	long * ends;            /**< The 3' end positions                  */
	double ** data;			/**< The measurements pop x samples        */
	unsigned char ignore;	/**< The ignore flag                       */
	unsigned char strand;	/**< The strand of the probe               */
	size_t nexon;			/**< The exon interrogated by this probe   */
	size_t * ex_idx;	    /**< The indexes of these exons            */
	size_t * gx_idx;	    /**< The indexes of the genes of the exons */
};

/*! \typedef gdl_expr_probe
 *  \brief A probe
 */
typedef struct gdl_expr_probe gdl_expr_probe;

gdl_expr_probe * gdl_expr_probe_alloc (const gdl_string * name, const unsigned char strand, long * start, long * end, const size_t npos);
void gdl_expr_probe_free (gdl_expr_probe * b, const size_t npop);
gdl_expr_probe * gdl_expr_probe_clone (const gdl_expr_probe * probe);

gdl_expr_probe * gdl_expr_probe_fread (FILE * stream, const size_t npop, const size_t * pop_sizes);
int gdl_expr_probe_fwrite (FILE * stream, const gdl_expr_probe * p, const size_t npop, const size_t * pop_sizes);

gdl_boolean gdl_expr_probe_is_missing (const gdl_expr_probe * p, const size_t i, const size_t j);

size_t gdl_expr_probe_add_exon (gdl_expr_probe * p, const size_t g, const size_t e);

__END_DECLS

#endif

/*
 *  expr/gdl_expr_prbtxset.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_PRBTXSET_H__
#define __GDL_EXPR_PRBTXSET_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_list.h>
#include <gdl/gdl_vector_uint.h>
#include <gdl/gdl_expr_probe.h>

__BEGIN_DECLS

/*! \struct gdl_expr_prbtxset
 *  \brief A PRoBed Transcript(X) SET
 *
 *  A probed transcript set is a set of transcripts which
 *  are interrogated by the same set of probes so that the summarized
 *  measurements from all the probes provide a measurement for the
 *  whole set of transcripts (in other words this measurement is a mixture
 *  of the expression levels of each individual transcript which is part
 *  of this set).
 */
struct gdl_expr_prbtxset
{
	size_t ntx;				/**< The number of transcripts in the set      */
	size_t nprobe;		    /**< The number of probes for that set         */
	size_t * tx_idx;        /**< The transcript indexes                    */
	size_t * probe_idx;     /**< The probes indexes                        */
	size_t ntxStart;		/**< The number of tx starts 				   */
	size_t ntxEnd;          /**< The number of tx ends  				   */
	size_t * txStarts; 		/**< The tx starts 				               */
	size_t * txEnds; 		/**< The tx ends 				               */
};

/*! \typedef gdl_expr_prbtxset
 *  \brief A probe
 */
typedef struct gdl_expr_prbtxset gdl_expr_prbtxset;

gdl_expr_prbtxset * gdl_expr_prbtxset_alloc (const size_t ntx, const size_t nprobe);
void gdl_expr_prbtxset_free (gdl_expr_prbtxset * b);

gdl_expr_prbtxset * gdl_expr_prbtxset_fread (FILE * stream);
int gdl_expr_prbtxset_fwrite (FILE * stream, const gdl_expr_prbtxset * p);

__END_DECLS

#endif

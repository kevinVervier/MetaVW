/*
 *  expr/meta_exon_f.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_sort.h>
#include <gdl/gdl_statistics.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_expr_genome.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_feature.h>

static double **
_gdl_expr_feature_metaexon_data (const gdl_expr_chromosome * c, size_t idx[], const gdl_expr_feature_parameter * p)
{
	size_t i, j, np=0;
	double ** Y = 0;
	gdl_expr_prbexset * pts = c->genes[idx[0]]->prbexsets[idx[1]];

	for(i = 0; i < pts->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		np++;
	}
	if (np > 1)
	{
		double *** X = GDL_MALLOC (double **, np);

	    for(i = j = 0; i < pts->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
			if (probe->ignore == 'y' || probe->data == 0)
			{
				continue;
			}
			X[j++] = probe->data;
		}

		Y = gdl_expr_summarize (X, np, c->npop, c->pop_sizes, p);

		GDL_FREE (X);
	}
	else
	{
		for(i = 0; i < pts->nprobe; i++)
	    {
			gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]];
			if (probe->ignore != 'y' && probe->data != 0)
			{
				break;
			}
	    }
		Y = c->probes[c->genes[idx[0]]->probe_idx[pts->probe_idx[i]]]->data;
	}

	return Y;
}

static double ***
gdl_expr_firma_run (double *** X, const size_t K, const size_t npop, const size_t pop_sizes[], double ****R)
{
	size_t i, j, k;
	double *** Y, t, ** x, * r, * c, * z, * zo, s;

	Y = GDL_MALLOC (double **, K);
	for(j = 0; j < K; j++)
	{
		Y[j] = GDL_MALLOC (double *, npop);
		for(i = 0; i < npop; i++)
		{
			Y[j][i] = GDL_MALLOC (double, pop_sizes[i]);
		}
	}
	// we do the median polish within each population
	for(i = 0; i < npop; i++)
	{
		// workspace
		r  = GDL_CALLOC (double, pop_sizes[i]);
		x  = GDL_MATRIX_ALLOC (double, K, pop_sizes[i]);
		c  = GDL_CALLOC (double, K);
		z  = GDL_CALLOC (double, pop_sizes[i]*K);
		zo = GDL_CALLOC (double, pop_sizes[i]*K);
		for(j = 0; j < K; j++)
		{
			memcpy(x[j], X[j][i], sizeof(double)*pop_sizes[i]);
		}
		gdl_stats_medpolish (x, K, pop_sizes[i], 1.e-3, 25, &t, c, r, z);
		for(j = k = 0; j < pop_sizes[i]*K; j++)
		{
			if (!gdl_isnan(z[j])) // missing data
			{
				zo[k++] = z[j];
			}
		}
		if (k)
		{
			gdl_sort(zo, 1, k);
			s = gdl_stats_median_from_sorted_data (zo, 1, k);
		}
		else
		{
			s = 0.0;
		}
		for(j = 0; j < K; j++)
		{
			for(k = 0; k < pop_sizes[i]; k++)
			{
				if (!gdl_isnan(X[j][i][k]))
				{
					(*R)[j][i][k] = c[j] + z[j*pop_sizes[i]+k];
					Y[j][i][k]    = z[j*pop_sizes[i]+k];
					if (s != 0.)
					{
						Y[j][i][k] /= s;
					}
				}
				else
				{
					Y[j][i][k]    = GDL_NAN;
                    (*R)[j][i][k] = GDL_NAN;
				}
			}
		}
		GDL_MATRIX_FREE (x, K);
		GDL_FREE (c);
		GDL_FREE (r);
		GDL_FREE (z);
		GDL_FREE (zo);
	}

	return Y;
}

static double ***
gdl_expr_firma_data (const gdl_expr_chromosome * c, const size_t idx[], size_t ** firma_idx, size_t * firma_n, double **** R)
{
	size_t i, j, k, np = 0;
	double *** X  = 0;

	for(np = i = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		k=i;
		np++;
	}

	*firma_n   = np;
	*firma_idx = GDL_MALLOC (size_t, np);
	*R         = GDL_MALLOC (double **, np);

	X = GDL_MALLOC (double **, np);

    for(i = j = 0; i < c->genes[idx[0]]->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[c->genes[idx[0]]->probe_idx[i]];
		if (probe->ignore == 'y' || probe->data == 0)
		{
			continue;
		}
		(*firma_idx)[j] = c->genes[idx[0]]->probe_idx[i];
		X[j]            = probe->data;
		(*R)[j]         = GDL_MALLOC (double *, c->npop);
		for(k = 0; k < c->npop; k++)
		{
			(*R)[j][k]  = GDL_MALLOC (double, c->pop_sizes[k]);
		}
		j++;
	}

    double *** Y = gdl_expr_firma_run (X, j, c->npop, c->pop_sizes, R);

    GDL_FREE (X);

	return Y;
}

static int
_gdl_expr_feature_metaexon_alloc (gdl_expr_feature_chromosome * f, const gdl_expr_chromosome * c, const gdl_expr_feature_parameter * p, FILE * progress, FILE * logger)
{
	size_t i, j, k, l, m, n, * idx, npts = 0;
	size_t min_probe;

	if (progress)
	{
		fprintf (progress, ">>Create Meta Exon Features for Chromosome %s\n", c->name);
		fflush (progress);
	}
	if (!c->ngene)
	{
		GDL_WARNING ("No gene defined for that chromosome\n", GDL_EINVAL);
		f->nfeature = 0;
		f->features = 0;
		return GDL_EINVAL;
	}
	if (p)
	{
		gdl_string * min_probe_str = gdl_hashtable_lookup (p->values, "MinimumProbeNumber");
		if (min_probe_str)
		{
			min_probe = (size_t)atoi(min_probe_str);
		}
	}
	// how many probe exon set ??
	for(i = 0; i < c->ngene; i++)
	{
		for(j = 0; j < c->genes[i]->nprbexset; j++)
		{
			for(l = k = 0; k < c->genes[i]->prbexsets[j]->nprobe; k++)
			{
				gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbexsets[j]->probe_idx[k]]];
				if (probe->ignore == 'y' || probe->data == 0)
				{
					l++;
				}
			}
			if (l < c->genes[i]->prbexsets[j]->nprobe)
			{
				npts += 1;
			}
		}
	}
	if (progress)
	{
		fprintf (progress, " #MetaExon(i.e set of exons with at least one common probe) = %ld\n", npts);
		fflush (progress);
	}

	if (npts)
	{
		f->nfeature = npts;
		f->features = GDL_MALLOC (gdl_expr_feature *, npts);

		idx = GDL_MALLOC (size_t, 2);

		for(i = k = 0; i < c->ngene; i++)
		{
			gdl_string * exon_index    = gdl_hashtable_lookup (p->values, "ExonIndex");
			double     **  eg_data     = 0;
			double     *** firma_data  = 0;
			double     *** firma_data2 = 0;
			size_t     * firma_prbidx  = 0;
			size_t       firma_nprb    = 0;

			if (exon_index && !strcmp(exon_index, "firma"))
			{
				firma_data = gdl_expr_firma_data (c, &i, &firma_prbidx, &firma_nprb, &firma_data2);
			}
			else if (exon_index && !strcmp(exon_index, "e/g"))
			{
				eg_data = gdl_expr_feature_gene_data (c, &i, p);
			}

			idx[0] = i;

			for(j = 0; j < c->genes[i]->nprbexset; j++)
			{
				for(l = m = 0; m < c->genes[i]->prbexsets[j]->nprobe; m++)
				{
					gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbexsets[j]->probe_idx[m]]];
					if (probe->ignore == 'y' || probe->data == 0)
					{
						l++;
					}
				}
				if (l < c->genes[i]->prbexsets[j]->nprobe)
				{
					idx[1] = j;
					f->features[k]            = gdl_expr_feature_alloc (gdl_expr_feature_metaexon, idx);
					f->features[k]->nprobe    = c->genes[i]->prbexsets[j]->nprobe - l;
					f->features[k]->probe_idx = GDL_MALLOC (size_t, f->features[k]->nprobe);
					for(m = l = 0; m < c->genes[i]->prbexsets[j]->nprobe; m++)
					{
						gdl_expr_probe * probe = c->probes[c->genes[i]->probe_idx[c->genes[i]->prbexsets[j]->probe_idx[m]]];
						if (probe->ignore == 'y' || probe->data == 0)
						{
							continue;
						}
						f->features[k]->probe_idx[l++] = c->genes[i]->probe_idx[c->genes[i]->prbexsets[j]->probe_idx[m]];
					}
					gdl_expr_feature_set_probe_positions (c, f->features[k]);
					gdl_expr_feature_create_name (c, f->features[k], c->genes[i]->name);
					if (firma_data && firma_nprb > 1)
					{
						double *** X = 0;
                                                if (f->features[k]->nprobe > 1)
                                                {
                                                   X = GDL_MALLOC (double **, f->features[k]->nprobe);
                                                }
						for(l = 0; l < f->features[k]->nprobe; l++)
						{
							for(n = 0; n < firma_nprb; n++)
							{
								if (f->features[k]->probe_idx[l]==firma_prbidx[n])
								{
									break;
								}
							}
							if (n == firma_nprb)
							{
								GDL_ERROR_VAL("Internal error", GDL_FAILURE, GDL_FAILURE);
							}
                                                        if (f->features[k]->nprobe > 1)
                                                        {
							   X[l] = firma_data[n];
                                                        }
                                                        else
                                                        {
						           f->features[k]->data = firma_data2[n];
                                                           firma_data2[n]       = 0;
                                                           break;
                                                        }
						}
                                                if (f->features[k]->nprobe > 1)
                                                {
						   f->features[k]->data = gdl_expr_summarize (X, f->features[k]->nprobe, c->npop, c->pop_sizes, p);
						   GDL_FREE (X);
                                                }
					}
					else
					{
						f->features[k]->data  = _gdl_expr_feature_metaexon_data(c, idx, p);
						if (eg_data)
						{
							for(l = 0; l < c->npop; l++)
							{
								for(n = 0; n < c->pop_sizes[l]; n++)
								{
									if (!gdl_isnan (f->features[k]->data[l][n]))
									{
										f->features[k]->data[l][n] -= eg_data[l][n];
									}
								}
							}
						}
					}
					k++;
				}
			}
			if (firma_data)
			{
				for(j = 0; j < firma_nprb; j++)
				{
					GDL_MATRIX_FREE (firma_data[j], c->npop);
					if (firma_data2[j])
					{
						GDL_MATRIX_FREE (firma_data2[j], c->npop);
					}
				}
				GDL_FREE (firma_data);
				GDL_FREE (firma_data2);
				GDL_FREE (firma_prbidx);
			}
			else if (eg_data)
			{
				GDL_MATRIX_FREE (eg_data, c->npop);
			}
		}
		GDL_FREE (idx);
	}

	return GDL_SUCCESS;
}

static void *
_gdl_expr_feature_metaexon_get (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->prbexsets[idx[1]];
}

static const long *
_gdl_expr_feature_metaexon_starts (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->prbexsets[idx[1]]->nexStart;
	return c->genes[idx[0]]->prbexsets[idx[1]]->exStarts;
}

static const long *
_gdl_expr_feature_metaexon_ends (const gdl_expr_chromosome * c, const size_t idx[], size_t * n)
{
	*n = c->genes[idx[0]]->prbexsets[idx[1]]->nexEnd;
	return c->genes[idx[0]]->prbexsets[idx[1]]->exEnds;
}

static unsigned char
_gdl_expr_feature_metaexon_strand (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->strand;
}

static size_t
_gdl_expr_feature_metaexon_unit_size (const gdl_expr_chromosome * c, const size_t idx[])
{
	return c->genes[idx[0]]->prbexsets[idx[1]]->nex;
}

static void
_gdl_expr_feature_metaexon_unit_starts(const gdl_expr_chromosome * c, const size_t idx[], long starts[])
{
	size_t i;
	for(i = 0; i < c->genes[idx[0]]->prbexsets[idx[1]]->nex; i++)
	{
		starts[i] = c->genes[idx[0]]->exons[c->genes[idx[0]]->prbexsets[idx[1]]->ex_idx[i]]->start;
	}
}

static void
_gdl_expr_feature_metaexon_unit_ends(const gdl_expr_chromosome * c, const size_t idx[], long ends[])
{
	size_t i;
	for(i = 0; i < c->genes[idx[0]]->prbexsets[idx[1]]->nex; i++)
	{
		ends[i] = c->genes[idx[0]]->exons[c->genes[idx[0]]->prbexsets[idx[1]]->ex_idx[i]]->end;
	}
}

static long
_gdl_expr_feature_metaexon_unit_start (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->exons[c->genes[idx[0]]->prbexsets[idx[1]]->ex_idx[unit_idx]]->start;
}

static long
_gdl_expr_feature_metaexon_unit_end (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	return c->genes[idx[0]]->exons[c->genes[idx[0]]->prbexsets[idx[1]]->ex_idx[unit_idx]]->end;
}

static gdl_expr_feature_entities *
_gdl_expr_feature_metaexon_unit_entities (const gdl_expr_chromosome * c, const size_t idx[], const size_t unit_idx)
{
	gdl_expr_feature_entities * e = GDL_CALLOC (gdl_expr_feature_entities, 1);

	e->gene       = c->genes[idx[0]];
	e->prbexset   = e->gene->prbexsets[idx[1]];
	e->exon       = e->gene->exons[e->prbexset->ex_idx[unit_idx]];

	return e;
}

static const gdl_expr_feature_type _gdl_expr_feature_metaexon =
{
	"gdl_expr_feature_metaexon",
	"metaexon",
	2,
	&_gdl_expr_feature_metaexon_alloc,
	&_gdl_expr_feature_metaexon_get,
	&_gdl_expr_feature_metaexon_starts,
	&_gdl_expr_feature_metaexon_ends,
	&_gdl_expr_feature_metaexon_strand,
	&_gdl_expr_feature_metaexon_data,
	&_gdl_expr_feature_metaexon_unit_size,
	&_gdl_expr_feature_metaexon_unit_starts,
	&_gdl_expr_feature_metaexon_unit_ends,
	&_gdl_expr_feature_metaexon_unit_start,
	&_gdl_expr_feature_metaexon_unit_end,
	&_gdl_expr_feature_metaexon_unit_entities,
};

const gdl_expr_feature_type * gdl_expr_feature_metaexon = &_gdl_expr_feature_metaexon;

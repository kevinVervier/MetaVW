/*
 *  expr/gene_is_in.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_expr_gene.h>

static int
is_in_exon_intron (const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position, gdl_boolean * in_exon)
{
	size_t i;

	if (position >= tx->txStart && position <= tx->txEnd)
	{
		for (i = 0; i < tx->nexon; i++)
		{
			if (position >= gene->exons[tx->exon_idx[i]]->start && position <= gene->exons[tx->exon_idx[i]]->end)
			{
				*in_exon=gdl_true;
				return i;
			}
			else if (i < tx->nexon-1 && (position > gene->exons[tx->exon_idx[i]]->end && position < gene->exons[tx->exon_idx[i+1]]->start))
			{
				*in_exon=gdl_false;
				return i;
			}
		}
		*in_exon = gdl_false;
		return -1;
	}
	else
	{
		*in_exon = gdl_false;
		return -1;
	}
}

size_t *
gdl_expr_gene_which_exons (const gdl_expr_gene * gene, const long position, size_t * nexon)
{
	size_t i;

	(*nexon) = 0;
	if (position < gene->txStartMin || position > gene->txEndMax)
	{
		return 0;
	}
	for(i = 0; i < gene->nexon; i++)
	{
		if (position >= gene->exons[i]->start && position <= gene->exons[i]->end)
		{
			(*nexon)++;
		}
	}
	if (*nexon)
	{
		size_t * exon_idx = GDL_MALLOC (size_t, *nexon);
		*nexon = 0;
		for(i = 0; i < gene->nexon; i++)
		{
			if (position >= gene->exons[i]->start && position <= gene->exons[i]->end)
			{
				exon_idx[(*nexon)++] = i;
			}
		}
		return exon_idx;
	}
	else
	{
		return 0;
	}
}

gdl_boolean
gdl_expr_gene_is_within(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	if (position >= tx->txStart && position <= tx->txEnd)
	{
		return gdl_true;
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_5utr(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	if (gene->strand == '+')
	{
		if (position >= tx->txStart && position < tx->cdsStart)
		{
			return gdl_true;
		}
	}
	else
	{
		if (position <= tx->txEnd && position > tx->cdsEnd)
		{
			return gdl_true;
		}
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_3utr(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	if (gene->strand == '+')
	{
		if (position > tx->cdsEnd && position <= tx->txEnd)
		{
			return gdl_true;
		}
	}
	else
	{
		if (position >= tx->txStart && position < tx->cdsStart)
		{
			return gdl_true;
		}
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		if (in_exon)
		{
			return gdl_true;
		}
		return gdl_false;
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		if (in_exon)
		{
			return gdl_false;
		}
		return gdl_true;
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_cds_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if (position > tx->cdsEnd || position < tx->cdsStart)
	{
		return gdl_false;
	}
	if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		if (in_exon)
		{
			return gdl_false;
		}
		return gdl_true;
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_non_cds_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if (position >= tx->cdsStart && position <= tx->cdsEnd)
	{
		return gdl_false;
	}
	if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		if (in_exon)
		{
			return gdl_false;
		}
		if (j = 0 || j + 2 == tx->nexon) // neither first or last intron
		{
			return gdl_false;
		}
		return gdl_true;
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_first_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if (tx->nexon == 1)
	{
		return gdl_false;
	}
	if ((position >= tx->txStart && position < tx->cdsStart) || (position > tx->cdsEnd && position <= tx->txEnd))
	{
		if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
		{
			if (in_exon)
			{
				return gdl_false;
			}
			if ((j == 0 && gene->strand == '+') || (j + 2 == tx->nexon && gene->strand == '-'))
			{
				return gdl_true;
			}
		}
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_last_intron(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if (tx->nexon <= 2)
	{
		return gdl_false;
	}
	if ((position >= tx->txStart && position < tx->cdsStart) || (position > tx->cdsEnd && position <= tx->txEnd))
	{
		if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
		{
			if (in_exon)
			{
				return gdl_false;
			}
			if ((j == 0 && gene->strand == '-') || (j + 2 == tx->nexon && gene->strand == '+'))
			{
				return gdl_true;
			}
		}
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_cds_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int j;
	gdl_boolean in_exon;

	if (position > tx->cdsEnd || position < tx->cdsStart)
	{
		return gdl_false;
	}
	if ((j=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		return in_exon;
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_non_cds_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int i;
	gdl_boolean in_exon;

	if (position >= tx->cdsStart && position <= tx->cdsEnd)
	{
		return gdl_false;
	}
	if ((i=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
	{
		if (!in_exon)
		{
			return gdl_false;
		}
		if (tx->nexon == 1)
		{
			return gdl_true;
		}
		else if (i > 0 && i < tx->nexon-1)
		{
			return gdl_true;
		}
		return gdl_false;
	}
	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_first_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int i;
	gdl_boolean in_exon;

	if (tx->nexon == 1)
	{
		return gdl_false;
	}

	if ((position >= tx->txStart && position < tx->cdsStart)
	   || (position > tx->cdsEnd && position <= tx->txEnd))
	{
		if ((i=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
		{
			if (!in_exon)
			{
				return gdl_false;
			}
			if (i == 0 && gene->strand == '+')
			{
				return gdl_true;
			}
			else if (i==tx->nexon-1 && gene->strand == '-')
			{
				return gdl_true;
			}
		}
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_last_exon(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	int i;
	gdl_boolean in_exon;

	if (tx->nexon == 1)
	{
		return gdl_false;
	}

	if ((position >= tx->txStart && position < tx->cdsStart)
	   || (position > tx->cdsEnd && position <= tx->txEnd))
	{
		if ((i=is_in_exon_intron (gene, tx, position, &in_exon))!=-1)
		{
			if (!in_exon)
			{
				return gdl_false;
			}
			if (i == 0 && gene->strand == '-')
			{
				return gdl_true;
			}
			else if (i==tx->nexon-1 && gene->strand == '+')
			{
				return gdl_true;
			}
		}
	}

	return gdl_false;
}

gdl_boolean
gdl_expr_gene_is_in_splice_site(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position)
{
	size_t i;

	for(i = 0; i < tx->nexon; i++)
	{
		switch (gene->strand)
		{
			case '+': // 5' end intron
				if (i > 1 && (position >= gene->exons[tx->exon_idx[i]]->end-2 && position <= gene->exons[tx->exon_idx[i]]->end + 6))
				{
					return gdl_true;
				}
				break;
				if ((i < tx->nexon - 1) && (position >= gene->exons[tx->exon_idx[i]]->start-3 && position <= gene->exons[tx->exon_idx[i]]->start))
				{
					return gdl_true;
				}
				break;
			case '-': // 3' end intron
				if (i > 1 && (position >= gene->exons[tx->exon_idx[i]]->end && position <= gene->exons[tx->exon_idx[i]]->end + 3))
				{
					return gdl_true;
				}
				break;
				if ((i < tx->nexon - 1) && (position >= gene->exons[tx->exon_idx[i]]->start-6 && position <= gene->exons[tx->exon_idx[i]]->start+2))
				{
					return gdl_true;
				}
				break;
		}
	}
	return gdl_false;
}

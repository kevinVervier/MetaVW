/*
 *  expr/cis.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_bayesian_regression.h>
#include <gdl/gdl_expr_feature.h>
#include <gdl/gdl_expr_feature_cis.h>

gdl_expr_feature_cis_snp *
gdl_expr_feature_cis_snp_alloc (const size_t grid_size)
{
	gdl_expr_feature_cis_snp * r;

	r = GDL_CALLOC (gdl_expr_feature_cis_snp, 1);

	r->bf   = GDL_CALLOC (double, grid_size);
	r->pval = 1;

	return r;
}

void
gdl_expr_feature_cis_snp_free (gdl_expr_feature_cis_snp * r)
{
	if (r)
	{
		GDL_FREE (r->bf);
		GDL_FREE (r);
	}
}

gdl_expr_feature_cis_snp *
gdl_expr_feature_cis_snp_fread (FILE * stream, const size_t grid_size)
{
	if (stream)
	{
		int status;
		gdl_expr_feature_cis_snp * r;

		r = gdl_expr_feature_cis_snp_alloc (grid_size);

		status = fread (r->bf, sizeof(double), grid_size, stream);
		GDL_FREAD_STATUS (status, grid_size, NULL);
		status = fread (&r->pval, sizeof(double), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread (&r->a, sizeof(double), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		return r;
	}
	return 0;
}

int
gdl_expr_feature_cis_snp_fwrite (FILE * stream, const gdl_expr_feature_cis_snp * r, const size_t grid_size)
{
	if (stream && r)
	{
		int status;

		status = fwrite (r->bf, sizeof(double), grid_size, stream);
		GDL_FWRITE_STATUS (status, grid_size, 1);
		status = fwrite (&r->pval, sizeof(double), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (&r->a, sizeof(double), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}

gdl_expr_feature_cis *
gdl_expr_feature_cis_alloc (const int snp_from, const int snp_to)
{
	gdl_expr_feature_cis * r;

	r = GDL_MALLOC (gdl_expr_feature_cis, 1);

	if (snp_from != -1 && snp_to != -1)
	{
		r->size     = snp_to - snp_from + 1;
		r->snp_from = (size_t) snp_from;
		r->snp_to   = (size_t) snp_to;
		if (r->size)
		{
			r->snps = GDL_CALLOC (gdl_expr_feature_cis_snp *, r->size);
		}
	}
	else
	{
		r->size = 0;
	}

	return r;
}

void
gdl_expr_feature_cis_free (gdl_expr_feature_cis * r)
{
	if (r)
	{
		size_t i;
		for (i = 0; i < r->size; i++)
			gdl_expr_feature_cis_snp_free (r->snps[i]);
		GDL_FREE (r->snps);
		GDL_FREE (r);
	}
}

gdl_expr_feature_cis *
gdl_expr_feature_cis_fread (FILE * stream, const size_t grid_size)
{
	if (stream)
	{
		int status;
		unsigned char has;
		size_t i;
		gdl_expr_feature_cis * r;

		r = GDL_CALLOC (gdl_expr_feature_cis, 1);

		status = fread (&(r->size), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		if (r->size)
		{
			status = fread (&(r->snp_from), sizeof(size_t), 1, stream);
			GDL_FREAD_STATUS (status, 1, NULL);
			status = fread (&(r->snp_to), sizeof(size_t), 1, stream);
			GDL_FREAD_STATUS (status, 1, NULL);

			r->snps = GDL_CALLOC (gdl_expr_feature_cis_snp *, r->size);
			for (i = 0; i < r->size; i++)
			{
				status = fread (&has, sizeof(unsigned char), 1, stream);
				GDL_FWRITE_STATUS (status, 1, NULL);
				if (has == 'y')
				{
					r->snps[i] = gdl_expr_feature_cis_snp_fread (stream, grid_size);
					GDL_FREAD_STATUS (r->snps[i] != 0, 1, NULL);
				}
			}
		}

		return r;
	}

	return 0;
}

int
gdl_expr_feature_cis_fwrite (FILE * stream, const gdl_expr_feature_cis * r, const size_t grid_size)
{
	if (stream && r)
	{
		int status;
		unsigned char has;
		size_t i;

		status = fwrite (&r->size, sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		if (r->size)
		{
			status = fwrite (&r->snp_from, sizeof(size_t), 1, stream);
			GDL_FWRITE_STATUS (status, 1, 1);
			status = fwrite (&r->snp_to, sizeof(size_t), 1, stream);
			GDL_FWRITE_STATUS (status, 1, 1);

			for (i = 0; i < r->size; i++)
			{
				has = (r->snps[i]) ? 'y' : 'n';
				status = fwrite (&has, sizeof(unsigned char), 1, stream);
				GDL_FWRITE_STATUS (status, 1, 1);
				if (has == 'y')
				{
					status = gdl_expr_feature_cis_snp_fwrite (stream, r->snps[i], grid_size);
					GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
				}
			}
		}

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}


gdl_expr_feature_cis_chromosome *
gdl_expr_feature_cis_chromosome_alloc (const size_t size)
{
	gdl_expr_feature_cis_chromosome * r;

	r = GDL_MALLOC (gdl_expr_feature_cis_chromosome, 1);

	r->size = size;
	r->features = GDL_CALLOC (gdl_expr_feature_cis *, size);

	return r;
}

void
gdl_expr_feature_cis_chromosome_free (gdl_expr_feature_cis_chromosome * r)
{
	if (r)
	{
		size_t i;
		for (i = 0; i < r->size; i++)
			gdl_expr_feature_cis_free (r->features[i]);
		GDL_FREE (r->features);
		GDL_FREE (r);
	}
}

gdl_expr_feature_cis_chromosome *
gdl_expr_feature_cis_chromosome_fread (FILE * stream, const size_t grid_size)
{
	if (stream)
	{
		int status;
		size_t i,size;
		gdl_expr_feature_cis_chromosome * r;

		status = fread (&size, sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		r = gdl_expr_feature_cis_chromosome_alloc (size);

		for (i = 0; i < size; i++)
		{
			r->features[i] = gdl_expr_feature_cis_fread (stream, grid_size);
			GDL_FREAD_STATUS (r->features[i]!=0, 1, NULL);
		}

		return r;
	}

	return 0;
}

int
gdl_expr_feature_cis_chromosome_fwrite (FILE * stream, const gdl_expr_feature_cis_chromosome * r, const size_t grid_size)
{
	if (stream && r)
	{
		int status;
		size_t i;

		status = fwrite (&r->size, sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		for (i = 0; i < r->size; i++)
		{
			status = gdl_expr_feature_cis_fwrite (stream, r->features[i], grid_size);
			GDL_FREAD_STATUS (status, GDL_SUCCESS, 1);
		}

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}

static gdl_string *
gdl_expr_feature_cis_genome_chromfile (const gdl_expr_feature_cis_genome * g, size_t i)
{
	return gdl_string_sprintf ("%s/%s_cis.fdb", g->dbdir, g->chroms[i], g->T->acronym);
}

gdl_expr_feature_cis_genome *
gdl_expr_feature_cis_genome_alloc (const gdl_string * dir, const gdl_expr_feature_genome * f_db, const gdl_bayreg_model * model)
{
	size_t i;
	gdl_expr_feature_cis_genome * r;

	r = GDL_MALLOC (gdl_expr_feature_cis_genome, 1);

	r->dbdir    = gdl_string_clone (dir);
	r->nchrom = f_db->nchrom;
	r->T      = f_db->T;
	r->chroms = GDL_CALLOC (gdl_string *, r->nchrom);
	r->model  = gdl_bayreg_model_clone (model);

	for(i = 0; i < r->nchrom; i++)
	{
		r->chroms[i] = gdl_string_clone (f_db->chroms[i]);
	}

	return r;
}

void
gdl_expr_feature_cis_genome_free (gdl_expr_feature_cis_genome * r)
{
	if (r)
	{
		size_t i;
		for (i = 0; i < r->nchrom; i++)
			gdl_string_free (r->chroms[i]);
		GDL_FREE (r->chroms);
		gdl_bayreg_model_free (r->model);
		gdl_string_free (r->dbdir);
		GDL_FREE (r);
	}
}

gdl_expr_feature_cis_genome *
gdl_expr_feature_cis_genome_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		size_t i;
		gdl_string * type;
		gdl_expr_feature_cis_genome * r;

		r = GDL_CALLOC (gdl_expr_feature_cis_genome, 1);

		type = gdl_string_fread (stream);
		GDL_FREAD_STATUS (type!=0, 1, NULL);

		r->T = gdl_expr_feature_type_lookup (type, "name");

		gdl_string_free (type);

		r->dbdir = gdl_string_fread (stream);
		GDL_FREAD_STATUS (r->dbdir!=0, 1, NULL);

		status = fread (&r->nchrom, sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		r->chroms = GDL_CALLOC (gdl_string *, r->nchrom);

		for (i = 0; i < r->nchrom; i++)
		{
			r->chroms[i] = gdl_string_fread (stream);
			GDL_FREAD_STATUS (r->chroms[i]!=0, 1, NULL);
		}

		r->model = gdl_bayreg_model_fread (stream);
		GDL_FREAD_STATUS (r->model!=0, 1, NULL);

		return r;
	}

	return 0;
}

int
gdl_expr_feature_cis_genome_fwrite (FILE * stream, const gdl_expr_feature_cis_genome * r)
{
	if (stream && r)
	{
		int status;
		size_t i;

		status = gdl_string_fwrite (stream, r->T->name);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);

		status = gdl_string_fwrite (stream, r->dbdir);
		GDL_FREAD_STATUS (status, GDL_SUCCESS, 1);

		status = fwrite (&r->nchrom, sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		for (i = 0; i < r->nchrom; i++)
		{
			status = gdl_string_fwrite (stream, r->chroms[i]);
			GDL_FREAD_STATUS (status, GDL_SUCCESS, 1);
		}

		status = gdl_bayreg_model_fwrite (stream, r->model);
		GDL_FREAD_STATUS (status, GDL_SUCCESS, 1);

		return GDL_SUCCESS;
	}

	return GDL_EINVAL;
}

int
gdl_expr_feature_cis_genome_set (gdl_expr_feature_cis_genome * g, size_t i, const gdl_string * name, const gdl_expr_feature_cis_chromosome * chrom)
{
	FILE * stream;
	gdl_string * filename = gdl_expr_feature_cis_genome_chromfile (g, i);

	gdl_string_free (g->chroms[i]);

	g->chroms[i] = gdl_string_clone (name);

	stream = gdl_fileopen (filename, "w");

	gdl_bayreg_model_bf_storage_size (g->model);

	gdl_expr_feature_cis_chromosome_fwrite (stream, chrom, g->model->size);

	gdl_fileclose (filename, stream);

	gdl_string_free (filename);
}

gdl_expr_feature_cis_chromosome *
gdl_expr_feature_cis_genome_get (const gdl_expr_feature_cis_genome * g, size_t i)
{
	FILE * stream;
	gdl_string * filename = gdl_expr_feature_cis_genome_chromfile (g, i);
	gdl_expr_feature_cis_chromosome * chrom;

	stream = gdl_fileopen (filename, "r");

	gdl_bayreg_model_bf_storage_size (g->model);

	chrom = gdl_expr_feature_cis_chromosome_fread (stream, g->model->size);

	gdl_fileclose (filename, stream);

	gdl_string_free (filename);

	return chrom;
}



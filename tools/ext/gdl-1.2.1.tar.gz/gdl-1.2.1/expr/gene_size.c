/*
 *  expr/gene_size.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *  
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_hash.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_sort_ulong.h>
#include <gdl/gdl_expr_chromosome.h>
#include <gdl/gdl_expr_gene.h>
#include <gdl/gdl_expr_transcript.h>
#include <gdl/gdl_expr_feature.h>

static long
gdl_expr_gene_collapse_segments(const long starts[], const long ends[], const size_t nseg)
{
	size_t i, j, * ignore;
	long tot, * new_starts, * new_ends;
	
	ignore     = GDL_MALLOC (size_t, nseg);
	new_starts = GDL_MALLOC (long, nseg);
	new_ends   = GDL_MALLOC (long, nseg);
	
	for(i = 0; i < nseg; i++)
	{
		if (!ignore[i])
		{
			new_starts[i] = starts[i];
			new_ends[i]   = ends[i];
			for(j = i+1; j < nseg; j++)
			{
				if (ends[j] < new_starts[i] || starts[j] > new_ends[i])
				{
					continue;
				}
				/**
				 *    ----------
				 * -------
				 */
				else if (starts[j] < new_starts[i] && (ends[j] >= new_starts[i] && ends[j] <= new_ends[i]))
				{
					new_starts[i] = starts[j];
					ignore[j] = 1;
				}
				/**
				 * ----------
				 *    ----------
				 */
				else if (ends[j] > new_ends[i] && (starts[j] >= new_starts[i] && starts[j] <= new_ends[i]))
				{
					new_ends[i] = ends[j];
					ignore[j]   = 1;
				} 
				 /**
				 *    ----------
				 *     -------
				 */
				else if (starts[j] >= new_starts[i] && ends[j] <= new_ends[i])
				{
					ignore[j] = 1;
				} 
				 /**
				 *      ----
				 *     -------
				 */
				else if (new_starts[j] >= starts[i] && new_ends[j] <= ends[i])
				{
					new_starts[i] = starts[j];
					new_ends[i]   = ends[j];
					ignore[j]     = 1;
				}
			}	
		}
	}
	
	tot = 0;
	for(i = 0; i < nseg; i++)
	{
		if (!ignore[i])
		{
			tot += new_ends[i]-new_starts[i]+1;	
		}
	}
	
	GDL_FREE (new_starts);
	GDL_FREE (new_ends);
	GDL_FREE (ignore);
	
	return tot;
}

long 
gdl_expr_feature_size_of_5utr(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		gdl_expr_prbtxset * pts = gene->prbtxsets[feature->idx[1]];
		if (pts->ntx > 1)
		{
			size_t i;
			long * starts, * ends, tot;
			
			starts = GDL_MALLOC (long, pts->ntx);
			ends   = GDL_MALLOC (long, pts->ntx); 
			
			for(i = 0; i < pts->ntx; i++)
			{
				gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
				switch(gene->strand)
				{
					case '+':
						starts[i] = tx->txStart;
						ends[i]    = tx->cdsStart - 1;
						break;
					case '-':
						starts[i] = tx->cdsEnd + 1;
						ends[i]    = tx->txEnd;
						break;
				}
			}
			
			tot = gdl_expr_gene_collapse_segments (starts, ends, pts->ntx);
			
			GDL_FREE (starts);
			GDL_FREE (ends);
			
			return tot;
		}
		else
		{
			switch(gene->strand)
			{
				case '+':
					return gene->transcripts[0]->cdsStart - gene->transcripts[0]->txStart; 		
				case '-':
					return gene->transcripts[0]->txEnd - gene->transcripts[0]->cdsEnd;
			}
		}
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		if (gene->ntx > 1)
		{
			size_t i;
			long tot, * starts, * ends;
			
			starts = GDL_MALLOC (long, gene->ntx);
			ends   = GDL_MALLOC (long, gene->ntx);
			
			for(i = 0; i < gene->ntx; i++)
			{
				gdl_expr_transcript * tx = gene->transcripts[i];
				switch(gene->strand)
				{
					case '+':
						starts[i] = tx->txStart;
						ends[i]    = tx->cdsStart - 1;
						break;
					case '-':
						starts[i] = tx->cdsEnd + 1;
						ends[i]    = tx->txEnd;
						break;
				}
			}
			
			tot = gdl_expr_gene_collapse_segments (starts, ends, gene->ntx);
			
			GDL_FREE (starts);
			GDL_FREE (ends);
			
			return tot;
		}
		else
		{
			switch(gene->strand)
			{
				case '+':
					return gene->transcripts[0]->cdsStart - gene->transcripts[0]->txStart; 		
				case '-':
					return gene->transcripts[0]->txEnd - gene->transcripts[0]->cdsEnd;
			}
		}
	}
	return 0;
}

long
gdl_expr_feature_size_of_3utr(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		gdl_expr_prbtxset * pts = gene->prbtxsets[feature->idx[1]];
		if (pts->ntx > 1)
		{
			size_t i;
			long * starts, * ends, tot;
			
			starts = GDL_MALLOC (long, pts->ntx);
			ends   = GDL_MALLOC (long, pts->ntx); 
			
			for(i = 0; i < pts->ntx; i++)
			{
				gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
				switch(gene->strand)
				{
					case '-':
						starts[i] = tx->txStart;
						ends[i]    = tx->cdsStart - 1;
						break;
					case '+':
						starts[i] = tx->cdsEnd + 1;
						ends[i]    = tx->txEnd;
						break;
				}
			}
			
			tot = gdl_expr_gene_collapse_segments (starts, ends, pts->ntx);
			
			GDL_FREE (starts);
			GDL_FREE (ends);
			
			return tot;
		}
		else
		{
			switch(gene->strand)
			{
				case '-':
					return gene->transcripts[0]->cdsStart - gene->transcripts[0]->txStart; 		
				case '+':
					return gene->transcripts[0]->txEnd - gene->transcripts[0]->cdsEnd;
			}
		}
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		if (gene->ntx > 1)
		{
			size_t i;
			long tot, * starts, * ends;
			
			starts = GDL_MALLOC (long, gene->ntx);
			ends   = GDL_MALLOC (long, gene->ntx);
			
			for(i = 0; i < gene->ntx; i++)
			{
				gdl_expr_transcript * tx = gene->transcripts[i];
				switch(gene->strand)
				{
					case '-':
						starts[i] = tx->txStart;
						ends[i]    = tx->cdsStart - 1;
						break;
					case '+':
						starts[i] = tx->cdsEnd + 1;
						ends[i]    = tx->txEnd;
						break;
				}
			}
			
			tot = gdl_expr_gene_collapse_segments (starts, ends, gene->ntx);
			
			GDL_FREE (starts);
			GDL_FREE (ends);
			
			return tot;
		}
		else
		{
			switch(gene->strand)
			{
				case '-':
					return gene->transcripts[0]->cdsStart - gene->transcripts[0]->txStart; 		
				case '+':
					return gene->transcripts[0]->txEnd - gene->transcripts[0]->cdsEnd;
			}
		}
	}
	return 0;
}

long
gdl_expr_feature_size_of_exon(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	size_t i, j, k;
	
	if (feature->T == gdl_expr_feature_transcript)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		gdl_expr_prbtxset * pts = gene->prbtxsets[feature->idx[1]];
		long * starts, * ends, tot;
		
		for(i = k = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			k += tx->nexon;
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			for(j = 0; j < tx->nexon; j++, k++)
			{
				starts[k] = gene->exons[tx->exon_idx[j]]->start;
				ends[k]    = gene->exons[tx->exon_idx[j]]->end;
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		long tot, * starts, * ends;
		
		for(i = k = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			k += tx->nexon;
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			for(j = 0; j < tx->nexon; j++, k++)
			{
				starts[k] = gene->exons[tx->exon_idx[j]]->start;
				ends[k]    = gene->exons[tx->exon_idx[j]]->end;
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	return 0;
}

long
gdl_expr_feature_size_of_intron(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	size_t i, j, k;
	
	if (feature->T == gdl_expr_feature_transcript)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		gdl_expr_prbtxset * pts = gene->prbtxsets[feature->idx[1]];
		long * starts, * ends, tot;
		
		for(i = k = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			k += tx->nexon - 1;
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			for(j = 0; j < tx->nexon - 1; j++, k++)
			{
				starts[k] = gene->exons[tx->exon_idx[j]]->end+1;
				ends[k]    = gene->exons[tx->exon_idx[j+1]]->start-1;
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		long tot, * starts, * ends;
		
		for(i = k = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			k += tx->nexon - 1;
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			for(j = 0; j < tx->nexon - 1; j++, k++)
			{
				starts[k] = gene->exons[tx->exon_idx[j]]->end+1;
				ends[k]    = gene->exons[tx->exon_idx[j+1]]->start-1;
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	
	return 0;
}

long
gdl_expr_feature_size_of_cds_intron(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	size_t i, j, k;
	
	if (feature->T == gdl_expr_feature_transcript)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		gdl_expr_prbtxset * pts = gene->prbtxsets[feature->idx[1]];
		long * starts, * ends, tot;
		
		for(i = k = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			for(j = 0; j < tx->nexon - 1; j++)
			{
				if (gene->exons[tx->exon_idx[j]]->end >= tx->cdsStart && gene->exons[tx->exon_idx[j]]->end <= tx->cdsEnd)
				{
					if (gene->exons[tx->exon_idx[j+1]]->end <= tx->cdsEnd)
					{
						k++;
					}
				}  
			}
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < pts->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[pts->tx_idx[i]];
			for(j = 0; j < tx->nexon - 1; j++)
			{
				if (gene->exons[tx->exon_idx[j]]->end >= tx->cdsStart && gene->exons[tx->exon_idx[j]]->end <= tx->cdsEnd)
				{
					if (gene->exons[tx->exon_idx[j+1]]->end <= tx->cdsEnd)
					{
						starts[k] = gene->exons[tx->exon_idx[j]]->end+1;
						ends[k]    = gene->exons[tx->exon_idx[j+1]]->start-1;
						k++;
					}
				}
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		gdl_expr_gene * gene = chrom->genes[feature->idx[0]];
		long tot, * starts, * ends;
		
		for(i = k = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			for(j = 0; j < tx->nexon - 1; j++)
			{
				if (gene->exons[tx->exon_idx[j]]->end >= tx->cdsStart && gene->exons[tx->exon_idx[j]]->end <= tx->cdsEnd)
				{
					if (gene->exons[tx->exon_idx[j+1]]->end <= tx->cdsEnd)
					{
						k++;
					}
				}  
			}
		}
		
		starts = GDL_MALLOC (long, k);
		ends   = GDL_MALLOC (long, k); 
		
		for(i = 0; i < gene->ntx; i++)
		{
			gdl_expr_transcript * tx = gene->transcripts[i];
			for(j = 0; j < tx->nexon - 1; j++)
			{
				if (gene->exons[tx->exon_idx[j]]->end >= tx->cdsStart && gene->exons[tx->exon_idx[j]]->end <= tx->cdsEnd)
				{
					if (gene->exons[tx->exon_idx[j+1]]->end <= tx->cdsEnd)
					{
						starts[k] = gene->exons[tx->exon_idx[j]]->end+1;
						ends[k]    = gene->exons[tx->exon_idx[j+1]]->start-1;
						k++;
					}
				}
			}
		}
		
		tot = gdl_expr_gene_collapse_segments (starts, ends, k);
		
		GDL_FREE (starts);
		GDL_FREE (ends);
		
		return tot;
	}
	
	return 0;
}

long
gdl_expr_feature_size_of_non_cds_intron(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long
gdl_expr_feature_size_of_first_intron(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long 
gdl_expr_feature_size_of_last_intron(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long
gdl_expr_feature_size_of_cds_exon(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long
gdl_expr_feature_size_of_non_cds_exon(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long
gdl_expr_feature_size_of_first_exon(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

long
gdl_expr_feature_size_of_last_exon(const gdl_expr_feature * feature, const  gdl_expr_chromosome * chrom)
{
	if (feature->T == gdl_expr_feature_transcript)
	{
		
		
	}
	else if (feature->T == gdl_expr_feature_gene)
	{
		
		
	}
	return 0;
}

/*
 *  expr/chrom.c
 *
 *  $Author: baptiste78 $, $Date: 2012/03/13 22:17:29 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_sort_long.h>
#include <gdl/gdl_clustering.h>
#include <gdl/gdl_expr_chromosome.h>

gdl_expr_chromosome *
gdl_expr_chromosome_alloc (gdl_string * name, const size_t npop)
{
	gdl_expr_chromosome * c;

	c = GDL_CALLOC (gdl_expr_chromosome, 1);

	c->name        = name;
	c->npop        = npop;
	c->pop_sizes   = GDL_CALLOC (size_t, npop);
	c->_gene_dico  = gdl_hashtable_alloc (gdl_hash_default, 0);
	c->_probe_dico = gdl_hashtable_alloc (gdl_hash_default, 0);

	return c;
}

void
gdl_expr_chromosome_free (gdl_expr_chromosome * c)
{
	if (c)
	{
		size_t i;
		gdl_string_free (c->name);
		GDL_FREE (c->pop_sizes);
		for(i = 0; i < c->ngene; i++)
		{
			gdl_expr_gene_free (c->genes[i]);
		}
		GDL_FREE (c->genes);
		for(i = 0; i < c->nprobe; i++)
		{
			gdl_expr_probe_free (c->probes[i], c->npop);
		}
		GDL_FREE (c->probes);
		gdl_hashtable_free (c->_gene_dico);
		gdl_hashtable_free (c->_probe_dico);
		GDL_FREE (c);
	}
}

gdl_expr_chromosome *
gdl_expr_chromosome_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		size_t i, n;
		gdl_string * name;
		gdl_expr_probe ** probes;
		gdl_expr_chromosome * c;

		name = gdl_string_fread(stream);
		GDL_FREAD_STATUS (name!=0, 1, NULL);

		status = fread (&n, sizeof (size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		c = gdl_expr_chromosome_alloc (name, n);

		status = fread (c->pop_sizes, sizeof (size_t), c->npop, stream);
		GDL_FREAD_STATUS (status, c->npop, NULL);

		status = fread (&(c->nprobe), sizeof (size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		c->probes = GDL_MALLOC (gdl_expr_probe *, c->nprobe);
		for (i = 0; i < c->nprobe; i++)
		{
			c->probes[i]      = gdl_expr_probe_fread (stream, c->npop, c->pop_sizes);
			c->probes[i]->idx = i;
			GDL_FREAD_STATUS (c->probes[i]!=0, 1, NULL);
			gdl_hashtable_add (c->_probe_dico, c->probes[i]->name, c->probes[i], 0);
		}

		status = fread (&(c->ngene), sizeof (size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		c->genes = GDL_MALLOC (gdl_expr_gene *, c->ngene);
		for (i = 0; i < c->ngene; i++)
		{
		   c->genes[i] = gdl_expr_gene_fread (stream);
		   GDL_FREAD_STATUS (c->genes[i] != 0, 1, NULL);
		   gdl_hashtable_add (c->_gene_dico, c->genes[i]->name, c->genes[i], 0);
		}

		return c;
	}
	return 0;
}

int
gdl_expr_chromosome_fwrite (FILE * stream, const gdl_expr_chromosome * c)
{
	if (stream && c)
	{
		int status;
		size_t i;

		status = gdl_string_fwrite (stream, c->name);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		status = fwrite (&c->npop, sizeof (size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite (c->pop_sizes, sizeof (size_t), c->npop, stream);
		GDL_FWRITE_STATUS (status, c->npop, 1);
		status = fwrite (&(c->nprobe), sizeof (size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		if (c->nprobe)
		{
			for (i = 0; i < c->nprobe; i++)
			{
				status = gdl_expr_probe_fwrite (stream, c->probes[i], c->npop, c->pop_sizes);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}
		status = fwrite (&(c->ngene), sizeof (size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		if (c->ngene)
		{
			for (i = 0; i < c->ngene; i++)
			{
				status = gdl_expr_gene_fwrite (stream, c->genes[i]);
				GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
			}
		}

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

int
gdl_expr_chromosome_map_probe (gdl_expr_chromosome * c, FILE * logger)
{
	size_t i, j, k, l, t;
	gdl_expr_probe * probe;
	gdl_expr_gene * gene;

	/**
	 * STEP 1 - Map probes on gene structure
	 */
	for(j = 0; j < c->nprobe; j++)
	{
		probe = c->probes[j];
		// Map the probe to its corresponding gene (if exists)
		long probe_min = probe->starts[0];
		long probe_max = probe->ends[c->probes[j]->npos-1];
		for(i = 0; i < c->ngene; i++)
		{
			gene = c->genes[i];
			if (gene->strand != probe->strand)
			{
				continue;
			}
			if (probe_max < gene->txStartMin)
			{
				break;
			}
			// first, does that probe falls into the gene region
			if (probe_min >= gene->txStartMin && probe_max <= gene->txEndMax)
			{
				// this probe can belong to one or several exons of that gene
				// each piece of the probe must be encompassed within exon
				size_t nex_in = probe->nexon;
				for(k = 0; k < probe->npos; k++)
				{
					long start = probe->starts[k];
					long end   = probe->ends[k];
					gdl_boolean out_exon = gdl_true;
					for(l = 0; l < gene->nexon; l++)
					{
						if (start >= gene->exons[l]->start && end <= gene->exons[l]->end)
						{
							// this piece lies within the exon (l) of this gene (i)
							gdl_expr_probe_add_exon (probe, i, l);
							// If no spliced probe, then add it directly to the gene
							if (probe->npos==1 && out_exon) gdl_expr_gene_add_probe (gene, j);
							out_exon = gdl_false;
						}
					}
					if (out_exon && probe->npos > 1)
					{
						// unable to map this spliced probe to that gene
						// try another gene
						// Reset possible matches
						probe->nexon = nex_in;
						break;
					}
				}
				if (probe->npos > 1 && k == probe->npos)
				{
					// Successful, this spliced probe belongs to that gene
					gdl_expr_gene_add_probe (gene, j);
					break; // assume here that a spliced probe can belongs only to a single gene
				}
			}  // if (probe within gene)
		} // loop on genes
		if (!probe->nexon)
		{
			// unable to map this probe to a gene of the chromosome
			// report failure
			if (logger)
			{
				fprintf (logger, "[ WARNING ] Unable to map probe %s on genes of chromosome %s\n", probe->name, c->name);
				fflush (logger);
			}
		}
	}
	/**
	 * STEP 2 - Get the probed exon and transcript sets
	 */
	for(i = 0; i < c->ngene; i++)
	{
		gene = c->genes[i];
		gene->prbtxsets = gdl_expr_prbtxset_create (c, i, gene, &(gene->nprbtxset));
		for(j = 0; j < gene->nprbtxset; j++)
		{
			gdl_expr_prbtxset_set_boundaries (gene, gene->prbtxsets[j]);
		}
		gene->prbexsets = gdl_expr_prbexset_create (c, i, gene, &(gene->nprbexset));
		for(j = 0; j < gene->nprbexset; j++)
		{
			gdl_expr_prbexset_set_boundaries (gene, gene->prbexsets[j]);
		}
	}

	return GDL_SUCCESS;
}

/** \brief Get the number of genes with at least one probe.
 *
 * \param c a gdl_expr_chromosome structure of a given chromosome.
 * \return number of genes with at least one probe as an integer.
 */
int
gdl_exp_chromosome_ngenes_with_probe (gdl_expr_chromosome * c)
{
  int ngenes_with_probe = 0;
  gdl_expr_gene * gene;
  size_t i = 0;
  for(i = 0; i < c->ngene; i++)
  {
    gene = c->genes[i];
    if (gene->nprobe > 0)
    {
      ++ngenes_with_probe;
    }
  }
  return ngenes_with_probe;
}

gdl_expr_prbtxset **
gdl_expr_prbtxset_create (gdl_expr_chromosome * c, const size_t gx, gdl_expr_gene * g, size_t * n)
{
	size_t i, j, k, npts = 0;
	gdl_expr_probe * probe;
	gdl_expr_exon  * exon;
	gdl_expr_prbtxset ** pts = 0;

	if (g->nprobe && g->ntx > 1)
	{
		// First, get the list of probes for each transcript
		size_t ** tx_prb_mat = GDL_MATRIX_ALLOC (size_t, g->ntx, g->nprobe);
		for(i = 0; i < g->nprobe; i++)
		{
			probe = c->probes[g->probe_idx[i]];
			for(j = 0; j < probe->nexon; j++)
			{
				if (probe->gx_idx[j] == gx)
				{
					exon = g->exons[probe->ex_idx[j]];
					for(k = 0; k < exon->ntx; k++)
					{
						tx_prb_mat[exon->tx_idx[k]][i] = 1;
					}
				}
			}
		}
		// Use the matrix to fill the tx -> probe relationship
		for(i = 0; i < g->ntx; i++)
		{
			for(j = 0; j < g->nprobe; j++)
			{
				if (tx_prb_mat[i][j])
				{
					// add this probe to that transcript
					gdl_expr_transcript_add_probe (g->transcripts[i], j);
				}
			}
		}
		if (g->nprobe > 1)
		{
			int ** cidx = GDL_MATRIX_ALLOC (int, g->nprobe, g->nprobe);
			for(i = 0; i < g->nprobe; i++)
			{
				if (cidx[i][0] == -1)
				{
					continue;
				}
				for(j = i + 1; j < g->nprobe; j++)
				{
					// Are columns i,j identical ?
					for(k = 0; k < g->ntx; k++)
					{
						if (tx_prb_mat[k][i] != tx_prb_mat[k][j])
						{
							break;
						}
					}
					if (k == g->ntx)
					{
						cidx[i][++cidx[i][0]] = j;
						cidx[j][0] = -1;
					}
				}
			}
			for(npts = i = 0; i < g->nprobe; i++)
			{
				npts += (cidx[i][0] != -1);
			}
			pts  = GDL_MALLOC (gdl_expr_prbtxset *, npts);
			for(npts = i = 0; i < g->nprobe; i++)
			{
				if (cidx[i][0] == -1)
				{
					continue;
				}
				size_t ntx  = 0;
				size_t np   = cidx[i][0]+1;
				//printf ("CLUSTER %d ==> (np = %d, cx = %d)\n", npts, np, i);
				fflush (stdout);
				for(j = 0; j < g->ntx; j++)
				{
					ntx += tx_prb_mat[j][i];
				}
				pts[npts] = gdl_expr_prbtxset_alloc (ntx, np);
				for(j = k = 0; j < g->ntx; j++)
				{
					if (tx_prb_mat[j][i])
					{
						pts[npts]->tx_idx[k++] = j;
					}
				}
				pts[npts]->probe_idx[0] = i;
				for(j = 1; j < np; j++)
				{
					pts[npts]->probe_idx[j] = cidx[i][j];
					//printf ("MX %d %d\n", j, cidx[i][j]);
				}
				npts++;
			}
			GDL_MATRIX_FREE (cidx, g->nprobe);
		}
		else
		{
			size_t ntx = 0;
			// There is a single probe, so this is easy
			for(j = 0; j < g->ntx; j++)
			{
				ntx += tx_prb_mat[j][0];
			}
			npts   = 1;
			pts    = GDL_MALLOC (gdl_expr_prbtxset *, 1);
			pts[0] = gdl_expr_prbtxset_alloc (ntx, 1);
			pts[0]->probe_idx[0] = 0;
			for(j = k = 0; j < g->ntx; j++)
			{
				if (tx_prb_mat[j][0])
				{
					pts[0]->tx_idx[k++] = j;
				}
			}
		}
	}
	else if (g->nprobe)
	{
		// There is a single transcript, so this is easy
		npts   = 1;
		pts    = GDL_MALLOC (gdl_expr_prbtxset *, 1);
		pts[0] = gdl_expr_prbtxset_alloc (1, g->nprobe);
		pts[0]->tx_idx[0] = 0;
		for(i = 0; i < g->nprobe; i++)
		{
			pts[0]->probe_idx[i] = i;
			// don't forget to add the probe to the transcript
			gdl_expr_transcript_add_probe (g->transcripts[0], i);
		}
	}

	(*n) = npts;

	return pts;
}

int
gdl_expr_chromosome_init_global_gene_measurment (gdl_expr_chromosome * c)
{
	size_t i,j;
	long *s,*e;
	gdl_expr_gene * gene;
	gdl_expr_probe * probe;
	gdl_expr_prbtxset * prbtxset;

	if (c->ngene)
	{
		c->nprobe = c->ngene;
		c->probes = GDL_CALLOC (gdl_expr_probe *, c->ngene);

		for(i = 0; i < c->ngene; i++)
		{
			gene  = c->genes[i];
			s  = GDL_MALLOC (long, 1);
			e  = GDL_MALLOC (long, 1);
			*s = gene->txStartMin;
			*e = gene->txEndMax;
			probe = c->probes[i] = gdl_expr_probe_alloc (gene->name, gene->strand, s, e, 1);
			probe->gx_idx    = GDL_MALLOC (size_t, 1);
			probe->gx_idx[0] = i;
			probe->nexon     = gene->nexon;
			probe->ex_idx    = GDL_MALLOC (size_t, probe->nexon);
			for(j = 0; j < probe->nexon; j++) probe->ex_idx[j]=j;
			probe->nexon       = 0;
			gene->nprobe       = 1;
			gene->nprbtxset    = 1;
			gene->probe_idx    = GDL_MALLOC (size_t, 1);
			gene->probe_idx[0] = i;
			gene->prbtxsets = GDL_MALLOC (gdl_expr_prbtxset *, 1);
			prbtxset = gene->prbtxsets[0] = gdl_expr_prbtxset_alloc (gene->ntx, 1);
			for(j = 0; j < gene->ntx; j++)
			{
				prbtxset->tx_idx[j] = i;
			}
		    prbtxset->probe_idx[0] = 1;
		    prbtxset->ntxStart = gene->ntxStart;
		    prbtxset->ntxEnd   = gene->ntxEnd;
		    prbtxset->txStarts = GDL_MALLOC (size_t, prbtxset->ntxStart);
		    prbtxset->txEnds   = GDL_MALLOC (size_t, prbtxset->ntxEnd);
		    memcpy(prbtxset->txStarts, gene->txStarts, sizeof(size_t)*prbtxset->ntxStart);
		    memcpy(prbtxset->txEnds, gene->txEnds, sizeof(size_t)*prbtxset->ntxEnd);
		    gdl_hashtable_add (c->_probe_dico, c->probes[i]->name, c->probes[i], 0);
		}
	}
}

int
gdl_expr_chromosome_init_global_exon_measurment (gdl_expr_chromosome * c)
{
	size_t i,j,k,l,nexon;
	long *s,*e;
	gdl_expr_gene * gene;
	gdl_expr_exon * exon;
	gdl_expr_probe * probe;
	gdl_expr_prbtxset * prbtxset;
	gdl_string * probe_name;

	if (c->ngene)
	{
		for(nexon = i = 0; i < c->ngene; i++)
		{
			nexon += c->genes[i]->nexon;
		}
		if (!nexon)
		{
			return 0;
		}

		c->nprobe = nexon;

		c->probes = GDL_CALLOC (gdl_expr_probe *, c->nprobe);

		for(i = j = 0; i < c->ngene; i++)
		{
			size_t * exon_probe_idx;

			gene  = c->genes[i];

			gene->nprbtxset = gene->ntx;
			gene->nprobe    = gene->nexon;
			gene->probe_idx = GDL_MALLOC (size_t, gene->nexon);

			exon_probe_idx = GDL_MALLOC (size_t, gene->nexon);

			for(k = 0; k < gene->nexon; k++, j++)
			{
				exon_probe_idx[k] = j;

				exon = gene->exons[k];

				s  = GDL_MALLOC (long, 1);
				e  = GDL_MALLOC (long, 1);

				*s = exon->start;
				*e = exon->end;

				probe_name = gdl_string_sprintf("%s_%s_%c_%ld_%ld", c->name, gene->name, gene->strand, exon->start, exon->end);

				probe = c->probes[j] = gdl_expr_probe_alloc (probe_name, gene->strand, s, e, 1);

				probe->idx       = j;
				probe->nexon     = 1;
				probe->gx_idx    = GDL_MALLOC (size_t, 1);
				probe->ex_idx    = GDL_MALLOC (size_t, 1);
				probe->gx_idx[0] = i;
				probe->ex_idx[0] = k;

				gene->probe_idx[k] = j;

				gdl_hashtable_add (c->_probe_dico, probe_name, c->probes[j], 0);

				gdl_string_free (probe_name);
			}
			// Set the exon/probe indexes for the transcripts
			for(k = 0; k < gene->ntx; k++)
			{
				gene->transcripts[k]->nprobe    = gene->transcripts[k]->nexon;
				gene->transcripts[k]->probe_idx = GDL_MALLOC(size_t, gene->transcripts[k]->nexon);
				for(l = 0; l < gene->transcripts[k]->nexon; l++)
				{
					gene->transcripts[k]->probe_idx[l] = exon_probe_idx[gene->transcripts[k]->exon_idx[l]];
				}
			}
			// Set the probe tx set = same than the transcripts
			gene->prbtxsets = GDL_MALLOC (gdl_expr_prbtxset *, gene->ntx);
			for(k = 0; k < gene->ntx; k++)
			{
				prbtxset = gene->prbtxsets[k] = gdl_expr_prbtxset_alloc (1, gene->transcripts[k]->nexon);
				prbtxset->tx_idx[0] = k;
				for(l = 0; l < gene->transcripts[k]->nexon; l++)
				{
					prbtxset->probe_idx[l] = gene->transcripts[k]->probe_idx[l];
				}
				prbtxset->ntxStart = 1;
				prbtxset->ntxEnd   = 1;
				prbtxset->txStarts = GDL_MALLOC (size_t, prbtxset->ntxStart);
				prbtxset->txEnds   = GDL_MALLOC (size_t, prbtxset->ntxEnd);
				*(prbtxset->txStarts) = gene->transcripts[k]->txStart;
				*(prbtxset->txEnds)   = gene->transcripts[k]->txEnd;
			}
			GDL_FREE (exon_probe_idx);
		}
	}
}

int
gdl_expr_chromosome_create_prbwindow (gdl_expr_chromosome * c, const long window, FILE * logger)
{
	size_t i, j, k, l;
	gdl_expr_probe * probe;
	gdl_expr_gene * gene;

	/**
	 * STEP 1 - Map probes on gene
	 */
	for(j = 0; j < c->nprobe; j++)
	{
		probe = c->probes[j];
		// Map the probe to its corresponding gene (if exists)
		long probe_min = probe->starts[0];
		long probe_max = probe->ends[c->probes[j]->npos-1];
		for(i = 0; i < c->ngene; i++)
		{
			gene = c->genes[i];
//			if (gene->strand != probe->strand)
//			{
//				continue;
//			}
			// first, does that probe falls into the gene region
			for(k = 0; k < gene->ntx; k++)
			{
				gdl_expr_transcript * transcript = gene->transcripts[k];
				if (gene->strand == '+')
				{
					if (probe_min >= transcript->txStart - window && probe_max <= transcript->txStart + window)
					{
						// Successful, this probe belongs to that gene
						gdl_expr_gene_add_probe (gene, j);
						if (logger)
						{
							fprintf (logger, "prbtsswindow %s %c %s %ld %ld %s %ld %ld\n", gene->name, gene->strand, transcript->name, transcript->txStart, transcript->txEnd, probe->name, probe_min, probe_max);
							fflush (logger);
						}
						break;
					}
				}
				else
				{
					if (probe_min >= transcript->txEnd - window && probe_max <= transcript->txEnd + window)
					{
						// Successful, this probe belongs to that gene
						gdl_expr_gene_add_probe (gene, j);
						if (logger)
						{
							fprintf (logger, "prbtsswindow %s %c %s %ld %ld %s %ld %ld\n", gene->name, gene->strand, transcript->name, transcript->txStart, transcript->txEnd, probe->name, probe_min, probe_max);
							fflush (logger);
						}
						break;
					}
				}
			}
			if (k < gene->ntx)
			{
				break;
			}
		} // loop on genes
		if (i == c->ngene)
		{
			// unable to map this probe to a gene of the chromosome
			// report failure
			if (logger)
			{
				fprintf (logger, "[ WARNING ] Unable to map probe %s on genes of chromosome %s\n", probe->name, c->name);
				fflush (logger);
			}
		}
	}
}

int
gdl_expr_chromosome_fprintf (const gdl_expr_chromosome * c, gdl_string ** pop_names, const gdl_string * output)
{
	size_t i,j,k;
	gdl_string * file;
	FILE * stream;

	// Expression Measurement
	for(i = 0; i < c->npop; i++)
	{
		if (pop_names)
		{
			file   = gdl_string_sprintf ("%s/%s/%s.exp", output, pop_names[i], c->name);
		}
		else
		{
			file   = gdl_string_sprintf ("%s/Pop_%d/%s.exp", output, i+1, c->name);
		}
		stream = gdl_fileopen (file, "w");
		// .exp pop( probe x sample )
		for(j = 0; j < c->nprobe; j++)
		{
			gdl_expr_probe * probe = c->probes[j];
			if (probe->data)
			{
				fprintf (stream, "%s", probe->name);
				for(k = 0; k < c->pop_sizes[i]; k++)
				{
					if (!gdl_isnan (probe->data[i][k]))
					{
						fprintf (stream, " %g", probe->data[i][k]);
					}
					else
					{
						fprintf (stream, " NA");
					}
				}
				fprintf (stream, "\n");
				fflush (stream);
			}
		}
		gdl_fileclose (file, stream);
		gdl_string_free (file);
	}
	// Probe Annotation
	file   = gdl_string_sprintf ("%s/Extra/%s.prb", output, c->name);
	stream = gdl_fileopen (file, "w");
	for(i = 0; i < c->nprobe; i++)
	{
		gdl_expr_probe * probe = c->probes[i];
		if (probe->data)
		{
			fprintf (stream, "%s %c ", probe->name, probe->strand);
			for(j = 0; j < probe->npos; j++)
			{
				fprintf (stream, "%ld,", probe->starts[j]);
			}
			fprintf (stream, " ");
			for(j = 0; j < probe->npos; j++)
			{
				fprintf (stream, "%ld,", probe->ends[j]);
			}
			fprintf (stream, "\n");
			fflush (stream);
		}
	}
	gdl_fileclose (file, stream);
	gdl_string_free (file);
	// Gene Annotation
	file   = gdl_string_sprintf ("%s/Extra/%s.txtb", output, c->name);
	stream = gdl_fileopen (file, "w");
	for(i = 0; i < c->ngene; i++)
	{
		gdl_expr_gene * gene = c->genes[i];
		for(j = 0; j < gene->ntx; j++)
		{
			gdl_expr_transcript * tx = gene->transcripts[j];
			fprintf (stream, "%s %s %c", gene->name, tx->name, gene->strand);
			fprintf (stream, " %ld %ld", tx->txStart, tx->txEnd);
			fprintf (stream, " %ld %ld", tx->cdsStart, tx->cdsEnd);
			fprintf (stream, " %ld ", tx->nexon);
			for(k = 0; k < tx->nexon; k++)
			{
				fprintf (stream, "%ld,", gene->exons[tx->exon_idx[k]]->start);
			}
			fprintf (stream, " ", tx->nexon);
			for(k = 0; k < tx->nexon; k++)
			{
				fprintf (stream, "%ld,", gene->exons[tx->exon_idx[k]]->end);
			}
			fprintf (stream, "\n");
			fflush (stream);
		}
	}
	gdl_fileclose (file, stream);
	gdl_string_free (file);
}

//int
//gdl_expr_chromosome_create_meta_exon (gdl_expr_chromosome * c, FILE * logger)
//{
//	size_t i, j, k, l, t;
//	gdl_expr_gene * gene;
//
//	for(i = 0; i < c->ngene; i++)
//	{
//		gene = c->genes[i];
//		gdl_clustering_workspace * exon_cluster = gdl_clustering_workspace_alloc (gene->nexon);
//
//		for(j = 0; j < gene->nexon; j++)
//		{
//			for(k = j; k < gene->nexon; k++)
//			{
//				if ((gene->exons[j]->start >= gene->exons[k]->start && gene->exons[j]->end <= gene->exons[k]->end)
//				    || (gene->exons[k]->start >= gene->exons[j]->start && gene->exons[k]->end <= gene->exons[j]->end)
//					|| (gene->exons[j]->start < gene->exons[k]->start && (gene->exons[j]->end >= gene->exons[k]->start && gene->exons[j]->end <= gene->exons[k]->end))
//					|| (gene->exons[k]->start < gene->exons[j]->start && (gene->exons[k]->end >= gene->exons[j]->start && gene->exons[k]->end <= gene->exons[j]->end))
//				    )
//				{
//					gdl_clustering_workspace_set (exon_cluster, j, k);
//				}
//			}
//		}
//		gdl_clustering * meta_cluster = gdl_clustering_workspace_done (exon_cluster);
//
//		gdl_clustering_workspace_free (exon_cluster);
//
//		size_t   nmeta_exon = gdl_clustering_nclust (meta_cluster);
//		size_t ** meta_exon = GDL_MALLOC(size_t *, nmeta_exon);
//		for(j = 0; j < nmeta_cluster; j++)
//		{
//			size_t ne = gdl_clustering_clust_size (meta_cluster, j);
//			meta_exon[j]    = GDL_MALLOC (size_t, ne+1);
//			meta_exon[j][0] = ne;
//			meta_exon[j][1] = gdl_clustering_clust_idx (meta_cluster, j);
//			memcpy(meta_exon[j]+2, gdl_clustering_clust_members(meta_cluster, j), sizeof(size_t)*ne);
//		}
//		gdl_clustering_free (meta_cluster);
//
//}

gdl_expr_prbexset **
gdl_expr_prbexset_create (gdl_expr_chromosome * c, const size_t gx, gdl_expr_gene * g, size_t * n)
{
	size_t i, j, k, npts = 0;
	gdl_expr_probe * probe;
	gdl_expr_exon  * exon;
	gdl_expr_prbexset ** pts = 0;

	if (g->nprobe && g->nexon > 1)
	{
		// First, get the list of probes for each exon
		size_t ** ex_prb_mat = GDL_MATRIX_ALLOC (size_t, g->nexon, g->nprobe);
		for(i = 0; i < g->nprobe; i++)
		{
			probe = c->probes[g->probe_idx[i]];
			for(j = 0; j < probe->nexon; j++)
			{
				if (probe->gx_idx[j]==gx)
				{
					ex_prb_mat[probe->ex_idx[j]][i] = 1;
				}
			}
		}
		// Use the matrix to fill the ex -> probe relationship
//		for(i = 0; i < g->nexon; i++)
//		{
//			for(j = 0; j < g->nprobe; j++)
//			{
//				if (ex_prb_mat[i][j])
//				{
//					gdl_expr_exon_add_probe (g->exons[i], j);
//				}
//			}
//		}
		if (g->nprobe > 1)
		{
			int ** cidx = GDL_MATRIX_ALLOC (int, g->nprobe, g->nprobe);
			for(i = 0; i < g->nprobe; i++)
			{
				if (cidx[i][0] == -1)
				{
					continue;
				}
				for(j = i + 1; j < g->nprobe; j++)
				{
					// Are columns i,j identical ?
					for(k = 0; k < g->nexon; k++)
					{
						if (ex_prb_mat[k][i] != ex_prb_mat[k][j])
						{
							break;
						}
					}
					if (k == g->nexon)
					{
						cidx[i][++cidx[i][0]] = j;
						cidx[j][0] = -1;
					}
				}
			}
			for(npts = i = 0; i < g->nprobe; i++)
			{
				npts += (cidx[i][0] != -1);
			}
			pts  = GDL_MALLOC (gdl_expr_prbexset *, npts);
			for(npts = i = 0; i < g->nprobe; i++)
			{
				if (cidx[i][0] == -1)
				{
					continue;
				}
				size_t ntx  = 0;
				size_t np   = cidx[i][0]+1;
				//printf ("CLUSTER %d ==> (np = %d, cx = %d)\n", npts, np, i);
				//fflush (stdout);
				for(j = 0; j < g->nexon; j++)
				{
					ntx += ex_prb_mat[j][i];
				}
				pts[npts] = gdl_expr_prbexset_alloc (ntx, np);
				for(j = k = 0; j < g->nexon; j++)
				{
					if (ex_prb_mat[j][i])
					{
						pts[npts]->ex_idx[k++] = j;
					}
				}
				pts[npts]->probe_idx[0] = i;
				for(j = 1; j < np; j++)
				{
					pts[npts]->probe_idx[j] = cidx[i][j];
				}
				npts++;
			}
			GDL_MATRIX_FREE (cidx, g->nprobe);
		}
		else
		{
			size_t ntx = 0;
			// There is a single probe, so this is easy
			for(j = 0; j < g->nexon; j++)
			{
				ntx += ex_prb_mat[j][0];
			}
			npts   = 1;
			pts    = GDL_MALLOC (gdl_expr_prbexset *, 1);
			pts[0] = gdl_expr_prbexset_alloc (ntx, 1);
			pts[0]->probe_idx[0] = 0;
			for(j = k = 0; j < g->nexon; j++)
			{
				if (ex_prb_mat[j][0])
				{
					pts[0]->ex_idx[k++] = j;
				}
			}
		}
	}
	else if (g->nprobe)
	{
		// There is a single exon, so this is easy
		npts   = 1;
		pts    = GDL_MALLOC (gdl_expr_prbexset *, 1);
		pts[0] = gdl_expr_prbexset_alloc (1, g->nprobe);
		pts[0]->ex_idx[0] = 0;
		for(i = 0; i < g->nprobe; i++)
		{
			pts[0]->probe_idx[i] = i;
		}
	}

	(*n) = npts;

	return pts;
}

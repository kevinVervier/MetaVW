/*
 *  expr/prbexset.c
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_sort.h>
#include <gdl/gdl_statistics.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_specfunc.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_expr_prbexset.h>

gdl_expr_prbexset *
gdl_expr_prbexset_alloc (const size_t ntx, const size_t nprobe)
{
	gdl_expr_prbexset * p;

	p = GDL_CALLOC (gdl_expr_prbexset, 1);

	p->nex    = ntx;
	p->nprobe = nprobe;

	if (ntx)
	{
		p->ex_idx = GDL_CALLOC (size_t, ntx);
	}
	if (nprobe)
	{
		p->probe_idx = GDL_CALLOC (size_t, nprobe);
	}

	return p;
}

void
gdl_expr_prbexset_free (gdl_expr_prbexset * p)
{
	if (p)
	{
		GDL_FREE (p->ex_idx);
		GDL_FREE (p->probe_idx);
		GDL_FREE (p->exStarts);
		GDL_FREE (p->exEnds);
		GDL_FREE (p);
	}
}


gdl_expr_prbexset *
gdl_expr_prbexset_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		gdl_expr_prbexset * p;

		p = GDL_CALLOC (gdl_expr_prbexset, 1);

		status = fread(&(p->nex), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->nprobe), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->nexStart), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		status = fread(&(p->nexEnd), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);

		if (p->nex)
		{
			p->ex_idx = GDL_MALLOC (size_t, p->nex);
			status = fread(p->ex_idx, sizeof(size_t), p->nex, stream);
			GDL_FREAD_STATUS (status, p->nex, NULL);
		}
		if (p->nprobe)
		{
			p->probe_idx = GDL_MALLOC (size_t, p->nprobe);
			status = fread(p->probe_idx, sizeof(size_t), p->nprobe, stream);
			GDL_FREAD_STATUS (status, p->nprobe, NULL);
		}
		if (p->nexStart)
		{
			p->exStarts = GDL_MALLOC (size_t, p->nexStart);
			status = fread(p->exStarts, sizeof(size_t), p->nexStart, stream);
			GDL_FREAD_STATUS (status, p->nexStart, NULL);
		}
		if (p->nexEnd)
		{
			p->exEnds = GDL_MALLOC (size_t, p->nexEnd);
			status = fread(p->exEnds, sizeof(size_t), p->nexEnd, stream);
			GDL_FREAD_STATUS (status, p->nexEnd, NULL);
		}

		return p;
	}
	return 0;
}

int
gdl_expr_prbexset_fwrite (FILE * stream, const gdl_expr_prbexset * p)
{
	if (stream && p)
	{
		int status;

		status = fwrite(&(p->nex), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->nprobe), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->nexStart), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		status = fwrite(&(p->nexEnd), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);

		if (p->nex)
		{
			status = fwrite(p->ex_idx, sizeof(size_t), p->nex, stream);
			GDL_FWRITE_STATUS (status, p->nex, 1);
		}
		if (p->nprobe)
		{
			status = fwrite(p->probe_idx, sizeof(size_t), p->nprobe, stream);
			GDL_FWRITE_STATUS (status, p->nprobe, 1);
		}
		if (p->nexStart)
		{
			status = fwrite(p->exStarts, sizeof(size_t), p->nexStart, stream);
			GDL_FWRITE_STATUS (status, p->nexStart, 1);
		}
		if (p->nexEnd)
		{
			status = fwrite(p->exEnds, sizeof(size_t), p->nexEnd, stream);
			GDL_FWRITE_STATUS (status, p->nexEnd, 1);
		}

		return GDL_SUCCESS;
	}
	return GDL_EINVAL;
}

/*
 *  expr/gdl_expr_feature_cis.h
 *
 *  $Author: tflutre $, $Date: 2011/07/18 00:39:01 $, $Revision: 1.3 $
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, University of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_FEATURE_CIS_H__
#define __GDL_EXPR_FEATURE_CIS_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_bayesian_regression.h>
#include <gdl/gdl_expr_feature.h>

__BEGIN_DECLS

/** \brief Variant-level record aggregating results of regression.
 */
typedef struct
{
  double * bf;   // Bayes factors
  double pval;   // P-value (corresponding to a)
  double a;      // estimate of the additive genetic effect of the variant
} gdl_expr_feature_cis_snp;

gdl_expr_feature_cis_snp * gdl_expr_feature_cis_snp_alloc (const size_t grid_size);
void gdl_expr_feature_cis_snp_free (gdl_expr_feature_cis_snp * r);
gdl_expr_feature_cis_snp * gdl_expr_feature_cis_snp_fread (FILE * stream, const size_t grid_size);
int gdl_expr_feature_cis_snp_fwrite (FILE * stream, const gdl_expr_feature_cis_snp * r, const size_t grid_size);

/** \brief Feature-level record aggregating variants.
 */
typedef struct
{
  size_t size;
  size_t snp_from;
  size_t snp_to;
  gdl_expr_feature_cis_snp ** snps;
} gdl_expr_feature_cis;

gdl_expr_feature_cis * gdl_expr_feature_cis_alloc (const int snp_from, const int snp_to);
void gdl_expr_feature_cis_free (gdl_expr_feature_cis * r);
gdl_expr_feature_cis * gdl_expr_feature_cis_fread (FILE * stream, const size_t grid_size);
int gdl_expr_feature_cis_fwrite (FILE * stream, const gdl_expr_feature_cis * r, const size_t grid_size);

/** \brief Chromosome-level record aggregating features.
 */
typedef struct
{
  size_t size;
  gdl_expr_feature_cis ** features;
} gdl_expr_feature_cis_chromosome;

gdl_expr_feature_cis_chromosome * gdl_expr_feature_cis_chromosome_alloc (const size_t size);
void gdl_expr_feature_cis_chromosome_free (gdl_expr_feature_cis_chromosome * r);
gdl_expr_feature_cis_chromosome * gdl_expr_feature_cis_chromosome_fread (FILE * stream, const size_t grid_size);
int gdl_expr_feature_cis_chromosome_fwrite (FILE * stream, const gdl_expr_feature_cis_chromosome * r, const size_t grid_size);

/** \brief Genome-level record aggregating chromosomes.
 */
typedef struct
{
  const gdl_expr_feature_type * T;
  size_t nchrom;
  gdl_string * dbdir;
  gdl_bayreg_model * model;
  gdl_string ** chroms;
} gdl_expr_feature_cis_genome;

gdl_expr_feature_cis_genome * gdl_expr_feature_cis_genome_alloc (const gdl_string * dir,const gdl_expr_feature_genome * f_db, const gdl_bayreg_model * model);
void gdl_expr_feature_cis_genome_free (gdl_expr_feature_cis_genome * r);
int gdl_expr_feature_cis_genome_set (gdl_expr_feature_cis_genome * g, size_t i, const gdl_string * name, const gdl_expr_feature_cis_chromosome * chrom);
gdl_expr_feature_cis_chromosome * gdl_expr_feature_cis_genome_get (const gdl_expr_feature_cis_genome * g, const size_t i);
gdl_expr_feature_cis_genome * gdl_expr_feature_cis_genome_fread (FILE * stream);
int gdl_expr_feature_cis_genome_fwrite (FILE * stream, const gdl_expr_feature_cis_genome * r);

__END_DECLS

#endif

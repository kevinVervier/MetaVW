/*
 *  expr/gdl_expr_gene.h
 *
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:22 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 *
 *  Copyright (C) 2009  Jean-Baptiste Veyrieras, Univeristy of Chicago
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 */
#ifndef __GDL_EXPR_GENE_H__
#define __GDL_EXPR_GENE_H__

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_expr_exon.h>
#include <gdl/gdl_expr_probe.h>
#include <gdl/gdl_expr_transcript.h>
#include <gdl/gdl_expr_prbtxset.h>
#include <gdl/gdl_expr_prbexset.h>

__BEGIN_DECLS

/*! \struct gdl_expr_gene
 *  \brief A gene
 *
 *  A gene can contains several exons and each exon can
 *  belong to different transcripts. For each exon we
 *  can have either counts from RNA-seq or micro-array
 *  probes within the exons.
 *
 *  Note that this structure can also handle expression
 *  data from non-coding elements (the gene denomination is
 *  here is restrictive in meaning but not in practice)
 */
struct gdl_expr_gene
{
	gdl_string * name;              		/**< The name of the gene      */
	unsigned char strand;					/**< The strand of the gene    */
	size_t nexon;                   		/**< The number of exons       */
	size_t nprobe;							/**< The number of probes      */
	size_t nprbtxset;				        /**< The number of probed transcript sets */
	size_t nprbexset;				        /**< The number of probed exon sets */
	size_t ntx;								/**< The number of transcripts (same strand as the gene) */
	size_t ntxStart;						/**< The number of different transcript starts (strand == '+' = TSS otherwise TES) */
	size_t ntxEnd;				    		/**< The number of different transcript ends (strand == '+' = TES otherwise TSS) */
	size_t * txStarts;						/**< The transcript starts */
	size_t * txEnds;						/**< The transcript ends   */
	size_t txStartMin;						/**< The most 5' transcript start  */
	size_t txEndMax;						/**< The most 3' transcript end    */
	gdl_expr_exon  ** exons;      		    /**< The exons for that gene  */
	gdl_expr_transcript  ** transcripts;	/**< The transcripts for that gene */
	gdl_expr_prbtxset    ** prbtxsets;	    /**< The probed transcript sets for that gene  */
	gdl_expr_prbexset    ** prbexsets;	    /**< The probed exon sets for that gene  */
	size_t * probe_idx;     		    	/**< The indexes of the probe within that gene */
	// utilities
	unsigned char ignore;
	unsigned char iscoding;
};

/*! \typedef gdl_expr_gene
 *  \brief A gene
 */
typedef struct gdl_expr_gene gdl_expr_gene;

gdl_expr_gene * gdl_expr_gene_alloc (const gdl_string * name, const unsigned char strand);
void gdl_expr_gene_free (gdl_expr_gene * g);
gdl_expr_gene * gdl_expr_gene_clone (const gdl_expr_gene * gene);
gdl_expr_gene * gdl_expr_gene_fread (FILE * stream);
int gdl_expr_gene_fwrite (FILE * stream, const gdl_expr_gene * g);

size_t * gdl_expr_gene_add_exons(gdl_expr_gene * gene, const size_t tx, const size_t exonStarts[], const size_t exonEnds[], const size_t nexon);
size_t gdl_expr_gene_add_probe (gdl_expr_gene * p, const size_t e);
void gdl_expr_gene_set_boundaries (gdl_expr_gene * g);
void gdl_expr_prbtxset_set_boundaries (const gdl_expr_gene * g, gdl_expr_prbtxset * p);
void gdl_expr_prbexset_set_boundaries (const gdl_expr_gene * g, gdl_expr_prbexset * p); // TODO

// utilities to test if a position is in a peculiar part of a gene trnascript
size_t * gdl_expr_gene_which_exons (const gdl_expr_gene * gene, const long position, size_t * nexon);
gdl_boolean gdl_expr_gene_is_within(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_5utr(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_3utr(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_cds_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_non_cds_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_first_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_last_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_cds_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_non_cds_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_first_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_last_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position);
gdl_boolean gdl_expr_gene_is_in_splice_site(const gdl_expr_gene * gene, const gdl_expr_transcript * tx, const long position);

double gdl_expr_gene_is_del_within(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_5utr(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_3utr(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_cds_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_non_cds_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_first_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_last_intron(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_cds_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_non_cds_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_first_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);
double gdl_expr_gene_is_del_last_exon(const gdl_expr_gene * g, const gdl_expr_transcript * tx, const long position, const long size);

__END_DECLS

#endif

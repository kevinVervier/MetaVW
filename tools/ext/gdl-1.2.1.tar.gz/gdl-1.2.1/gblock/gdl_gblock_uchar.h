/*  
 * 	gblock/gdl_gblock_int.h 
 *  
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:26 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */

#include <gdl/gdl_common.h>

#ifndef __GDL_GBLOCK_UCHAR_H__
#define __GDL_GBLOCK_UCHAR_H__ 

__BEGIN_DECLS

typedef struct 
{
	size_t size;
	size_t p;
	size_t *dim;
	size_t *_ssize;
	unsigned char * data;
} gdl_block_uchar;

typedef gdl_block_uchar * gdl_block_uchar_ptr;

typedef struct 
{
	size_t size;
	size_t p;
	size_t *dim;
	size_t **nested;
	size_t *_sizes;
	size_t *_ssize;
	size_t **_nssize;
	unsigned char *data;
} gdl_nblock_uchar;

typedef gdl_nblock_uchar * gdl_nblock_uchar_ptr;

typedef struct 
{
	size_t size;
	size_t p;
	size_t p1;
	size_t p2;
	size_t *dim;
	size_t **nested;
	size_t *_sizes;
	size_t *_ssize;
	size_t **_nssize;
	unsigned char *data;
} gdl_hnblock_uchar;

typedef gdl_hnblock_uchar * gdl_hnblock_uchar_ptr;

gdl_block_uchar *gdl_block_uchar_alloc  (const size_t p, const size_t *dim);
gdl_block_uchar *gdl_block_uchar_alloc2 (const size_t p, ...);
void gdl_block_uchar_free (gdl_block_uchar * b);
unsigned char gdl_block_uchar_get (const gdl_block_uchar * b, ...);
void gdl_block_uchar_set (gdl_block_uchar * b, ...);
gdl_block_uchar *gdl_block_uchar_fread (FILE * stream);
int gdl_block_uchar_fwrite (FILE * stream, const gdl_block_uchar *b);

gdl_nblock_uchar *gdl_nblock_uchar_alloc (const size_t size, const size_t *dim, size_t ** nested);
void gdl_nblock_uchar_free (gdl_nblock_uchar * b);
unsigned char gdl_nblock_uchar_get (const gdl_nblock_uchar * b, ...);
void gdl_nblock_uchar_set (gdl_nblock_uchar * b, ...);
gdl_nblock_uchar *gdl_nblock_uchar_fread (FILE * stream);
int gdl_nblock_uchar_fwrite (FILE * stream, const gdl_nblock_uchar *b);

gdl_hnblock_uchar *gdl_hnblock_uchar_alloc (const size_t p1, const size_t p2, const size_t *dim, size_t **nested);
void gdl_hnblock_uchar_free (gdl_hnblock_uchar * b);
unsigned char gdl_hnblock_uchar_get (const gdl_hnblock_uchar * b, ...);
void gdl_hnblock_uchar_set (gdl_hnblock_uchar * b, ...);
gdl_hnblock_uchar *gdl_hnblock_uchar_fread (FILE * stream);
int gdl_hnblock_uchar_fwrite (FILE * stream, const gdl_hnblock_uchar *b);


__END_DECLS

#endif /* __GDL_GBLOCK_INT_H__ */


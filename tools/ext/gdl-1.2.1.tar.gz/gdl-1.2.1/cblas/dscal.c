#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

void
cblas_dscal (const int N, const double alpha, double *X, const int incX)
{
#define BASE double
#include "source_scal_r.h"
#undef BASE
}

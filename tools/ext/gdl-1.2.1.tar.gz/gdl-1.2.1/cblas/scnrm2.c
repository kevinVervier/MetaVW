#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

float
cblas_scnrm2 (const int N, const void *X, const int incX)
{
#define BASE float
#include "source_nrm2_c.h"
#undef BASE
}

#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

void
cblas_srotg (float *a, float *b, float *c, float *s)
{
#define BASE float
#include "source_rotg.h"
#undef BASE
}

#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

void
cblas_scopy (const int N, const float *X, const int incX, float *Y,
             const int incY)
{
#define BASE float
#include "source_copy_r.h"
#undef BASE
}

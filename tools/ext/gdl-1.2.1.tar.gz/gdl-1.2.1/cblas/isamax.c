#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

CBLAS_INDEX
cblas_isamax (const int N, const float *X, const int incX)
{
#define BASE float
#include "source_iamax_r.h"
#undef BASE
}

#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

void
cblas_zscal (const int N, const void *alpha, void *X, const int incX)
{
#define BASE double
#include "source_scal_c.h"
#undef BASE
}

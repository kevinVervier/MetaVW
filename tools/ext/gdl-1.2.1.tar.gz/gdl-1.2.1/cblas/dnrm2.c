#include <gdl/gdl_math.h>
#include <gdl/gdl_cblas.h>
#include "cblas.h"

double
cblas_dnrm2 (const int N, const double *X, const int incX)
{
#define BASE double
#include "source_nrm2_r.h"
#undef BASE
}

/*  
 * 	entity/allele.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:21 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_entity.h>
#include <gdl/gdl_allele.h>

gdl_allele *
gdl_allele_alloc (void)
{
	return gdl_entity_alloc (GDL_ALLELE);	
}

gdl_allele *
gdl_allele_new (const char * name)
{
	gdl_allele * a = gdl_entity_alloc (GDL_ALLELE);
	gdl_entity_set_name (a, name);
	return a;
}

void
gdl_allele_free (gdl_allele * va)
{
	gdl_entity_free (va);
}

static const gdl_entity_type _gdl_allele_type =
{
	0,
	"AL",
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};

static const gdl_entity_type _GDL_ALLELE_MISSING =
{
	0,
	"AM",
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};

static const gdl_entity_type _GDL_ALLELE_RECESSIVE =
{
	0,
	"AR",
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};

const gdl_entity_type * GDL_ALLELE = &_gdl_allele_type;
const gdl_entity_type * GDL_ALLELE_MISSING = &_GDL_ALLELE_MISSING;
const gdl_entity_type * GDL_ALLELE_RECESSIVE = &_GDL_ALLELE_RECESSIVE;

static const gdl_allele _allele_missing =
{
	&_GDL_ALLELE_MISSING,
	NULL,
	0,
	NULL,
	NULL	
};

const gdl_allele * gdl_allele_missing = &_allele_missing;

static const gdl_allele _allele_recessive =
{
	&_GDL_ALLELE_RECESSIVE,
	NULL,
	0,
	NULL,
	NULL
};

const gdl_allele * gdl_allele_recessive = &_allele_recessive;


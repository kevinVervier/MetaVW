/*  
 *  fview/wtype.c
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:21 $, $Version$
 *
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
 
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_fview_writer.h>

gdl_fview_writer_type *
gdl_fview_writer_type_new (const gdl_fview_writer_type * type)
{
	if (type)
	{
		gdl_fview_writer_type * clone;
		
		clone = GDL_CALLOC (gdl_fview_writer_type, 1);
		
		clone->missing   = gdl_string_clone (type->missing);
		clone->write     = type->write;
		
		return clone;
	}
}

void
gdl_fview_writer_type_free (gdl_fview_writer_type * type)
{
	if (type)
	{
		gdl_string_free (type->missing);		
		GDL_FREE (type);
	}
}

void
gdl_fview_writer_type_missing (gdl_fview_writer_type * type, gdl_string * missing)
{
	gdl_string_free (type->missing);
	type->missing = gdl_string_clone (missing);
}

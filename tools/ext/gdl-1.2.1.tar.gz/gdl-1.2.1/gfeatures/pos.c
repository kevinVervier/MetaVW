/**
 *  gfeatures/pos.c
 * 
 * Copyright (C) 2008 Jean-Baptiste Veyrieras
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */
 
#include <stdlib.h>
#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_io.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_list.h> 
#include <gdl/gdl_hash.h>
#include <gdl/gdl_math.h> 
#include <gdl/gdl_sort_long.h> 
#include <gdl/gdl_gfeatures.h>
#include <gdl/gdl_gfeatures_pos.h>


static gdl_gfeatures_landmark ** 
gdl_gfeatures_pos_alloc (const gdl_string * file, size_t * nlandmark, gdl_dictionary * dico)
{
	FILE * stream;
	
	stream = gdl_fileopen (file, "r");
	
	if (!stream)
	{
		return 0;
	}
	else
	{
		gdl_gfeatures_landmark ** landmarks;
		gdl_gfeatures_landmark * landmark;
		gdl_gfeatures_pos_record  * rec;
		gdl_hashtable * buffer;
		size_t i,j,k,l,n,m,o,p;
		gdl_string * line = 0, * tok, * key, * value;
		
		buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
		l = 0;
		while(gdl_getline (&line, &n, stream)!=-1)
		{
			if (line[0] == '#')
			{
				gdl_string_free (line);line=0;
				continue;
			}
			l++;
			i=j=k=0;
			tok = gdl_string_next_token (line, n, &i, &j);
			landmark = gdl_hashtable_lookup (buffer, tok);
			if (!landmark)
			{
				landmark = gdl_gfeatures_landmark_alloc (tok);
				landmark->_rec_buffer    = gdl_list_alloc (gdl_list_default);
				landmark->_rec_id_buffer = gdl_hashtable_alloc (gdl_hash_default, 0);
				gdl_hashtable_add (buffer, tok, landmark, 0); 
			}
			gdl_string_free (tok);
			rec = GDL_MALLOC (gdl_gfeatures_pos_record, 1);
			tok = gdl_string_next_token (line, n, &i, &j);
			rec->position = atol (tok);
			gdl_string_free (tok);
			gdl_list_push_back (landmark->_rec_buffer, rec, 0);
			gdl_string_free (line);line=0;
		}
		
		// Now, re-format the buffered landmarks
		 
		{
			if ((*nlandmark=gdl_hashtable_size (buffer))!=0)
			{
				i=0;
				gdl_list_itr * ritr;
				gdl_hashtable_itr * itr = gdl_hashtable_iterator (buffer);
				
				landmarks = GDL_MALLOC (gdl_gfeatures_landmark *, *nlandmark);
				do
				{
					size_t * idx;
					long * pos;
					void ** tmp;
					landmarks[i]         = gdl_hashtable_iterator_value (itr);
					landmarks[i]->size   = gdl_list_size (landmarks[i]->_rec_buffer);
					landmarks[i]->records= GDL_MALLOC (void *, landmarks[i]->size);
					pos = GDL_MALLOC (long, landmarks[i]->size); 
					ritr = gdl_list_iterator_front (landmarks[i]->_rec_buffer);
					j = 0;
					do
					{
						landmarks[i]->records[j]=gdl_list_iterator_value (ritr);
						gdl_gfeatures_pos_record  * rec = (gdl_gfeatures_pos_record  *)landmarks[i]->records[j]; 
						pos[j]=rec->position;
						j++;						
					}
					while (gdl_list_iterator_next (ritr));
					gdl_list_iterator_free (ritr);
					// clean the buffers
					gdl_list_free (landmarks[i]->_rec_buffer);landmarks[i]->_rec_buffer=0;
					gdl_hashtable_free (landmarks[i]->_rec_id_buffer);landmarks[i]->_rec_id_buffer=0;
					// sort the records
					idx = GDL_MALLOC (size_t, landmarks[i]->size);
					gdl_sort_long_index (idx, pos, 1, landmarks[i]->size);
					tmp = GDL_MALLOC (void *, landmarks[i]->size);
					for(j = 0; j <  landmarks[i]->size; j++)
					{
						tmp[j] = landmarks[i]->records[idx[j]];	
						gdl_gfeatures_pos_record  * rec = (gdl_gfeatures_pos_record  *)tmp[j]; 
					}
					GDL_FREE (landmarks[i]->records);
					landmarks[i]->records=tmp;
					GDL_FREE (idx);
					GDL_FREE (pos);
					i++;
				}
				while(gdl_hashtable_iterator_next (itr));
				gdl_hashtable_iterator_free (itr);				
			}
		}
		
		gdl_hashtable_free (buffer);
		gdl_fileclose(file, stream);
		
		return landmarks;
	}
}

static gdl_string ** 
gdl_gfeatures_pos_alloc_light (const gdl_string * file, const gdl_string * odir, size_t * nlandmark, gdl_dictionary * dico)
{
	// TODO :-)
}

static void 
gdl_gfeatures_pos_free (gdl_gfeatures_landmark * l)
{
	if (l)
	{
		size_t i;
		for (i = 0; i < l->size; i++)
		{
			GDL_FREE (l->records[i]);
		}
		GDL_FREE (l->records);
		GDL_FREE (l);
	}
}

gdl_gfeatures_landmark *
gdl_gfeatures_pos_fread (FILE * stream)
{
	if (stream)
	{
		int status;
		size_t i,j,pid,cid;
		gdl_gfeatures_landmark * l;
		
		l = GDL_CALLOC (gdl_gfeatures_landmark, 1);
		
		l->seqid = gdl_string_fread (stream);
		GDL_FREAD_STATUS (l->seqid != 0, 1, NULL);
		status   = fread (&(l->size), sizeof(size_t), 1, stream);
		GDL_FREAD_STATUS (status, 1, NULL);
		l->records = GDL_CALLOC (void *, l->size);
		for(i = 0; i < l->size; i++)
		{
			gdl_gfeatures_pos_record * rec = l->records[i] = GDL_MALLOC (gdl_gfeatures_pos_record, 1);
			status = fread (&(rec->position), sizeof(long), 1, stream);
		}		
		
		return l; 
	}
	return 0;
}

int 
gdl_gfeatures_pos_fwrite (FILE * stream, const gdl_gfeatures_landmark * l)
{
	if (stream && l)
	{
		int status;
		size_t i,j;
		
		status = gdl_string_fwrite (stream, l->seqid);
		GDL_FWRITE_STATUS (status, GDL_SUCCESS, 1);
		status   = fwrite (&(l->size), sizeof(size_t), 1, stream);
		GDL_FWRITE_STATUS (status, 1, 1);
		for(i = 0; i < l->size; i++)
		{
			gdl_gfeatures_pos_record * rec = l->records[i];
			status = fwrite (&(rec->position), sizeof(long), 1, stream);
			GDL_FWRITE_STATUS (status, 1, 1);
		}
		return GDL_SUCCESS; 
	}
	return GDL_EINVAL;
}


int
gdl_gfeatures_pos_record_fprintf (FILE * stream, const gdl_gfeatures_landmark * l, const gdl_gfeatures_pos_record * rec)
{
	size_t j,n,sep;
	
	fprintf(stream, "%s", l->seqid);
	fprintf(stream, " %d", rec->position);
	fprintf (stream, "\n");			
}
int 
gdl_gfeatures_pos_fprintf (FILE * stream, const gdl_gfeatures_landmark * l)
{
	if (stream && l)
	{
		size_t i;
		for(i = 0; i < l->size; i++)
		{
			gdl_gfeatures_pos_record_fprintf (stream, l, l->records[i]);	
		}
		return GDL_SUCCESS; 
	}
	return GDL_EINVAL;
}

gdl_gfeatures_landmark *
gdl_gfeatures_pos_convert (const gdl_gfeatures_landmark * l, const gdl_gfeatures_type * TO)
{
	// TODO
}

static gdl_gfeatures_type _gdl_gfeatures_pos =
{
	"gff3",
	&gdl_gfeatures_pos_alloc,
	&gdl_gfeatures_pos_alloc_light,
	&gdl_gfeatures_pos_free,
	&gdl_gfeatures_pos_fread,
	&gdl_gfeatures_pos_fwrite,
	&gdl_gfeatures_pos_fprintf,
	&gdl_gfeatures_pos_convert,
};

const gdl_gfeatures_type * gdl_gfeatures_pos = &_gdl_gfeatures_pos;

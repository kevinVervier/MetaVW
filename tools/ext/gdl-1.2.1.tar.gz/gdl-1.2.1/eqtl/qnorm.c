/*
 *  eqtl/qnorm.c 
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:29 $, $Version$
 *  
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <math.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>

/**
 * qnorm x and return the non-missing value status
 */
double *
gdl_eqtl_qqnorm (const double * x, const size_t n)
{
	size_t i,j,nm=0;
	double pr, * y, * qx; 
	size_t * yx;
	
	qx  = GDL_CALLOC (double, n);
	y   = GDL_CALLOC (double, n);
	for(i = j = 0; i < n ; i++)
	{
		if (gdl_isnan(x[i]))
		{
			qx[i] = GDL_NAN;
			nm++;
		}
		else
		{
			y[j++]=x[i];	
		}
	}
	yx = GDL_CALLOC (size_t, n - nm);
	gdl_sort_index (yx, y, 1, n - nm);
	for (j = 0; j < n - nm; j++)
	{
		pr = ((double)(j + 0.5))/((double)(n - nm + 1));
		y[yx[j]] = gdl_ran_ugaussian_quantile (pr);
	}
	for(i = j = 0; i < n; i++)
	{
		if (!gdl_isnan(x[i])) 
		{
			qx[i] = y[j++];
		}
	}
	GDL_FREE (y);
	GDL_FREE (yx);
	return qx;
}

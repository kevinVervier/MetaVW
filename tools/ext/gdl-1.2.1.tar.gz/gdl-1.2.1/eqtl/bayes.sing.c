/*
 *  eqtl/bayes.c 
 * 
 *  $Author: baptiste78 $, $Date: 2011/04/16 17:43:29 $, $Version$
 *  
 *  Libgdl : a C library for statistical genetics
 * 
 *  Copyright (C) 2003-2006  Jean-Baptiste Veyrieras, INRA, France.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA * 
 */
#include <math.h>

#include <gdl/gdl_common.h>
#include <gdl/gdl_errno.h>
#include <gdl/gdl_string.h>
#include <gdl/gdl_matrix.h>
#include <gdl/gdl_vector.h>
#include <gdl/gdl_blas.h>
#include <gdl/gdl_math.h>
#include <gdl/gdl_rng.h>
#include <gdl/gdl_randist.h>
#include <gdl/gdl_specfunc.h>
#include <gdl/gdl_sort_double.h>
#include <gdl/gdl_statistics_double.h>
#include <gdl/gdl_snp_annotation.h>
#include <gdl/gdl_eqtl_chromosome.h>
#include <gdl/gdl_eqtl_bayes.h>

gdl_eqtl_bayes *
gdl_eqtl_bayes_alloc (const size_t N, const size_t P)
{
	size_t i, j;
	gdl_eqtl_bayes * b;	
	
	b = GDL_CALLOC (gdl_eqtl_bayes, 1);
	
	b->P = P;
	b->N = N;	
		
	b->X   = gdl_matrix_alloc (N, 3);
	b->Q   = gdl_matrix_alloc (3, 3);
	b->QSI = gdl_matrix_alloc (3, 3);
	
	b->y  = gdl_vector_alloc (N);
	b->S  = gdl_vector_alloc (3);
	b->yy = gdl_vector_alloc (3);
	b->D  = gdl_vector_alloc (3);
	b->b  = gdl_vector_alloc (3);
 	b->xt = gdl_vector_alloc (3);
 	
 	for (i = 0; i < b->X->size1; i++)
 	{
 		gdl_matrix_set (b->X, i, 0, 1);
 	}
 	
	return b;
}

void
gdl_eqtl_bayes_free (gdl_eqtl_bayes * b)
{
	if (b)
	{
		gdl_matrix_free (b->X);
		gdl_matrix_free (b->Y);
		gdl_matrix_free (b->Q);
		gdl_matrix_free (b->QSI);
		gdl_matrix_free (b->invOmega);
		gdl_vector_free (b->y);
		gdl_vector_free (b->yy);
		gdl_vector_free (b->S);
		gdl_vector_free (b->D);
		gdl_vector_free (b->b);
		gdl_vector_free (b->xt);
		GDL_FREE (b->pidx);
		GDL_FREE (b);	
	}	
}

#define VECTOR_SET(X,i,y)(*(X->data+i*X->stride)=y)
#define VECTOR_GET(X,i)(*(X->data+i*X->stride))
#define MATRIX_SET(X,i,j,y)(*(X->data+(i*X->tda+j))=y)
#define MATRIX_GET(X,i,j)(*(X->data+(i*X->tda+j)))

size_t
gdl_eqtl_bayes_snp_init (gdl_eqtl_bayes * bayes, gdl_eqtl_chromosome * chrom, const size_t snp, const size_t probe)
{
	size_t i, j, k, kk, l, p, npop=0;
	
	bayes->y->size = bayes->X->size1 = chrom->nindiv;
	
	for (kk = k = i = 0; i < chrom->npop; i++)
	{
		if (gdl_snp_chromosome_is_polymorphic (chrom->snp_data, i, snp))
		{
			npop++;
			for(j = 0; j < chrom->pop_sizes[i]; j++, k++, kk++)
			{
				VECTOR_SET (bayes->y, k, gdl_matrix_get (bayes->Y, kk, probe));
				if (!probe)
				{
					switch(gdl_snp_chromosome_get_genotype (chrom->snp_data, i, j, snp))
					{
						case '2':
							MATRIX_SET(bayes->X, k, 1, 2);
							MATRIX_SET(bayes->X, k, 2, 0);
							//gdl_matrix_set (bayes->X, k, bayes->P, 2);
							//gdl_matrix_set (bayes->X, k, bayes->P+1, 0);
							break;
						case '1':
							MATRIX_SET (bayes->X, k, 1, 1);
							MATRIX_SET (bayes->X, k, 2, 1);
	//						gdl_matrix_set (bayes->X, k, bayes->P, 1);
	//						gdl_matrix_set (bayes->X, k, bayes->P+1, 1);
							break;
						case '0':
							MATRIX_SET (bayes->X, k, 1, 0);
							MATRIX_SET (bayes->X, k, 2, 0);
	//						gdl_matrix_set (bayes->X, k, bayes->P, 0);
	//						gdl_matrix_set (bayes->X, k, bayes->P+1, 0);
							break;	
					}
				}
			}
		}
		else kk += chrom->pop_sizes[i];
	}
	
	bayes->y->size = bayes->X->size1 = k;
	
	return npop;
}

void
gdl_eqtl_bayes_gene_init (gdl_eqtl_bayes * bayes, gdl_eqtl_chromosome * chrom, gdl_eqtl_block * block, const gdl_boolean qnorm)
{
	size_t i, j, k, p, pp, * rk;
	double s, m, * x;
	
	for (bayes->np = p = 0; p < block->size; p++)
	{
	   if (block->probes[p]->ignore=='n') (bayes->np)++;
	}
	
	gdl_matrix_free (bayes->Y);
	GDL_FREE (bayes->pidx);
	
	bayes->Y    = gdl_matrix_alloc (chrom->nindiv, bayes->np);
	bayes->pidx = GDL_MALLOC (size_t, bayes->np);
	
	if (qnorm)
	{
		x  = GDL_MALLOC (double, chrom->nindiv);
		rk = GDL_MALLOC (size_t, chrom->nindiv);
	}
	
	for (pp = p = 0; p < block->size; p++)
	{
		if (block->probes[p]->ignore == 'y') continue;
		bayes->pidx[pp] = p;
		for (k = i = 0; i < chrom->npop; i++)
		{
			const size_t n = chrom->pop_sizes[i];
			if (qnorm)
			{
				// normalize the data...
				double mean    = block->probes[p]->mean[i];
				double sigma   = sqrt(block->probes[p]->var[i]);
				memcpy (x, block->probes[p]->data[i], sizeof(double)*n);
				gdl_sort_index (rk, x, 1, n);
				for (j = 0; j < n; j++)
				{
					double p = ((double)(j+1))/((double)(n+1));
					x[rk[j]] = mean + sigma*gdl_ran_ugaussian_quantile (p);
				}
			}
			for(j = 0; j < n; j++, k++)
			{
				MATRIX_SET (bayes->Y, k, pp, (qnorm) ? x[j] : block->probes[p]->data[i][j]);
			}
		}
		pp++;
	}
	
	if (qnorm)
	{
		GDL_FREE (x);
		GDL_FREE (rk);
	}
}

#include "../linalg/givens.c"
#include "../linalg/svdstep.c"

static int
gdl_eqtl_bayes_svd (gdl_matrix * A, gdl_matrix * V, gdl_vector * S, gdl_vector * work)
{
	size_t a, b, i, j;
  
  const size_t M = A->size1;
  const size_t N = A->size2;
  const size_t K = GDL_MIN (M, N);

  {
    gdl_vector_view f = gdl_vector_subvector (work, 0, K - 1);
    
    /* bidiagonalize matrix A, unpack A into U S V */
    
    gdl_linalg_bidiag_decomp (A, S, &f.vector);
    gdl_linalg_bidiag_unpack2 (A, S, &f.vector, V);
    
    /* apply reduction steps to B=(S,Sd) */
    
    chop_small_elements (S, &f.vector);
    
    /* Progressively reduce the matrix until it is diagonal */
    
    b = N - 1;
    
    while (b > 0)
      {
        double fbm1 = VECTOR_GET ((&f.vector), b - 1);

        if (fbm1 == 0.0 || gdl_isnan (fbm1))
          {
            b--;
            continue;
          }
        
        /* Find the largest unreduced block (a,b) starting from b
           and working backwards */
        
        a = b - 1;
        
        while (a > 0)
          {
            double fam1 = VECTOR_GET ((&f.vector), a - 1);

            if (fam1 == 0.0 || gdl_isnan (fam1))
              {
                break;
              }
            
            a--;
          }
        
        {
          const size_t n_block = b - a + 1;
          gdl_vector_view S_block = gdl_vector_subvector (S, a, n_block);
          gdl_vector_view f_block = gdl_vector_subvector (&f.vector, a, n_block - 1);
          
          gdl_matrix_view U_block =
            gdl_matrix_submatrix (A, 0, a, A->size1, n_block);
          gdl_matrix_view V_block =
            gdl_matrix_submatrix (V, 0, a, V->size1, n_block);
          
          qrstep (&S_block.vector, &f_block.vector, &U_block.matrix, &V_block.matrix);
          
          /* remove any small off-diagonal elements */
          
          chop_small_elements (&S_block.vector, &f_block.vector);
        }
      }
  }
  /* Make singular values positive by reflections if necessary */
  
  for (j = 0; j < K; j++)
    {
      double Sj = VECTOR_GET (S, j);
      
      if (Sj < 0.0)
        {
          for (i = 0; i < N; i++)
            {
              double Vij = MATRIX_GET (V, i, j);
              MATRIX_SET (V, i, j, -Vij);
            }
          
          VECTOR_SET (S, j, -Sj);
        }
    }
  
  /* Sort singular values into decreasing order */
  
  for (i = 0; i < K; i++)
    {
      double S_max = VECTOR_GET (S, i);
      size_t i_max = i;
      
      for (j = i + 1; j < K; j++)
        {
          double Sj = VECTOR_GET (S, j);
          
          if (Sj > S_max)
            {
              S_max = Sj;
              i_max = j;
            }
        }
      
      if (i_max != i)
        {
          /* swap eigenvalues */
          gdl_vector_swap_elements (S, i, i_max);
          
          /* swap eigenvectors */
          gdl_matrix_swap_columns (A, i, i_max);
          gdl_matrix_swap_columns (V, i, i_max);
        }
    }
  
  return GDL_SUCCESS;	
}

int
gdl_eqtl_bayes_solve (gdl_eqtl_bayes * bayes)
{
   const size_t n = bayes->invOmega->size1;
   const size_t p = bayes->invOmega->size2;

   size_t i, j, p_eff;
   double alpha0;

   /* Balance the columns of the matrix A */

   //gdl_linalg_balance_columns (bayes->invOmega, bayes->D);

   /* Decompose A into U S Q^T */
   
   gdl_eqtl_bayes_svd (bayes->invOmega, bayes->Q, bayes->S, bayes->xt);
   
   /* Solve y = A c for c */

   gdl_blas_dgemv (CblasTrans, 1.0, bayes->invOmega, bayes->yy, 0.0, bayes->xt);

   alpha0     = gdl_vector_get (bayes->S, 0);
   bayes->det = 1;
   
  for (j = 0; j < p; j++)
    {
      gdl_vector_view column = gdl_matrix_column (bayes->Q, j);
      double alpha = VECTOR_GET(bayes->S, j);
		if (alpha <= GDL_DBL_EPSILON * alpha0) {
        alpha = 0.0;
      } else {
        bayes->det *= alpha;//*gdl_vector_get (bayes->D, j);
        alpha = 1.0 / alpha;
      }
      gdl_vector_scale (&column.vector, alpha);
    }

   gdl_vector_set_zero (bayes->b);

   gdl_blas_dgemv (CblasNoTrans, 1.0, bayes->Q, bayes->xt, 0.0, bayes->b);

   /* Unscale the balancing factors */

   //gdl_vector_div (bayes->b, bayes->D);

   return GDL_SUCCESS;
}

double
gdl_eqtl_bayes_compute_factor2 (gdl_eqtl_bayes * bayes,
                                const double sigmaa,
                                const double sigmad,
                                const double sigmap)
{
	return 0;
}                                

double
gdl_eqtl_bayes_compute_factor (gdl_eqtl_bayes * bayes,
                               const double sigmaa,
                               const double sigmad)
{
	const size_t N = bayes->X->size1;
	
	size_t i, j;
	double e0, e1, t, s, s2, u, v, bf;
	
	gdl_matrix_free (bayes->invOmega);
	bayes->invOmega = gdl_matrix_calloc (3, 3);
	MATRIX_SET (bayes->invOmega, 1, 1, 1/(sigmaa*sigmaa));
	MATRIX_SET (bayes->invOmega, 2, 2, 1/(sigmad*sigmad));

	gdl_blas_dgemm (CblasTrans, CblasNoTrans, 1, bayes->X, bayes->X, 1, bayes->invOmega);
	gdl_blas_dgemv (CblasTrans, 1, bayes->X, bayes->y, 0, bayes->yy);
	
	gdl_eqtl_bayes_solve (bayes);
	
	e1 = s = s2 = 0;
	for (i = 0; i < N; i++)
	{
		t   = VECTOR_GET (bayes->y, i);
		s2 += t*t;
		s  += t;
		v   = t;
		for (j = 0; j < 3; j++)
		{
			v -= VECTOR_GET (bayes->b, j) * MATRIX_GET (bayes->X, i, j);
		}
		e1 += v*t;
	}
	e0 = s2-s*s/N;
	
	bf  = -0.5*log(bayes->det);
	bf += 0.5*log(N);
	bf -= log (sigmaa);
	bf -= log (sigmad);
	bf -= 0.5*N*(log(e1)-log(e0));
	
	return bf/log(10);
}

void
gdl_eqtl_chromosome_cis_bayes (gdl_eqtl_chromosome * chrom, const gdl_eqtl_bayes_grid * grid, const double threshold, const gdl_boolean qnorm)
{
	const size_t G = chrom->ngene;
	const size_t P = chrom->ploidy;
	const size_t N = chrom->nindiv;
	const size_t POP = chrom->npop;
	size_t i, j, k, l, p, g, m, maxg;
	gdl_genex_gene * gene;
	gdl_genex_block * block;
	gdl_snp ** snps;
	double max, bf, u, a, d;
	gdl_eqtl_bayes * bayes;
	
	snps = chrom->snp_data->chrom->snps;
	
	bayes = gdl_eqtl_bayes_alloc (N, POP);
	
	for (i = 0; i < G; i++)
	{
		gene = chrom->genes[i];
		
		if (gene->ignore == 'y') continue;
		
		for (j = 0; j < gene->size; j++)
		{
			block = gene->blocks[j];
			
			if (block->ignore == 'y') continue;
			
			gdl_genex_block_clean_record_snp (block);
			
			gdl_eqtl_bayes_gene_init (bayes, chrom, block, qnorm);
			
			for (l = block->snp_up; l <= block->snp_down; l++)
			{
				if (snps[l]->ignore == 'y') continue;
				
				u = a = d = 0;
				
				for (p = 0; p < bayes->np; p++)
				{
					gdl_eqtl_bayes_snp_init (bayes, chrom, l, p);
					
					for (bf = 0, g = 0; g < grid->size; g++)
					{
						bf += grid->weight[g]*gdl_eqtl_bayes_compute_factor (bayes, grid->sigmaa[g], 0.25*grid->sigmaa[g]);
						u  += grid->weight[g]*gdl_vector_get (bayes->b, 0);	
						a  += grid->weight[g]*gdl_vector_get (bayes->b, 1);
						d  += grid->weight[g]*gdl_vector_get (bayes->b, 2);
					}
					
					if (bf >= threshold)
					{
						fprintf (chrom->logger, "%s %s %d %d %d %d %c %s %d %d %s %d %g %g %g %e\n",chrom->name,gene->name,gene->id,j+1,block->start,block->end,block->strand,block->probes[bayes->pidx[p]]->name, block->probes[bayes->pidx[p]]->start, block->probes[bayes->pidx[p]]->end, snps[l]->rs, snps[l]->position, u, a, d, bf);
						gdl_genex_block_record_snp (block, bayes->pidx[p], l);
					}
				}
			}
		}
	}
	
	gdl_eqtl_bayes_free (bayes);
}
